import {
  createContext,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { jwtDecode } from 'jwt-decode';
import { authenticateGuest } from '../../api/endpoints/auth';
import { checkoutSession, getOrCreateSession } from '../../api/endpoints/session';
import { configureHttp } from '../../api/http';
import { ApiError } from '../../api/ApiError';
import type { GuestCheckoutResponse, GuestLoginRequest } from '../../api/types';

// Session lifecycle status. ACTIVE/CLOSED are the only meaningful values for the
// teardown seam; null is the pre-authenticate state. CLOSED is IN-MEMORY ONLY —
// it is never persisted (A2): a reload re-derives ACTIVE via get-or-create.
export type SessionStatus = 'ACTIVE' | 'CLOSED' | null;

export interface SessionState {
  token: string | null;
  expiresAt: number | null;
  sessionId: string | null;
  venueId: string | null;
  serviceLocationId: string | null;
  // Teardown seam (D-11, RESEARCH Option A): observable lifecycle status, a derived
  // `closed` boolean the order/cart/raise UI (and Phase 5 STOMP connect effect) gate on,
  // a guarded server-authoritative checkout(), and the server summary CheckoutPage renders.
  status: SessionStatus;
  closed: boolean;
  authenticate(qr: GuestLoginRequest): Promise<void>;
  reAuth(): Promise<void>;
  // Returns the server summary on success, undefined on guard/error. The CALLING PAGE
  // toasts on undefined (SessionProvider is mounted ABOVE ToastProvider, so it cannot
  // consume useToast — see SUMMARY mount-order note).
  checkout(): Promise<GuestCheckoutResponse | undefined>;
  checkoutSummary: GuestCheckoutResponse | null;
}

export const SessionCtx = createContext<SessionState | null>(null);

const STORAGE_KEY = 'halia.guest.session';

// Only non-secret fields are ever persisted. clientSecret is deliberately absent.
interface PersistedSession {
  token: string | null;
  expiresAt: number | null;
  sessionId: string | null;
  clientId: string | null;
  venueId: string | null;
  serviceLocationId: string | null;
}

// Derive expiry (ms epoch) from the JWT `exp` claim; null if undecodable.
function expFromJwt(token: string): number | null {
  try {
    return (jwtDecode<{ exp?: number }>(token).exp ?? 0) * 1000 || null;
  } catch {
    return null;
  }
}

export function SessionProvider({ children }: { children: ReactNode }) {
  const [token, setTokenState] = useState<string | null>(null);
  const [expiresAt, setExpiresAt] = useState<number | null>(null);
  const [sessionId, setSessionIdState] = useState<string | null>(null);
  const [venueId, setVenueId] = useState<string | null>(null);
  const [serviceLocationId, setServiceLocationId] = useState<string | null>(null);
  // Lifecycle status (in-memory only — never persisted). Derived `closed` below.
  const [status, setStatus] = useState<SessionStatus>(null);
  // Server checkout summary CheckoutPage renders verbatim (never computed client-side, D-09).
  const [checkoutSummary, setCheckoutSummary] =
    useState<GuestCheckoutResponse | null>(null);
  const closed = status === 'CLOSED';

  // In-memory only: the clientSecret-bearing creds. NEVER persisted anywhere.
  const qrCredsRef = useRef<GuestLoginRequest | null>(null);
  // Single-flight re-auth promise (collapses concurrent 401s).
  const inFlightRef = useRef<Promise<void> | null>(null);
  // In-flight checkout guard (mirrors CartProvider's submittingRef double-submit guard).
  const checkoutRef = useRef(false);
  // Live mirrors so http.getToken / reAuth read current values, not stale closures.
  const tokenRef = useRef<string | null>(null);
  const sessionIdRef = useRef<string | null>(null);

  const setToken = useCallback((t: string | null, exp: number | null) => {
    tokenRef.current = t;
    setTokenState(t);
    setExpiresAt(exp);
  }, []);

  const setSessionId = useCallback((id: string | null) => {
    sessionIdRef.current = id;
    setSessionIdState(id);
  }, []);

  // Write ONLY non-secret fields to sessionStorage (single-tab reload survival).
  const persist = useCallback((data: PersistedSession) => {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, []);

  const authenticate = useCallback(
    async (qr: GuestLoginRequest) => {
      const jwt = await authenticateGuest(qr);
      qrCredsRef.current = qr; // cache for re-auth (in-memory only)
      const exp = expFromJwt(jwt.accessToken);
      setToken(jwt.accessToken, exp);
      setVenueId(qr.venueId);
      setServiceLocationId(qr.serviceLocationId);
      const session = await getOrCreateSession();
      setSessionId(session.id); // sessionId = response.id
      // Surface the server lifecycle status; default ACTIVE if the field is absent.
      // CLOSED is never carried here — checkout() is the only path that sets CLOSED.
      setStatus(session.status === 'CLOSED' ? 'CLOSED' : 'ACTIVE');
      persist({
        token: jwt.accessToken,
        expiresAt: exp,
        sessionId: session.id,
        clientId: qr.clientId,
        venueId: qr.venueId,
        serviceLocationId: qr.serviceLocationId,
      });
    },
    [persist, setSessionId, setToken],
  );

  // Single-flight re-auth (Pattern 3): concurrent 401s collapse to ONE authenticate.
  // Reuses the existing sessionId (no get-or-create on a pure token refresh).
  const reAuth = useCallback(async () => {
    if (inFlightRef.current) return inFlightRef.current;
    const p = (async () => {
      const creds = qrCredsRef.current;
      if (!creds) throw new ApiError(401, 'session unrecoverable', 'NO_QR');
      const jwt = await authenticateGuest(creds);
      const exp = expFromJwt(jwt.accessToken);
      setToken(jwt.accessToken, exp);
      persist({
        token: jwt.accessToken,
        expiresAt: exp,
        sessionId: sessionIdRef.current,
        clientId: creds.clientId,
        venueId: creds.venueId,
        serviceLocationId: creds.serviceLocationId,
      });
    })();
    inFlightRef.current = p;
    try {
      await p;
    } finally {
      inFlightRef.current = null;
    }
  }, [persist, setToken]);

  // Guarded, server-authoritative checkout (D-11, Option A). Single-flight via checkoutRef
  // and an early-return when already CLOSED (T-04-04). On success: status → CLOSED and the
  // server summary is stashed for CheckoutPage. On 404/403 (and any error) it returns
  // undefined and STAYS on screen (status unchanged) — the calling page toasts on undefined.
  // NO 409 branch: the server is the authority and the checkout path never documents 409
  // (Pitfall 4). CLOSED is in-memory only — checkout() never persists (A2).
  const checkout = useCallback(async (): Promise<
    GuestCheckoutResponse | undefined
  > => {
    if (checkoutRef.current || !sessionIdRef.current || closed) return;
    checkoutRef.current = true;
    try {
      const res = await checkoutSession(sessionIdRef.current);
      setStatus('CLOSED');
      setCheckoutSummary(res);
      return res;
    } catch {
      // 404/403/other: stay on screen (status untouched). Page toasts on undefined.
      return undefined;
    } finally {
      checkoutRef.current = false;
    }
  }, [closed]);

  // On mount: hydrate non-secret fields from sessionStorage (qrCredsRef stays null —
  // no secret persisted), and bridge token/reAuth into the React-free http layer.
  useEffect(() => {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        const data = JSON.parse(raw) as PersistedSession;
        setToken(data.token, data.expiresAt);
        setSessionId(data.sessionId);
        setVenueId(data.venueId);
        setServiceLocationId(data.serviceLocationId);
        // CR-01: re-derive the lifecycle status on reload. status is in-memory only, so a
        // rehydrated session would otherwise stay null and the RealtimeProvider gate
        // (status === 'ACTIVE') would never reopen — silently killing live order/SR pushes
        // for the rest of the session after a routine reload. When a VALID, non-expired token
        // + sessionId rehydrate, restore ACTIVE (the same default authenticate() applies when
        // the server omits the field) so realtime re-activates. A missing/expired token leaves
        // status null, preserving today's re-auth/expiry path (no optimistic ACTIVE).
        const notExpired =
          data.expiresAt == null || data.expiresAt > Date.now();
        if (data.token && data.sessionId && notExpired) {
          setStatus('ACTIVE');
        }
      } catch {
        // ignore corrupt storage
      }
    }
    configureHttp({ getToken: () => tokenRef.current, reAuth });
  }, [reAuth, setSessionId, setToken]);

  const value = useMemo<SessionState>(
    () => ({
      token,
      expiresAt,
      sessionId,
      venueId,
      serviceLocationId,
      status,
      closed,
      authenticate,
      reAuth,
      checkout,
      checkoutSummary,
    }),
    [
      token,
      expiresAt,
      sessionId,
      venueId,
      serviceLocationId,
      status,
      closed,
      authenticate,
      reAuth,
      checkout,
      checkoutSummary,
    ],
  );

  return <SessionCtx.Provider value={value}>{children}</SessionCtx.Provider>;
}
