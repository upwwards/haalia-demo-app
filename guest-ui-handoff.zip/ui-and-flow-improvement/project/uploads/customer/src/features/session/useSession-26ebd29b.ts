import { useContext } from 'react';
import { SessionCtx, type SessionState } from './SessionProvider';

export function useSession(): SessionState {
  const v = useContext(SessionCtx);
  if (!v) throw new Error('useSession must be used inside <SessionProvider>');
  return v;
}
