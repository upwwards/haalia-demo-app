import type { GuestLoginRequest } from '../../api/types';

const FIELDS = ['clientId', 'clientSecret', 'venueId', 'serviceLocationId'] as const;

// Validate the four required QR credential fields. Returns a GuestLoginRequest only when
// all are present-and-truthy; otherwise null. Never logs its input/result, never builds a URL.
export function parseQrCreds(
  input: Record<string, unknown>,
): GuestLoginRequest | null {
  if (FIELDS.some((k) => !input[k])) return null;
  return Object.fromEntries(
    FIELDS.map((k) => [k, String(input[k])]),
  ) as unknown as GuestLoginRequest;
}
