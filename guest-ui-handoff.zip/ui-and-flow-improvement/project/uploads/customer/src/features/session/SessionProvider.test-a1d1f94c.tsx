import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { act, renderHook, waitFor } from '@testing-library/react';
import { http as mswHttp, HttpResponse } from 'msw';
import type { ReactNode } from 'react';
import { server } from '../../test/server';
import { errorHandlers } from '../../test/handlers';
import { errorBody, nowPlus, signedFakeJwt } from '../../test/jwt';
import { http } from '../../api/http';
import { ApiError } from '../../api/ApiError';
import type { GuestJwtResponse } from '../../api/types';
import { SessionProvider } from './SessionProvider';
import { useSession } from './useSession';

const QR = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'v1',
  serviceLocationId: 'l1',
};

const jwtResponse = (): GuestJwtResponse => ({
  accessToken: signedFakeJwt({ exp: nowPlus(3600) }),
  tokenType: 'Bearer',
  organizationId: 'org-1',
  venueId: 'v1',
  serviceLocationId: 'l1',
  role: 'GUEST',
});

function wrapper({ children }: { children: ReactNode }) {
  return <SessionProvider>{children}</SessionProvider>;
}

beforeEach(() => sessionStorage.clear());
afterEach(() => sessionStorage.clear());

describe('SessionProvider (AUTH-02/03/04)', () => {
  it('authenticate stores token, sessionId, and a decoded non-null expiresAt', async () => {
    const { result } = renderHook(() => useSession(), { wrapper });
    await act(async () => {
      await result.current.authenticate(QR);
    });
    expect(result.current.token).toBeTruthy();
    expect(result.current.sessionId).toBe('session-1');
    expect(result.current.expiresAt).not.toBeNull();
    expect(result.current.expiresAt as number).toBeGreaterThan(Date.now());
  });

  it('persists token/sessionId but NEVER the clientSecret', async () => {
    const { result } = renderHook(() => useSession(), { wrapper });
    await act(async () => {
      await result.current.authenticate(QR);
    });
    const dump = Object.keys(sessionStorage)
      .map((k) => sessionStorage.getItem(k))
      .join('|');
    expect(dump).toContain('session-1'); // sessionId persisted
    expect(dump).not.toContain('sekret'); // secret NEVER persisted
  });

  it('collapses concurrent 401s into exactly one re-authenticate (single-flight)', async () => {
    let authCalls = 0;
    let unlocked = true;
    server.use(
      mswHttp.post('*/api/v1/auth/guest/authenticate', () => {
        authCalls += 1;
        unlocked = true;
        return HttpResponse.json(jwtResponse());
      }),
      mswHttp.get('*/api/v1/__protected', () =>
        unlocked
          ? HttpResponse.json({ ok: true })
          : HttpResponse.json(errorBody(401, 'UNAUTHORIZED'), { status: 401 }),
      ),
    );

    const { result } = renderHook(() => useSession(), { wrapper });
    await act(async () => {
      await result.current.authenticate(QR);
    });

    // Now simulate a wave of concurrent 401s that must collapse to ONE re-auth.
    authCalls = 0;
    unlocked = false;

    await act(async () => {
      const calls = Array.from({ length: 5 }, () =>
        http<{ ok: boolean }>('/__protected', { method: 'GET' }),
      );
      const results = await Promise.all(calls);
      expect(results.every((r) => r.ok)).toBe(true);
    });

    expect(authCalls).toBe(1);
  });

  it('reAuth reuses the existing sessionId without calling get-or-create again', async () => {
    let sessionCalls = 0;
    server.use(
      mswHttp.post('*/api/v1/guest/service-sessions/get-or-create', () => {
        sessionCalls += 1;
        return HttpResponse.json({
          id: 'session-1',
          serviceLocationId: 'l1',
          status: 'ACTIVE',
          startedAt: new Date().toISOString(),
          endedAt: '',
        });
      }),
    );
    const { result } = renderHook(() => useSession(), { wrapper });
    await act(async () => {
      await result.current.authenticate(QR);
    });
    expect(sessionCalls).toBe(1);
    await act(async () => {
      await result.current.reAuth();
    });
    expect(sessionCalls).toBe(1); // unchanged — pure token refresh
    expect(result.current.sessionId).toBe('session-1');
  });

  it('CR-01: rehydrating a VALID, non-expired token + sessionId restores status to ACTIVE (realtime re-activates)', async () => {
    sessionStorage.setItem(
      'halia.guest.session',
      JSON.stringify({
        token: signedFakeJwt({ exp: nowPlus(3600) }),
        expiresAt: nowPlus(3600) * 1000,
        sessionId: 'session-1',
        clientId: 'c1',
        venueId: 'v1',
        serviceLocationId: 'l1',
      }),
    );
    const { result } = renderHook(() => useSession(), { wrapper });
    // The mount-time rehydrate effect restores token/sessionId AND re-derives ACTIVE so the
    // RealtimeProvider gate (status === 'ACTIVE') reopens after a reload (CR-01).
    await waitFor(() => expect(result.current.token).toBeTruthy());
    await waitFor(() => expect(result.current.status).toBe('ACTIVE'));
    expect(result.current.sessionId).toBe('session-1');
    expect(result.current.closed).toBe(false);
  });

  it('CR-01: rehydrating an EXPIRED token leaves status null (no optimistic ACTIVE — re-auth/expiry path)', async () => {
    sessionStorage.setItem(
      'halia.guest.session',
      JSON.stringify({
        token: signedFakeJwt({ exp: nowPlus(-3600) }),
        expiresAt: nowPlus(-3600) * 1000, // already expired
        sessionId: 'session-1',
        clientId: 'c1',
        venueId: 'v1',
        serviceLocationId: 'l1',
      }),
    );
    const { result } = renderHook(() => useSession(), { wrapper });
    await waitFor(() => expect(result.current.token).toBeTruthy()); // hydration ran
    // An expired token must NOT optimistically reopen the realtime gate; status stays null so
    // the existing re-auth/expiry flow (not realtime) handles recovery.
    expect(result.current.status).toBeNull();
  });

  it('post-reload 401 with no in-memory secret throws terminally (no re-auth)', async () => {
    sessionStorage.setItem(
      'halia.guest.session',
      JSON.stringify({
        token: signedFakeJwt({ exp: nowPlus(3600) }),
        expiresAt: nowPlus(3600) * 1000,
        sessionId: 'session-1',
        clientId: 'c1',
        venueId: 'v1',
        serviceLocationId: 'l1',
      }),
    );
    let authCalls = 0;
    server.use(
      mswHttp.post('*/api/v1/auth/guest/authenticate', () => {
        authCalls += 1;
        return HttpResponse.json(errorBody(401, 'X'), { status: 401 });
      }),
      mswHttp.get('*/api/v1/__protected', () =>
        HttpResponse.json(errorBody(401, 'UNAUTHORIZED'), { status: 401 }),
      ),
    );

    const { result } = renderHook(() => useSession(), { wrapper });
    await waitFor(() => expect(result.current.token).toBeTruthy()); // hydration ran

    const err = await http('/__protected', { method: 'GET' }).catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect(authCalls).toBe(0); // reAuth threw before any authenticate (no cached creds)
  });
});

describe('SessionProvider teardown seam (SESS-01 / D-11)', () => {
  it('after authenticate, status is ACTIVE and closed is false', async () => {
    const { result } = renderHook(() => useSession(), { wrapper });
    await act(async () => {
      await result.current.authenticate(QR);
    });
    expect(result.current.status).toBe('ACTIVE');
    expect(result.current.closed).toBe(false);
    expect(result.current.checkoutSummary).toBeNull();
  });

  it('checkout() success flips status to CLOSED and stashes the server summary verbatim', async () => {
    const { result } = renderHook(() => useSession(), { wrapper });
    await act(async () => {
      await result.current.authenticate(QR);
    });
    let res: unknown;
    await act(async () => {
      res = await result.current.checkout();
    });
    // The default checkout handler returns { totalOrders: 3, totalSpent: 1516.5 }.
    expect(res).toEqual({
      sessionId: 'session-1',
      totalOrders: 3,
      totalSpent: 1516.5,
    });
    expect(result.current.status).toBe('CLOSED');
    expect(result.current.closed).toBe(true);
    expect(result.current.checkoutSummary).toEqual({
      sessionId: 'session-1',
      totalOrders: 3,
      totalSpent: 1516.5,
    });
  });

  it('a second checkout() after CLOSED is a guarded no-op (no second POST)', async () => {
    let checkoutCalls = 0;
    server.use(
      mswHttp.post(
        '*/api/v1/guest/service-sessions/:sessionId/checkout',
        ({ params }) => {
          checkoutCalls += 1;
          return HttpResponse.json({
            sessionId: String(params.sessionId),
            totalOrders: 3,
            totalSpent: 1516.5,
          });
        },
      ),
    );
    const { result } = renderHook(() => useSession(), { wrapper });
    await act(async () => {
      await result.current.authenticate(QR);
    });
    await act(async () => {
      await result.current.checkout();
    });
    expect(checkoutCalls).toBe(1);
    let second: unknown = 'sentinel';
    await act(async () => {
      second = await result.current.checkout();
    });
    expect(second).toBeUndefined(); // guarded — early return
    expect(checkoutCalls).toBe(1); // no second POST
    expect(result.current.status).toBe('CLOSED');
  });

  it('checkout() 404 returns undefined and leaves the session ACTIVE (stays on screen)', async () => {
    server.use(
      errorHandlers.notFoundPost('/guest/service-sessions/:sessionId/checkout'),
    );
    const { result } = renderHook(() => useSession(), { wrapper });
    await act(async () => {
      await result.current.authenticate(QR);
    });
    let res: unknown = 'sentinel';
    await act(async () => {
      res = await result.current.checkout();
    });
    expect(res).toBeUndefined();
    expect(result.current.closed).toBe(false);
    expect(result.current.status).toBe('ACTIVE');
    expect(result.current.checkoutSummary).toBeNull();
  });

  it('checkout() 403 returns undefined and leaves the session ACTIVE (stays on screen)', async () => {
    server.use(
      errorHandlers.forbiddenPost('/guest/service-sessions/:sessionId/checkout'),
    );
    const { result } = renderHook(() => useSession(), { wrapper });
    await act(async () => {
      await result.current.authenticate(QR);
    });
    let res: unknown = 'sentinel';
    await act(async () => {
      res = await result.current.checkout();
    });
    expect(res).toBeUndefined();
    expect(result.current.closed).toBe(false);
    expect(result.current.status).toBe('ACTIVE');
  });

  it('CLOSED status is NOT persisted to sessionStorage (no-persist, A2)', async () => {
    const { result } = renderHook(() => useSession(), { wrapper });
    await act(async () => {
      await result.current.authenticate(QR);
    });
    await act(async () => {
      await result.current.checkout();
    });
    expect(result.current.status).toBe('CLOSED');
    const dump = Object.keys(sessionStorage)
      .map((k) => sessionStorage.getItem(k))
      .join('|');
    expect(dump).not.toContain('CLOSED');
    expect(dump).not.toContain('"status"');
  });
});
