import { useContext } from 'react';
import { CartCtx, type CartState } from './CartProvider';

export function useCart(): CartState {
  const v = useContext(CartCtx);
  if (!v) throw new Error('useCart must be used inside <CartProvider>');
  return v;
}
