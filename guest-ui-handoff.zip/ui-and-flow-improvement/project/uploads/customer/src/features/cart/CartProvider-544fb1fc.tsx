import {
  createContext,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import {
  clearCart,
  getCart,
  submitCart,
  upsertCart,
} from '../../api/endpoints/cart';
import { ApiError } from '../../api/ApiError';
import type {
  GuestCartItemResponse,
  GuestCartResponse,
  OrderResponse,
} from '../../api/types';
import { useSession } from '../session/useSession';
import { useToast } from '../toast/useToast';
import { intentToRequestItems, lineKey, type CartLine } from './cartAdapter';

export type CartStatus = 'idle' | 'loading' | 'empty' | 'error' | 'ready';

export interface CartState {
  lines: CartLine[]; // local-intent lines keyed by menuItemId+variantId (D-04)
  serverLines: GuestCartItemResponse[]; // per-line itemTotal for display (keyed by menuItemId)
  totalPrice: number | null; // server-authoritative ₹ — render THIS, never a computed total (D-06)
  estimatedWaitMinutes: number | null; // server-derived longest item prep time; null when empty
  count: number; // badge count derived from local intent
  status: CartStatus;
  error: ApiError | null;
  submitting: boolean;
  add(menuItemId: string, variantId?: string, notes?: string): void;
  sub(menuItemId: string, variantId?: string): void;
  remove(menuItemId: string, variantId?: string): void;
  clear(): void;
  submit(): Promise<OrderResponse | undefined>;
}

export const CartCtx = createContext<CartState | null>(null);

const DEBOUNCE_MS = 400;

export function CartProvider({ children }: { children: ReactNode }) {
  const { token, sessionId, closed } = useSession(); // token+sessionId gate the GET; closed gates writes
  const { toast } = useToast();

  const [intent, setIntent] = useState<Record<string, CartLine>>({});
  const [serverLines, setServerLines] = useState<GuestCartItemResponse[]>([]);
  const [totalPrice, setTotalPrice] = useState<number | null>(null);
  const [estimatedWaitMinutes, setEstimatedWaitMinutes] = useState<number | null>(null);
  const [status, setStatus] = useState<CartStatus>('idle');
  const [error, setError] = useState<ApiError | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Refs mirror SessionProvider's single-flight idiom: the hand-rolled debounce timer,
  // an in-flight write guard, a coalesce flag, the live intent (so flush reads fresh state,
  // not a stale closure), and the last-known-good snapshot for exact rollback.
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const writing = useRef(false);
  const dirtyWhileWriting = useRef(false);
  const intentRef = useRef<Record<string, CartLine>>({});
  const lastKnownGood = useRef<Record<string, CartLine>>({});
  const submittingRef = useRef(false);
  // Stable indirection so flush() can re-arm the debounce without a forward reference
  // to scheduleFlush (which is declared after flush).
  const scheduleFlushRef = useRef<() => void>(() => {});

  // Keep intentRef in sync so flush() (a stable callback) always sees the latest intent.
  useEffect(() => {
    intentRef.current = intent;
  }, [intent]);

  // Sync-on-Read reconcile: adopt the server's money + lines, never compute a total client-side
  // (D-06 / Pitfall 6). Local intent stays the source of line identity/quantities; we do NOT
  // rebuild local lines from the response (the cart response carries no variantId).
  const reconcile = useCallback((res: GuestCartResponse) => {
    setTotalPrice(res.totalPrice);
    setEstimatedWaitMinutes(res.estimatedWaitMinutes ?? null);
    setServerLines(res.items);
    lastKnownGood.current = intentRef.current; // commit point for rollback
  }, []);

  // Roll the optimistic intent back to the last server-confirmed snapshot.
  const rollback = useCallback(() => {
    setIntent(lastKnownGood.current);
  }, []);

  const flush = useCallback(async () => {
    if (!sessionId || closed) return; // a CLOSED session is read-only — never PUT/DELETE
    if (writing.current) {
      dirtyWhileWriting.current = true; // coalesce edits that land mid-flight
      return;
    }
    const items = intentToRequestItems(intentRef.current);
    writing.current = true;
    try {
      if (items.length === 0) {
        // D-02: never PUT items: [] — route an empty cart to DELETE and reconcile to empty.
        await clearCart(sessionId);
        setTotalPrice(0);
        setServerLines([]);
        lastKnownGood.current = intentRef.current;
        setStatus('empty');
      } else {
        const res = await upsertCart({ serviceSessionId: sessionId, items });
        reconcile(res);
        setStatus('ready');
      }
    } catch {
      rollback();
      toast({ kind: 'danger', title: "Couldn't update your cart" });
    } finally {
      writing.current = false;
      if (dirtyWhileWriting.current) {
        dirtyWhileWriting.current = false;
        scheduleFlushRef.current();
      }
    }
  }, [sessionId, closed, reconcile, rollback, toast]);

  const scheduleFlush = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      void flush();
    }, DEBOUNCE_MS);
  }, [flush]);

  // Keep the indirection ref pointed at the current scheduleFlush.
  useEffect(() => {
    scheduleFlushRef.current = scheduleFlush;
  }, [scheduleFlush]);

  // Mutate intent immutably, snapshot last-known-good BEFORE the change is not needed here —
  // lastKnownGood is committed on every successful reconcile, so it already holds the last
  // server-confirmed state. Each mutation updates optimistic state instantly, then debounces.
  const mutate = useCallback(
    (menuItemId: string, variantId: string | undefined, delta: number, notes?: string) => {
      if (closed) return; // CLOSED session: refuse mutations (no optimistic edit, no flush)
      const key = lineKey(menuItemId, variantId);
      setIntent((prev) => {
        const existing = prev[key];
        const nextQty = (existing?.quantity ?? 0) + delta;
        const next = { ...prev };
        if (nextQty <= 0) {
          delete next[key];
        } else {
          // Preserve any existing line note unless this call explicitly sets one (sub/+ never
          // clears it). An empty string clears the note.
          next[key] = {
            ...existing,
            menuItemId,
            variantId,
            quantity: nextQty,
            ...(notes !== undefined ? { notes: notes || undefined } : {}),
          };
        }
        return next;
      });
      scheduleFlush();
    },
    [closed, scheduleFlush],
  );

  const add = useCallback(
    (menuItemId: string, variantId?: string, notes?: string) => mutate(menuItemId, variantId, 1, notes),
    [mutate],
  );
  const sub = useCallback(
    (menuItemId: string, variantId?: string) => mutate(menuItemId, variantId, -1),
    [mutate],
  );
  const remove = useCallback(
    (menuItemId: string, variantId?: string) => {
      if (closed) return; // CLOSED session: refuse mutations
      const key = lineKey(menuItemId, variantId);
      setIntent((prev) => {
        if (!prev[key]) return prev;
        const next = { ...prev };
        delete next[key];
        return next;
      });
      scheduleFlush();
    },
    [closed, scheduleFlush],
  );

  const clear = useCallback(() => {
    if (closed) return; // CLOSED session: refuse mutations
    setIntent({});
    scheduleFlush(); // empty intent routes flush → DELETE (D-02)
  }, [closed, scheduleFlush]);

  const submit = useCallback(async (): Promise<OrderResponse | undefined> => {
    if (submittingRef.current || !sessionId || closed) return; // double-submit guard + CLOSED no-op (D-08, T-03-06)
    submittingRef.current = true;
    setSubmitting(true);
    try {
      const order = await submitCart(sessionId);
      // Mirror the server clear (D-07) — do NOT navigate; the page owns the inline confirmation.
      setIntent({});
      intentRef.current = {};
      lastKnownGood.current = {};
      setServerLines([]);
      setTotalPrice(0);
      setStatus('empty');
      return order;
    } catch (e) {
      const s = e instanceof ApiError ? e.status : 0;
      if (s === 409) {
        toast({ kind: 'warning', title: 'This session has closed' }); // D-10
      } else if (s === 400 || s === 422) {
        toast({ kind: 'warning', title: 'Your cart is empty' });
      } else {
        toast({ kind: 'danger', title: "Couldn't place your order" });
      }
      return undefined;
    } finally {
      submittingRef.current = false;
      setSubmitting(false);
    }
  }, [sessionId, closed, toast]);

  // Initial GET — gated on BOTH token AND sessionId (stays 'idle' until both exist).
  // Mirrors useMenu's cancelled-cleanup status machine.
  useEffect(() => {
    if (!token || !sessionId) return;
    let cancelled = false;
    setStatus('loading');
    setError(null);
    getCart(sessionId)
      .then((res) => {
        if (cancelled) return;
        reconcile(res);
        setStatus(res.items.length ? 'ready' : 'empty');
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        setError(e instanceof ApiError ? e : new ApiError(0, String(e)));
        setStatus('error');
      });
    return () => {
      cancelled = true;
    };
  }, [token, sessionId, reconcile]);

  // Session-teardown self-clear (D-11): when the session flips CLOSED, the SERVER has already
  // cleared the cart as part of checkout, so we mirror server truth locally — NO PUT/DELETE.
  // Cancels any in-flight debounce first (a pending flush would be a write against a CLOSED
  // session). This is the exact local-clear sequence from submit()'s success branch.
  useEffect(() => {
    if (!closed) return;
    if (timer.current) clearTimeout(timer.current);
    setIntent({});
    intentRef.current = {};
    lastKnownGood.current = {};
    setServerLines([]);
    setTotalPrice(0);
    setStatus('empty');
  }, [closed]);

  // Clear any pending debounce timer on unmount (Pitfall 5 — no setState-after-unmount).
  useEffect(() => {
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, []);

  const lines = useMemo(() => Object.values(intent), [intent]);
  const count = useMemo(
    () => lines.reduce((sum, l) => sum + l.quantity, 0),
    [lines],
  );

  const value = useMemo<CartState>(
    () => ({
      lines,
      serverLines,
      totalPrice,
      estimatedWaitMinutes,
      count,
      status,
      error,
      submitting,
      add,
      sub,
      remove,
      clear,
      submit,
    }),
    [
      lines,
      serverLines,
      totalPrice,
      estimatedWaitMinutes,
      count,
      status,
      error,
      submitting,
      add,
      sub,
      remove,
      clear,
      submit,
    ],
  );

  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}
