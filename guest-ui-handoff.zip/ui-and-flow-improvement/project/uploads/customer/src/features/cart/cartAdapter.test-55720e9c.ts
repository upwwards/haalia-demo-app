import { describe, expect, it } from 'vitest';
import { lineKey, intentToRequestItems, type CartLine } from './cartAdapter';

describe('lineKey (CART line identity, D-04)', () => {
  it('keys a no-variant line distinctly from a variant line of the same dish', () => {
    expect(lineKey('m1')).not.toBe(lineKey('m1', 'v1'));
  });

  it('keys two variants of one dish as distinct lines', () => {
    expect(lineKey('m1', 'v1')).not.toBe(lineKey('m1', 'v2'));
  });

  it('is stable for the same inputs', () => {
    expect(lineKey('m1', 'v1')).toBe(lineKey('m1', 'v1'));
    expect(lineKey('m1')).toBe(lineKey('m1'));
  });
});

describe('intentToRequestItems (intent → PUT body, D-05)', () => {
  it('maps each line to { menuItemId, quantity } and never emits a notes field', () => {
    const intent: Record<string, CartLine> = {
      [lineKey('m1')]: { menuItemId: 'm1', quantity: 2 },
    };
    const items = intentToRequestItems(intent);
    expect(items).toHaveLength(1);
    expect(items[0].menuItemId).toBe('m1');
    expect(items[0].quantity).toBe(2);
    expect('notes' in items[0]).toBe(false);
  });

  it('includes variantId only when present', () => {
    const intent: Record<string, CartLine> = {
      [lineKey('m1', 'v1')]: { menuItemId: 'm1', variantId: 'v1', quantity: 1 },
      [lineKey('m2')]: { menuItemId: 'm2', quantity: 3 },
    };
    const items = intentToRequestItems(intent);
    const withVariant = items.find((i) => i.menuItemId === 'm1')!;
    const without = items.find((i) => i.menuItemId === 'm2')!;
    expect(withVariant.variantId).toBe('v1');
    expect('variantId' in without).toBe(false);
  });

  it('returns [] for an empty intent', () => {
    expect(intentToRequestItems({})).toEqual([]);
  });
});
