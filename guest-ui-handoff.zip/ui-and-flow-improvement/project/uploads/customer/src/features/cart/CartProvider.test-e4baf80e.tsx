import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { act, renderHook, waitFor } from '@testing-library/react';
import { http as mswHttp } from 'msw';
import type { ReactNode } from 'react';
import { server } from '../../test/server';
import { errorHandlers } from '../../test/handlers';
import type { GuestCartUpsertRequest } from '../../api/types';
import { SessionProvider } from '../session/SessionProvider';
import { useSession } from '../session/useSession';
import { VenueProvider } from '../venue/VenueProvider';
import { ToastProvider } from '../toast/ToastProvider';
import { useToast } from '../toast/useToast';
import { CartProvider } from './CartProvider';
import { useCart } from './useCart';

const QR = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'v1',
  serviceLocationId: 'l1',
};

// Match main.tsx mount order: Session > Venue > Toast > Cart (so context resolution is identical).
function wrapper({ children }: { children: ReactNode }) {
  return (
    <SessionProvider>
      <VenueProvider>
        <ToastProvider>
          <CartProvider>{children}</CartProvider>
        </ToastProvider>
      </VenueProvider>
    </SessionProvider>
  );
}

function useHarness() {
  return { session: useSession(), cart: useCart(), toast: useToast() };
}

beforeEach(() => sessionStorage.clear());
afterEach(() => {
  sessionStorage.clear();
  vi.useRealTimers();
});

// Authenticate + wait for the initial GET cart to settle to 'ready'.
async function authReady() {
  const view = renderHook(() => useHarness(), { wrapper });
  await act(async () => {
    await view.result.current.session.authenticate(QR);
  });
  await waitFor(() => expect(view.result.current.cart.status).toBe('ready'));
  return view;
}

describe('CartProvider — read (CART-01)', () => {
  it('adopts the server totalPrice after the initial GET (never a computed total)', async () => {
    const { result } = await authReady();
    // MSW GET handler returns totalPrice: 818.
    expect(result.current.cart.totalPrice).toBe(818);
    expect(result.current.cart.serverLines).toHaveLength(2);
  });
});

describe('CartProvider — debounced full-replace write (CART-02)', () => {
  it('coalesces rapid taps within the debounce window into exactly ONE PUT', async () => {
    let putCount = 0;
    let lastBody: GuestCartUpsertRequest | null = null;
    server.use(
      mswHttp.put('*/api/v1/guest/cart', async ({ request }) => {
        putCount += 1;
        lastBody = (await request.json()) as GuestCartUpsertRequest;
        return Response.json({
          serviceSessionId: lastBody.serviceSessionId,
          totalPrice: 349 * (lastBody.items[0]?.quantity ?? 0),
          status: 'ACTIVE',
          items: lastBody.items.map((i) => ({
            menuItemId: i.menuItemId,
            menuItemName: 'x',
            categoryName: 'Mains',
            quantity: i.quantity,
            unitPrice: 349,
            itemTotal: 349 * i.quantity,
          })),
        });
      }),
    );

    vi.useFakeTimers();
    const view = renderHook(() => useHarness(), { wrapper });
    await act(async () => {
      await view.result.current.session.authenticate(QR);
    });
    // GET resolved under fake timers; advance microtasks.
    await act(async () => {
      await vi.advanceTimersByTimeAsync(0);
    });

    // Three rapid adds within one 400ms window.
    act(() => {
      view.result.current.cart.add('item-1');
      view.result.current.cart.add('item-1');
      view.result.current.cart.add('item-1');
    });
    await act(async () => {
      await vi.advanceTimersByTimeAsync(450);
    });

    expect(putCount).toBe(1);
    expect(lastBody!.items).toHaveLength(1);
    expect(lastBody!.items[0]).toMatchObject({ menuItemId: 'item-1', quantity: 3 });
  });

  it('removing one of two items PUTs the full remaining item set (full-replace)', async () => {
    let lastBody: GuestCartUpsertRequest | null = null;
    server.use(
      mswHttp.put('*/api/v1/guest/cart', async ({ request }) => {
        lastBody = (await request.json()) as GuestCartUpsertRequest;
        return Response.json({
          serviceSessionId: lastBody.serviceSessionId,
          totalPrice: 100 * lastBody.items.length,
          status: 'ACTIVE',
          items: lastBody.items.map((i) => ({
            menuItemId: i.menuItemId,
            menuItemName: 'x',
            categoryName: 'Mains',
            quantity: i.quantity,
            unitPrice: 100,
            itemTotal: 100 * i.quantity,
          })),
        });
      }),
    );

    const { result } = await authReady();
    // Build two local lines, then remove one — the resulting PUT carries the remaining line.
    act(() => {
      result.current.cart.add('item-1');
      result.current.cart.add('item-2', 'var-1');
    });
    await waitFor(() => expect(lastBody?.items.length).toBe(2));
    act(() => {
      result.current.cart.remove('item-1');
    });
    await waitFor(() => expect(lastBody?.items.length).toBe(1));
    expect(lastBody!.items[0]).toMatchObject({ menuItemId: 'item-2', variantId: 'var-1' });
  });
});

describe('CartProvider — clear routes to DELETE, never PUT [] (CART-03)', () => {
  it('removing the last item issues a DELETE and never a PUT with items: []', async () => {
    let deleteCount = 0;
    let emptyPutSeen = false;
    server.use(
      mswHttp.delete('*/api/v1/guest/cart/:sessionId', () => {
        deleteCount += 1;
        return new Response(null, { status: 204 });
      }),
      mswHttp.put('*/api/v1/guest/cart', async ({ request }) => {
        const body = (await request.json()) as GuestCartUpsertRequest;
        if (body.items.length === 0) emptyPutSeen = true;
        return Response.json({
          serviceSessionId: body.serviceSessionId,
          totalPrice: 100 * body.items.length,
          status: 'ACTIVE',
          items: body.items.map((i) => ({
            menuItemId: i.menuItemId,
            menuItemName: 'x',
            categoryName: 'Mains',
            quantity: i.quantity,
            unitPrice: 100,
            itemTotal: 100 * i.quantity,
          })),
        });
      }),
    );

    const { result } = await authReady();
    act(() => {
      result.current.cart.add('item-1');
    });
    await waitFor(() => expect(result.current.cart.count).toBe(1));
    act(() => {
      result.current.cart.remove('item-1');
    });
    await waitFor(() => expect(deleteCount).toBe(1));
    expect(emptyPutSeen).toBe(false);
    expect(result.current.cart.status).toBe('empty');
  });
});

describe('CartProvider — variant line identity (D-04)', () => {
  it('two variants of one dish are two distinct lines', async () => {
    const { result } = await authReady();
    act(() => {
      result.current.cart.add('item-2', 'var-1');
      result.current.cart.add('item-2', 'var-2');
    });
    await waitFor(() => expect(result.current.cart.lines.length).toBe(2));
    const keys = result.current.cart.lines.map((l) => `${l.menuItemId}:${l.variantId}`);
    expect(keys).toContain('item-2:var-1');
    expect(keys).toContain('item-2:var-2');
  });
});

describe('CartProvider — submit (ORDER-01)', () => {
  it('200 returns the order and clears the local cart', async () => {
    const { result } = await authReady();
    act(() => {
      result.current.cart.add('item-1');
    });
    await waitFor(() => expect(result.current.cart.count).toBe(1));

    let order;
    await act(async () => {
      order = await result.current.cart.submit();
    });
    expect(order).toMatchObject({ id: 'order-1', status: 'PENDING' });
    expect(result.current.cart.count).toBe(0);
    expect(result.current.cart.lines).toHaveLength(0);
  });

  it('re-entry while submitting is a no-op (double-submit guard)', async () => {
    let submitCalls = 0;
    server.use(
      mswHttp.post('*/api/v1/guest/cart/:sessionId/submit', async ({ params }) => {
        submitCalls += 1;
        await new Promise((r) => setTimeout(r, 30));
        return Response.json({
          id: 'order-1',
          orderNumber: 1,
          venueId: 'venue-1',
          serviceLocationId: 'loc-1',
          locationName: 'T',
          serviceSessionId: String(params.sessionId),
          status: 'PENDING',
          source: 'GUEST',
          notes: '',
          totalPrice: 0,
          orderItems: [],
          created: '',
          placedAt: '',
          confirmedAt: '',
          preparingAt: '',
          readyAt: '',
          deliveredAt: '',
          assignedWaiterId: '',
          assignedWaiterName: '',
          allergyFlag: false,
          allergyNote: '',
          priorityFlag: '',
          priorityNote: '',
        });
      }),
    );

    const { result } = await authReady();
    await act(async () => {
      // Fire two submits back-to-back; the second must be a no-op while the first is pending.
      const p1 = result.current.cart.submit();
      const p2 = result.current.cart.submit();
      await Promise.all([p1, p2]);
    });
    expect(submitCalls).toBe(1);
  });

  it('409 surfaces a distinct "session closed" toast', async () => {
    server.use(errorHandlers.conflictPost('/guest/cart/:sessionId/submit'));
    const { result } = await authReady();
    await act(async () => {
      await result.current.cart.submit();
    });
    expect(
      result.current.toast.toasts.some((t) => t.title === 'This session has closed'),
    ).toBe(true);
  });

  it('400 surfaces a distinct "cart empty" toast', async () => {
    server.use(errorHandlers.badRequestPost('/guest/cart/:sessionId/submit'));
    const { result } = await authReady();
    await act(async () => {
      await result.current.cart.submit();
    });
    expect(
      result.current.toast.toasts.some((t) => t.title === 'Your cart is empty'),
    ).toBe(true);
  });
});

describe('useCart guard', () => {
  it('throws when used outside the provider', () => {
    expect(() => renderHook(() => useCart())).toThrow(
      /useCart must be used inside <CartProvider>/,
    );
  });
});
