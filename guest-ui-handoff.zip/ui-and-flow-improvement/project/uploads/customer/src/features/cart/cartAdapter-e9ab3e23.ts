import type { GuestCartItemRequest } from '../../api/types';

// One line of local cart intent. Identity is `menuItemId` + `variantId` (D-04) — two variants
// of one dish are two distinct lines. Kept minimal: identity + quantity (+ optional display name).
// Mirrors menuAdapter's discipline: pure data, no undefined leaking into the request mapping.
export interface CartLine {
  menuItemId: string;
  variantId?: string;
  quantity: number;
  name?: string;
  notes?: string; // optional guest special-instruction note for this line
}

// Stable line key combining menuItemId + variantId so two variants of one dish key apart (D-04).
// The `?? ''` keeps a no-variant line (`m1::`) distinct from any variant line (`m1::v1`).
export function lineKey(menuItemId: string, variantId?: string): string {
  return `${menuItemId}::${variantId ?? ''}`;
}

// Map the optimistic intent record to the PUT /guest/cart body items. Emits menuItemId + quantity,
// includes variantId ONLY when present, and includes `notes` ONLY when the guest set one (a line
// with no note still emits no notes field). Empty intent → [].
export function intentToRequestItems(
  intent: Record<string, CartLine>,
): GuestCartItemRequest[] {
  return Object.values(intent).map((line) => ({
    menuItemId: line.menuItemId,
    quantity: line.quantity,
    ...(line.variantId ? { variantId: line.variantId } : {}),
    ...(line.notes ? { notes: line.notes } : {}),
  }));
}
