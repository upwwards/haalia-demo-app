import {
  createContext,
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import {
  cancelServiceRequest,
  createServiceRequest,
  listServiceRequests,
} from '../../api/endpoints/serviceRequests';
import { ApiError } from '../../api/ApiError';
import { useSession } from '../session/useSession';
import { useToast } from '../toast/useToast';
import type {
  GuestServiceRequestCreateRequest,
  GuestServiceRequestResponse,
} from '../../api/types';

export type ServiceRequestsStatus =
  | 'idle'
  | 'loading'
  | 'empty'
  | 'error'
  | 'ready';

export interface ServiceRequestsState {
  requests: GuestServiceRequestResponse[];
  status: ServiceRequestsStatus;
  error: ApiError | null;
  create(
    body: GuestServiceRequestCreateRequest,
  ): Promise<GuestServiceRequestResponse | undefined>;
  cancel(requestId: string): Promise<void>;
  refresh(): void;
  applyLiveRequest(sr: GuestServiceRequestResponse): void;
}

export const ServiceRequestsCtx = createContext<ServiceRequestsState | null>(
  null,
);

// Session-gated service-request data layer, now a SHARED-STATE context provider (RT-02 gapfix).
// Same root cause/fix as OrdersProvider: previously a plain useServiceRequests() hook gave
// RealtimeProvider and ServiceRequestPage SEPARATE instances, so a live STOMP push's
// applyLiveRequest never reached the page. Hoisting state into a provider above both yields
// ONE shared instance. The public shape returned by useServiceRequests() is unchanged
// (requests, status, error, create, cancel, refresh, applyLiveRequest).
//
// Behavior is identical to the old hook: shaped exactly like the orders layer (idle → loading →
// ready/empty/error) plus guarded create/cancel mutations that re-read server truth after every
// success (D-06). The list effect copies the orders effect verbatim: gate on sessionId, a
// `cancelled` cleanup flag guards every setState (Pitfall 5), errors are stored as a typed
// ApiError, and a `tick` counter makes refresh() re-run the fetch (the Phase-5 WebSocket-resync
// seam, D-09).
//
// Mutations mirror CartProvider.submit's in-flight guard + ApiError status branching:
//   - create: a single creatingRef collapses double-taps to one call; success refetches +
//     success toast; 400/422 → validation `warning` toast (Pitfall 3 — BOTH), else `danger`.
//   - cancel: a per-id Set guard collapses double-taps per row; success reconciles the row with
//     the server-returned CANCELLED row (D-08, never optimistic) then refetches; 409 → `warning`
//     ("can't be cancelled"), else `danger`.
// Every call routes through http() (bearer + 401 single-flight) — the layer never calls fetch.
export function ServiceRequestsProvider({ children }: { children: ReactNode }) {
  const { sessionId } = useSession();
  const { toast } = useToast();

  const [requests, setRequests] = useState<GuestServiceRequestResponse[]>([]);
  const [status, setStatus] = useState<ServiceRequestsStatus>('idle');
  const [error, setError] = useState<ApiError | null>(null);
  const [tick, setTick] = useState(0);

  // In-flight guards (CartProvider.submit idiom). Refs so concurrent calls see live state.
  const creatingRef = useRef(false);
  const cancellingRef = useRef<Set<string>>(new Set());

  const refresh = useCallback(() => setTick((t) => t + 1), []);

  // Live-merge seam (RT-02), mirroring applyLiveOrder over GuestServiceRequestResponse.
  // Merge a server-pushed SR by id — replace if present, prepend if new — so replayed rows across
  // WebSocket reconnects are idempotent at the data layer (T-05-05). Stores the pushed row verbatim;
  // flips the first arrival from 'empty' → 'ready' and leaves every other status untouched. The
  // create/cancel mutations, their guards/toasts, and refresh() are unaffected.
  const applyLiveRequest = useCallback((sr: GuestServiceRequestResponse) => {
    setRequests((prev) => {
      const i = prev.findIndex((r) => r.id === sr.id);
      if (i === -1) return [sr, ...prev];
      const next = prev.slice();
      next[i] = sr;
      return next;
    });
    setStatus((s) => (s === 'empty' ? 'ready' : s));
  }, []);

  // List effect — copied from the orders layer. Stays 'idle' (no fetch) until sessionId exists.
  useEffect(() => {
    if (!sessionId) return;
    let cancelled = false;
    setStatus('loading');
    setError(null);
    listServiceRequests(sessionId)
      .then((res) => {
        if (cancelled) return;
        setRequests(res);
        setStatus(res.length ? 'ready' : 'empty');
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        setError(e instanceof ApiError ? e : new ApiError(0, String(e)));
        setStatus('error');
      });
    return () => {
      cancelled = true;
    };
  }, [sessionId, tick]);

  const create = useCallback(
    async (
      body: GuestServiceRequestCreateRequest,
    ): Promise<GuestServiceRequestResponse | undefined> => {
      if (creatingRef.current || !sessionId) return; // single-flight guard (T-04-04)
      creatingRef.current = true;
      try {
        const row = await createServiceRequest(body);
        toast({ kind: 'success', title: 'Request sent' });
        refresh(); // re-read server truth (D-06)
        return row;
      } catch (e) {
        const s = e instanceof ApiError ? e.status : 0;
        if (s === 400 || s === 422) {
          // Pitfall 3: documented status is 400, but Spring bean-validation can surface 422.
          toast({ kind: 'warning', title: "We couldn't send that request" });
        } else {
          toast({ kind: 'danger', title: "Couldn't send your request" });
        }
        return undefined; // never throw to the caller; layer stays usable
      } finally {
        creatingRef.current = false;
      }
    },
    [sessionId, toast, refresh],
  );

  const cancel = useCallback(
    async (requestId: string): Promise<void> => {
      if (!sessionId || cancellingRef.current.has(requestId)) return; // per-row guard (T-04-04)
      cancellingRef.current.add(requestId);
      try {
        const row = await cancelServiceRequest(sessionId, requestId);
        // Server-authoritative reconcile: replace the row with the returned CANCELLED row (D-08).
        setRequests((prev) => prev.map((r) => (r.id === row.id ? row : r)));
        refresh(); // re-read server truth (D-06)
      } catch (e) {
        const s = e instanceof ApiError ? e.status : 0;
        if (s === 409) {
          toast({ kind: 'warning', title: "This request can't be cancelled" });
        } else {
          toast({ kind: 'danger', title: "Couldn't cancel your request" });
        }
      } finally {
        cancellingRef.current.delete(requestId);
      }
    },
    [sessionId, toast, refresh],
  );

  const value: ServiceRequestsState = {
    requests,
    status,
    error,
    create,
    cancel,
    refresh,
    applyLiveRequest,
  };

  return (
    <ServiceRequestsCtx.Provider value={value}>
      {children}
    </ServiceRequestsCtx.Provider>
  );
}
