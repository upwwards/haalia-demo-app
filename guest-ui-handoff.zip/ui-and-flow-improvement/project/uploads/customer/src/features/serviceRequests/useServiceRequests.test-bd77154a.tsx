import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { act, renderHook, waitFor } from '@testing-library/react';
import { http as mswHttp, HttpResponse } from 'msw';
import type { ReactNode } from 'react';
import { server } from '../../test/server';
import { errorHandlers } from '../../test/handlers';
import type {
  GuestServiceRequestResponse,
  PageGuestServiceRequestResponse,
} from '../../api/types';
import { SessionProvider } from '../session/SessionProvider';
import { ToastProvider } from '../toast/ToastProvider';
import { useSession } from '../session/useSession';
import { useToast } from '../toast/useToast';
import { ServiceRequestsProvider } from './ServiceRequestsProvider';
import { useServiceRequests } from './useServiceRequests';

const QR = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'v1',
  serviceLocationId: 'l1',
};

function wrapper({ children }: { children: ReactNode }) {
  return (
    <SessionProvider>
      <ToastProvider>
        <ServiceRequestsProvider>{children}</ServiceRequestsProvider>
      </ToastProvider>
    </SessionProvider>
  );
}

// Drive session (to authenticate), the unit under test, and the toast slice in one render so
// tests can both prime the session and assert toast behavior (ToastProvider exposes `toasts`).
function useHarness() {
  return {
    session: useSession(),
    sr: useServiceRequests(),
    toastState: useToast(),
  };
}

// GuestServiceRequestResponse fixture shaped like the MSW SR-list handler rows.
function makeRequest(
  over: Partial<GuestServiceRequestResponse> &
    Pick<GuestServiceRequestResponse, 'id'>,
): GuestServiceRequestResponse {
  return {
    serviceLocationId: 'loc-1',
    serviceSessionId: 'session-1',
    requestType: 'WATER',
    status: 'OPEN',
    message: null,
    requestedAt: new Date().toISOString(),
    completedAt: null,
    ...over,
  };
}

beforeEach(() => sessionStorage.clear());
afterEach(() => sessionStorage.clear());

async function primeSession(result: { current: ReturnType<typeof useHarness> }) {
  await act(async () => {
    await result.current.session.authenticate(QR);
  });
}

describe('useServiceRequests (SVC-01/02/03)', () => {
  it("stays 'idle' and does not fetch before the session is ready", () => {
    const { result } = renderHook(() => useHarness(), { wrapper });
    expect(result.current.sr.status).toBe('idle');
    expect(result.current.sr.requests).toHaveLength(0);
  });

  it('after auth loads the aggregated list across BOTH MSW pages (SVC-02)', async () => {
    const { result } = renderHook(() => useHarness(), { wrapper });
    await primeSession(result);
    await waitFor(() => expect(result.current.sr.status).toBe('ready'));

    const ids = result.current.sr.requests.map((r) => r.id);
    // Page 0 rows + page 1 row — proves the aggregation loop runs through the hook.
    expect(ids).toEqual(expect.arrayContaining(['sr-1', 'sr-2', 'sr-3']));
    expect(result.current.sr.requests.length).toBeGreaterThan(2);
    expect(result.current.sr.error).toBeNull();
  });

  it("becomes 'empty' when the list returns zero rows", async () => {
    server.use(
      mswHttp.get('*/api/v1/guest/service-requests/:sessionId', () =>
        HttpResponse.json({
          content: [],
          totalPages: 1,
          totalElements: 0,
          number: 0,
          size: 20,
          numberOfElements: 0,
          first: true,
          last: true,
          empty: true,
        } satisfies PageGuestServiceRequestResponse),
      ),
    );
    const { result } = renderHook(() => useHarness(), { wrapper });
    await primeSession(result);
    await waitFor(() => expect(result.current.sr.status).toBe('empty'));
    expect(result.current.sr.requests).toHaveLength(0);
  });

  it("becomes 'error' with an ApiError when the list 404s", async () => {
    server.use(errorHandlers.notFoundGet('/guest/service-requests/:sessionId'));
    const { result } = renderHook(() => useHarness(), { wrapper });
    await primeSession(result);
    await waitFor(() => expect(result.current.sr.status).toBe('error'));
    expect(result.current.sr.error?.status).toBe(404);
  });

  it('create success refetches the list and shows a success toast (SVC-01, D-06)', async () => {
    let listHits = 0;
    server.use(
      mswHttp.get('*/api/v1/guest/service-requests/:sessionId', () => {
        listHits += 1;
        const row: GuestServiceRequestResponse = {
          id: 'sr-1',
          serviceLocationId: 'loc-1',
          serviceSessionId: 'session-1',
          requestType: 'WATER',
          status: 'OPEN',
          message: null,
          requestedAt: new Date().toISOString(),
          completedAt: null,
        };
        return HttpResponse.json({
          content: [row],
          totalPages: 1,
          totalElements: 1,
          number: 0,
          size: 20,
          numberOfElements: 1,
          first: true,
          last: true,
          empty: false,
        } satisfies PageGuestServiceRequestResponse);
      }),
    );
    const { result } = renderHook(() => useHarness(), { wrapper });
    await primeSession(result);
    await waitFor(() => expect(result.current.sr.status).toBe('ready'));
    const before = listHits;

    let created: GuestServiceRequestResponse | undefined;
    await act(async () => {
      created = await result.current.sr.create({
        serviceSessionId: 'session-1',
        requestType: 'WATER',
      });
    });
    expect(created?.id).toBe('sr-new');
    await waitFor(() => expect(listHits).toBeGreaterThan(before));
    expect(
      result.current.toastState.toasts.some((t) => t.kind === 'success'),
    ).toBe(true);
  });

  it('create 400 shows a validation warning toast and does NOT throw', async () => {
    server.use(errorHandlers.badRequestPost('/guest/service-requests'));
    const { result } = renderHook(() => useHarness(), { wrapper });
    await primeSession(result);
    await waitFor(() => expect(result.current.sr.status).toBe('ready'));

    let threw = false;
    let out: GuestServiceRequestResponse | undefined = undefined;
    await act(async () => {
      try {
        out = await result.current.sr.create({
          serviceSessionId: 'session-1',
          requestType: 'CUSTOM',
          message: '',
        });
      } catch {
        threw = true;
      }
    });
    expect(threw).toBe(false);
    expect(out).toBeUndefined();
    expect(
      result.current.toastState.toasts.some((t) => t.kind === 'warning'),
    ).toBe(true);
  });

  it('create 422 shows a validation warning toast and does NOT throw (Pitfall 3)', async () => {
    server.use(errorHandlers.unprocessablePost('/guest/service-requests'));
    const { result } = renderHook(() => useHarness(), { wrapper });
    await primeSession(result);
    await waitFor(() => expect(result.current.sr.status).toBe('ready'));

    let threw = false;
    await act(async () => {
      try {
        await result.current.sr.create({
          serviceSessionId: 'session-1',
          requestType: 'CUSTOM',
          message: '',
        });
      } catch {
        threw = true;
      }
    });
    expect(threw).toBe(false);
    expect(
      result.current.toastState.toasts.some((t) => t.kind === 'warning'),
    ).toBe(true);
  });

  it('cancel on an OPEN row reconciles to CANCELLED and refetches (SVC-03)', async () => {
    // Stateful list: server truth flips sr-1 → CANCELLED once cancel runs, so the
    // refetch-on-success (D-06) re-reads the cancelled row rather than clobbering it.
    let cancelled = false;
    server.use(
      mswHttp.post(
        '*/api/v1/guest/service-requests/:sessionId/:requestId/cancel',
        ({ params }) => {
          cancelled = true;
          return HttpResponse.json({
            id: String(params.requestId),
            serviceLocationId: 'loc-1',
            serviceSessionId: String(params.sessionId),
            requestType: 'WATER',
            status: 'CANCELLED',
            message: null,
            requestedAt: new Date().toISOString(),
            completedAt: new Date().toISOString(),
          } satisfies GuestServiceRequestResponse);
        },
      ),
      mswHttp.get('*/api/v1/guest/service-requests/:sessionId', () => {
        const row: GuestServiceRequestResponse = {
          id: 'sr-1',
          serviceLocationId: 'loc-1',
          serviceSessionId: 'session-1',
          requestType: 'WATER',
          status: cancelled ? 'CANCELLED' : 'OPEN',
          message: null,
          requestedAt: new Date().toISOString(),
          completedAt: cancelled ? new Date().toISOString() : null,
        };
        return HttpResponse.json({
          content: [row],
          totalPages: 1,
          totalElements: 1,
          number: 0,
          size: 20,
          numberOfElements: 1,
          first: true,
          last: true,
          empty: false,
        } satisfies PageGuestServiceRequestResponse);
      }),
    );
    const { result } = renderHook(() => useHarness(), { wrapper });
    await primeSession(result);
    await waitFor(() => expect(result.current.sr.status).toBe('ready'));

    await act(async () => {
      await result.current.sr.cancel('sr-1');
    });
    // Server-authoritative: cancel returns CANCELLED for sr-1 and the refetch confirms it.
    await waitFor(() => {
      const row = result.current.sr.requests.find((r) => r.id === 'sr-1');
      expect(row?.status).toBe('CANCELLED');
    });
    expect(
      result.current.toastState.toasts.some((t) => t.kind === 'danger'),
    ).toBe(false);
  });

  it('cancel 409 shows a warning toast', async () => {
    server.use(
      errorHandlers.conflictPost(
        '/guest/service-requests/:sessionId/:requestId/cancel',
      ),
    );
    const { result } = renderHook(() => useHarness(), { wrapper });
    await primeSession(result);
    await waitFor(() => expect(result.current.sr.status).toBe('ready'));

    await act(async () => {
      await result.current.sr.cancel('sr-1');
    });
    expect(
      result.current.toastState.toasts.some((t) => t.kind === 'warning'),
    ).toBe(true);
  });

  describe('applyLiveRequest — merge-by-id live updater (RT-02)', () => {
    it('with a NEW id prepends (newest-first) and keeps every existing row', async () => {
      const { result } = renderHook(() => useHarness(), { wrapper });
      await primeSession(result);
      await waitFor(() => expect(result.current.sr.status).toBe('ready'));
      const initialIds = result.current.sr.requests.map((r) => r.id);
      expect(initialIds.length).toBeGreaterThan(0);

      act(() =>
        result.current.sr.applyLiveRequest(makeRequest({ id: 'sr-live' })),
      );

      expect(result.current.sr.requests[0].id).toBe('sr-live');
      for (const id of initialIds) {
        expect(result.current.sr.requests.map((r) => r.id)).toContain(id);
      }
      expect(result.current.sr.requests).toHaveLength(initialIds.length + 1);
    });

    it('with an EXISTING id replaces that row in place and drops nothing else', async () => {
      const { result } = renderHook(() => useHarness(), { wrapper });
      await primeSession(result);
      await waitFor(() => expect(result.current.sr.status).toBe('ready'));
      const existingId = result.current.sr.requests[0].id;
      const lenBefore = result.current.sr.requests.length;

      act(() =>
        result.current.sr.applyLiveRequest(
          makeRequest({ id: existingId, status: 'COMPLETED' }),
        ),
      );

      const replaced = result.current.sr.requests.find(
        (r) => r.id === existingId,
      );
      expect(replaced?.status).toBe('COMPLETED');
      expect(result.current.sr.requests).toHaveLength(lenBefore);
    });

    it('applying the SAME id twice yields exactly one row for that id (no dup)', async () => {
      const { result } = renderHook(() => useHarness(), { wrapper });
      await primeSession(result);
      await waitFor(() => expect(result.current.sr.status).toBe('ready'));

      act(() =>
        result.current.sr.applyLiveRequest(makeRequest({ id: 'sr-dup' })),
      );
      act(() =>
        result.current.sr.applyLiveRequest(
          makeRequest({ id: 'sr-dup', status: 'ACKNOWLEDGED' }),
        ),
      );

      const matches = result.current.sr.requests.filter(
        (r) => r.id === 'sr-dup',
      );
      expect(matches).toHaveLength(1);
      expect(matches[0].status).toBe('ACKNOWLEDGED');
    });

    it("from an empty list, the first applyLiveRequest flips status 'empty' → 'ready'", async () => {
      server.use(
        mswHttp.get('*/api/v1/guest/service-requests/:sessionId', () =>
          HttpResponse.json({
            content: [],
            totalPages: 1,
            totalElements: 0,
            number: 0,
            size: 20,
            numberOfElements: 0,
            first: true,
            last: true,
            empty: true,
          } satisfies PageGuestServiceRequestResponse),
        ),
      );
      const { result } = renderHook(() => useHarness(), { wrapper });
      await primeSession(result);
      await waitFor(() => expect(result.current.sr.status).toBe('empty'));

      act(() =>
        result.current.sr.applyLiveRequest(makeRequest({ id: 'sr-first' })),
      );

      expect(result.current.sr.status).toBe('ready');
      expect(result.current.sr.requests).toHaveLength(1);
      expect(result.current.sr.requests[0].id).toBe('sr-first');
    });
  });
});
