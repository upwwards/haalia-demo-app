import { useContext } from 'react';
import {
  ServiceRequestsCtx,
  type ServiceRequestsState,
  type ServiceRequestsStatus,
} from './ServiceRequestsProvider';

// Backward-compatible aliases for the pre-gapfix names so any existing references keep working.
export type { ServiceRequestsStatus };
export type UseServiceRequestsResult = ServiceRequestsState;

// RT-02 gapfix: useServiceRequests() is now a thin context consumer over the shared
// ServiceRequestsProvider (mirrors useSession/useToast). All state/effect/create/cancel/refresh/
// applyLiveRequest logic moved into the provider so RealtimeProvider and ServiceRequestPage
// observe ONE shared instance — the public shape (requests, status, error, create, cancel,
// refresh, applyLiveRequest) is identical to the old plain hook.
export function useServiceRequests(): ServiceRequestsState {
  const v = useContext(ServiceRequestsCtx);
  if (!v)
    throw new Error(
      'useServiceRequests must be used inside <ServiceRequestsProvider>',
    );
  return v;
}
