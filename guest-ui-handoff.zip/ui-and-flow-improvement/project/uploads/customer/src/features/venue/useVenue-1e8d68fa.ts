import { useContext } from 'react';
import { VenueCtx, type VenueState } from './VenueProvider';

export function useVenue(): VenueState {
  const v = useContext(VenueCtx);
  if (!v) throw new Error('useVenue must be used inside <VenueProvider>');
  return v;
}
