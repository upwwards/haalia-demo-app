import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { act, renderHook, waitFor } from '@testing-library/react';
import type { ReactNode } from 'react';
import { server } from '../../test/server';
import { errorHandlers } from '../../test/handlers';
import { ApiError } from '../../api/ApiError';
import type { GuestLoginRequest } from '../../api/types';
import { SessionProvider } from '../session/SessionProvider';
import { useSession } from '../session/useSession';
import { VenueProvider } from './VenueProvider';
import { useVenue } from './useVenue';

const QR: GuestLoginRequest = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'venue-1',
  serviceLocationId: 'loc-1',
};

// Nest VenueProvider inside SessionProvider so it can read the session token.
function wrapper({ children }: { children: ReactNode }) {
  return (
    <SessionProvider>
      <VenueProvider>{children}</VenueProvider>
    </SessionProvider>
  );
}

// Drive both hooks from one render so the test can authenticate (session) and
// observe venue state under the SAME provider tree.
function useBoth() {
  return { session: useSession(), venue: useVenue() };
}

beforeEach(() => sessionStorage.clear());
afterEach(() => sessionStorage.clear());

describe('VenueProvider (MENU-01/02)', () => {
  it('stays idle before token and fires no fetch', () => {
    const { result } = renderHook(() => useBoth(), { wrapper });
    expect(result.current.venue.status).toBe('idle');
    expect(result.current.venue.features).toEqual([]);
    expect(result.current.venue.venue).toBeNull();
    expect(result.current.venue.location).toBeNull();
  });

  it('loads features/venue/location after authenticate and reaches status ready', async () => {
    const { result } = renderHook(() => useBoth(), { wrapper });
    await act(async () => {
      await result.current.session.authenticate(QR);
    });
    await waitFor(() => expect(result.current.venue.status).toBe('ready'));
    expect(result.current.venue.hasFeature('ORDER_PLACEMENT')).toBe(true);
    expect(result.current.venue.hasFeature('ANALYTICS')).toBe(false);
    expect(result.current.venue.venue?.venueName).toBe('Verbena');
    expect(result.current.venue.location?.id).toBe('loc-1');
    expect(result.current.venue.error).toBeNull();
  });

  it('maps a 403 on features to status error with ApiError.status === 403 (not 401 re-auth)', async () => {
    server.use(errorHandlers.forbiddenGet('/guest/venue/features'));
    const { result } = renderHook(() => useBoth(), { wrapper });
    await act(async () => {
      await result.current.session.authenticate(QR);
    });
    await waitFor(() => expect(result.current.venue.status).toBe('error'));
    expect(result.current.venue.error).toBeInstanceOf(ApiError);
    expect(result.current.venue.error?.status).toBe(403);
  });

  it('useVenue throws outside <VenueProvider>', () => {
    expect(() => renderHook(() => useVenue())).toThrow(
      'useVenue must be used inside <VenueProvider>',
    );
  });
});
