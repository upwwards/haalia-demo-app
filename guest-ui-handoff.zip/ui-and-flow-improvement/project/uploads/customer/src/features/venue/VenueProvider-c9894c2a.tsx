import {
  createContext,
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import {
  getEnabledFeatures,
  getVenueDetails,
} from '../../api/endpoints/venue';
import { getCurrentLocation } from '../../api/endpoints/serviceLocation';
import { ApiError } from '../../api/ApiError';
import type {
  Feature,
  GuestServiceLocationResponse,
  GuestVenueResponse,
} from '../../api/types';
import { useSession } from '../session/useSession';

export type VenueStatus = 'idle' | 'loading' | 'ready' | 'error';

export interface VenueState {
  features: Feature[];
  venue: GuestVenueResponse | null;
  location: GuestServiceLocationResponse | null;
  status: VenueStatus;
  error: ApiError | null;
  hasFeature(f: Feature): boolean;
  refresh(): Promise<void>;
}

export const VenueCtx = createContext<VenueState | null>(null);

export function VenueProvider({ children }: { children: ReactNode }) {
  const { token } = useSession();
  const [features, setFeatures] = useState<Feature[]>([]);
  const [venue, setVenue] = useState<GuestVenueResponse | null>(null);
  const [location, setLocation] = useState<GuestServiceLocationResponse | null>(null);
  const [status, setStatus] = useState<VenueStatus>('idle');
  const [error, setError] = useState<ApiError | null>(null);

  // Fetch features + venue info + current location in parallel after auth.
  // A 403 here means a feature/venue is off (T-02-10) — it surfaces as an `error`
  // state with `error.status === 403` and is deliberately NOT funneled into the
  // session-layer 401 single-flight re-auth.
  const load = useCallback(async () => {
    setStatus('loading');
    setError(null);
    try {
      const [f, v, l] = await Promise.all([
        getEnabledFeatures(),
        getVenueDetails(),
        getCurrentLocation(),
      ]);
      setFeatures(f);
      setVenue(v);
      setLocation(l);
      setStatus('ready');
    } catch (e) {
      setError(e instanceof ApiError ? e : new ApiError(0, String(e)));
      setStatus('error');
    }
  }, []);

  // UX-only gate (T-02-09): the server is the real authority and enforces with 403
  // on submit. Never treat `hasFeature` as access control.
  const hasFeature = useCallback((f: Feature) => features.includes(f), [features]);

  // Load only once the session token exists — no fetch fires before auth (status 'idle').
  useEffect(() => {
    if (token) void load();
  }, [token, load]);

  const value = useMemo<VenueState>(
    () => ({
      features,
      venue,
      location,
      status,
      error,
      hasFeature,
      refresh: load,
    }),
    [features, venue, location, status, error, hasFeature, load],
  );

  return <VenueCtx.Provider value={value}>{children}</VenueCtx.Provider>;
}
