import {
  createContext,
  useCallback,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import { getSessionOrders } from '../../api/endpoints/orders';
import { ApiError } from '../../api/ApiError';
import { useSession } from '../session/useSession';
import type { OrderResponse } from '../../api/types';

export type OrdersStatus = 'idle' | 'loading' | 'empty' | 'error' | 'ready';

export interface OrdersState {
  orders: OrderResponse[];
  status: OrdersStatus;
  error: ApiError | null;
  refresh(): void;
  applyLiveOrder(o: OrderResponse): void;
}

export const OrdersCtx = createContext<OrdersState | null>(null);

// Session-gated order-history data layer, now a SHARED-STATE context provider (RT-02 gapfix).
// Previously this lived in a plain useOrders() hook, so RealtimeProvider and TrackingPage each
// instantiated their OWN copy of this state — RealtimeProvider's applyLiveOrder mutated an
// instance the page never read, so live STOMP pushes never reached the screen. Hoisting the
// state into a provider mounted above BOTH means there is exactly ONE instance: the push and
// the render observe the same orders array. The public shape returned by useOrders() is
// unchanged (orders, status, error, refresh, applyLiveOrder).
//
// Behavior is identical to the old hook: stays 'idle' (no fetch) until the session has a
// sessionId, then GET /orders/{sessionId} runs and the state machine transitions
// loading → ready (non-empty) / empty ([]) / error. The fetch is a BARE OrderResponse[] (no
// Page envelope, unlike the menu), so there is no pagination loop. A `cancelled` flag in the
// effect cleanup prevents setState-after-unmount under StrictMode's double-invoke. Errors are
// stored as a typed ApiError — the token is never logged or surfaced (T-02-16 / T-03-10).
//
// refresh() bumps an internal counter so the effect re-runs: this is the re-runnable read
// Phase 5 reuses as the WebSocket-reconnect resync source (D-09).
export function OrdersProvider({ children }: { children: ReactNode }) {
  const { sessionId } = useSession();
  const [orders, setOrders] = useState<OrderResponse[]>([]);
  const [status, setStatus] = useState<OrdersStatus>('idle');
  const [error, setError] = useState<ApiError | null>(null);
  const [tick, setTick] = useState(0);

  const refresh = useCallback(() => setTick((t) => t + 1), []);

  // Live-merge seam (RT-02): the symmetric "push" half of the refresh() resync contract.
  // Merge a server-pushed OrderResponse by id — replace if present, prepend if new — so
  // replayed rows across WebSocket reconnects are idempotent at the data layer (T-05-05).
  // Stores the pushed row VERBATIM (incl. totalPrice); never client-recomputes (D-06, T-05-06).
  // Flips the first arrival from 'empty' → 'ready'; leaves every other status untouched.
  const applyLiveOrder = useCallback((o: OrderResponse) => {
    setOrders((prev) => {
      const i = prev.findIndex((p) => p.id === o.id);
      if (i === -1) return [o, ...prev];
      const next = prev.slice();
      next[i] = o;
      return next;
    });
    setStatus((s) => (s === 'empty' ? 'ready' : s));
  }, []);

  useEffect(() => {
    if (!sessionId) return;
    let cancelled = false;
    setStatus('loading');
    setError(null);
    getSessionOrders(sessionId)
      .then((res) => {
        if (cancelled) return;
        setOrders(res);
        setStatus(res.length ? 'ready' : 'empty');
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        setError(e instanceof ApiError ? e : new ApiError(0, String(e)));
        setStatus('error');
      });
    return () => {
      cancelled = true;
    };
  }, [sessionId, tick]);

  const value: OrdersState = { orders, status, error, refresh, applyLiveOrder };

  return <OrdersCtx.Provider value={value}>{children}</OrdersCtx.Provider>;
}
