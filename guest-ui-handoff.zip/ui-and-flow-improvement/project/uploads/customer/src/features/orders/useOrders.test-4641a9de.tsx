import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { act, renderHook, waitFor } from '@testing-library/react';
import { http as mswHttp, HttpResponse } from 'msw';
import type { ReactNode } from 'react';
import { server } from '../../test/server';
import { errorHandlers } from '../../test/handlers';
import { ApiError } from '../../api/ApiError';
import type { OrderResponse } from '../../api/types';
import { SessionProvider } from '../session/SessionProvider';
import { useSession } from '../session/useSession';
import { OrdersProvider } from './OrdersProvider';
import { useOrders } from './useOrders';

const QR = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'v1',
  serviceLocationId: 'l1',
};

function wrapper({ children }: { children: ReactNode }) {
  return (
    <SessionProvider>
      <OrdersProvider>{children}</OrdersProvider>
    </SessionProvider>
  );
}

// Drive both useSession (to authenticate) and useOrders (the unit under test) in one render.
function useHarness() {
  return { session: useSession(), orders: useOrders() };
}

// OrderResponse fixture shaped like the MSW orders handler rows.
function makeOrder(over: Partial<OrderResponse> & Pick<OrderResponse, 'id'>): OrderResponse {
  return {
    orderNumber: 1042,
    venueId: 'venue-1',
    serviceLocationId: 'loc-1',
    locationName: 'Table 12',
    serviceSessionId: 'session-1',
    status: 'PREPARING',
    source: 'GUEST',
    notes: '',
    totalPrice: 698,
    orderItems: [],
    created: '',
    placedAt: '',
    confirmedAt: '',
    preparingAt: '',
    readyAt: '',
    deliveredAt: '',
    assignedWaiterId: '',
    assignedWaiterName: '',
    allergyFlag: false,
    allergyNote: '',
    priorityFlag: '',
    priorityNote: '',
    ...over,
  };
}

beforeEach(() => sessionStorage.clear());
afterEach(() => sessionStorage.clear());

describe('useOrders (ORDER-02)', () => {
  it("stays 'idle' and does not fetch before the session is ready", async () => {
    const { result } = renderHook(() => useHarness(), { wrapper });
    expect(result.current.orders.status).toBe('idle');
    expect(result.current.orders.orders).toHaveLength(0);
  });

  it("after auth transitions loading→ready with the session's orders", async () => {
    const { result } = renderHook(() => useHarness(), { wrapper });
    await act(async () => {
      await result.current.session.authenticate(QR);
    });
    await waitFor(() => expect(result.current.orders.status).toBe('ready'));

    expect(result.current.orders.orders.length).toBeGreaterThan(0);
    expect(result.current.orders.orders[0].id).toBe('order-1');
    expect(result.current.orders.orders[0].status).toBe('PREPARING');
    expect(result.current.orders.error).toBeNull();
  });

  it("becomes 'empty' when the session has no orders", async () => {
    server.use(
      mswHttp.get('*/api/v1/guest/orders/:sessionId', () =>
        HttpResponse.json([] satisfies OrderResponse[]),
      ),
    );
    const { result } = renderHook(() => useHarness(), { wrapper });
    await act(async () => {
      await result.current.session.authenticate(QR);
    });
    await waitFor(() => expect(result.current.orders.status).toBe('empty'));
    expect(result.current.orders.orders).toHaveLength(0);
  });

  it("becomes 'error' with an ApiError (404) on a not-found override", async () => {
    server.use(errorHandlers.notFoundGet('/guest/orders/:sessionId'));
    const { result } = renderHook(() => useHarness(), { wrapper });
    await act(async () => {
      await result.current.session.authenticate(QR);
    });
    await waitFor(() => expect(result.current.orders.status).toBe('error'));
    expect(result.current.orders.error).toBeInstanceOf(ApiError);
    expect(result.current.orders.error?.status).toBe(404);
  });

  it('refresh() re-runs the fetch (Phase-5 resync seam, D-09)', async () => {
    let hits = 0;
    server.use(
      mswHttp.get('*/api/v1/guest/orders/:sessionId', ({ params }) => {
        hits += 1;
        return HttpResponse.json([
          {
            id: 'order-1',
            orderNumber: 1042,
            venueId: 'venue-1',
            serviceLocationId: 'loc-1',
            locationName: 'Table 12',
            serviceSessionId: String(params.sessionId),
            status: 'PREPARING',
            source: 'GUEST',
            notes: '',
            totalPrice: 698,
            orderItems: [],
            created: '',
            placedAt: '',
            confirmedAt: '',
            preparingAt: '',
            readyAt: '',
            deliveredAt: '',
            assignedWaiterId: '',
            assignedWaiterName: '',
            allergyFlag: false,
            allergyNote: '',
            priorityFlag: '',
            priorityNote: '',
          },
        ] satisfies OrderResponse[]);
      }),
    );
    const { result } = renderHook(() => useHarness(), { wrapper });
    await act(async () => {
      await result.current.session.authenticate(QR);
    });
    await waitFor(() => expect(result.current.orders.status).toBe('ready'));
    const firstHits = hits;
    expect(firstHits).toBeGreaterThan(0);

    act(() => result.current.orders.refresh());
    await waitFor(() => expect(hits).toBeGreaterThan(firstHits));
    expect(result.current.orders.status).toBe('ready');
  });

  describe('applyLiveOrder — merge-by-id live updater (RT-02)', () => {
    it('with a NEW id prepends (newest-first) and keeps every existing order', async () => {
      const { result } = renderHook(() => useHarness(), { wrapper });
      await act(async () => {
        await result.current.session.authenticate(QR);
      });
      await waitFor(() => expect(result.current.orders.status).toBe('ready'));
      const initialIds = result.current.orders.orders.map((o) => o.id);
      expect(initialIds.length).toBeGreaterThan(0);

      act(() =>
        result.current.orders.applyLiveOrder(makeOrder({ id: 'order-live' })),
      );

      expect(result.current.orders.orders[0].id).toBe('order-live');
      // Every prior row is still present after the prepend.
      for (const id of initialIds) {
        expect(result.current.orders.orders.map((o) => o.id)).toContain(id);
      }
      expect(result.current.orders.orders).toHaveLength(initialIds.length + 1);
    });

    it('with an EXISTING id replaces that entry in place and drops nothing else', async () => {
      const { result } = renderHook(() => useHarness(), { wrapper });
      await act(async () => {
        await result.current.session.authenticate(QR);
      });
      await waitFor(() => expect(result.current.orders.status).toBe('ready'));
      const existingId = result.current.orders.orders[0].id;
      const lenBefore = result.current.orders.orders.length;

      act(() =>
        result.current.orders.applyLiveOrder(
          makeOrder({ id: existingId, status: 'COMPLETED', totalPrice: 999 }),
        ),
      );

      const replaced = result.current.orders.orders.find(
        (o) => o.id === existingId,
      );
      expect(replaced?.status).toBe('COMPLETED');
      // Pushed totalPrice stored verbatim (T-05-06 — never client-recomputed).
      expect(replaced?.totalPrice).toBe(999);
      expect(result.current.orders.orders).toHaveLength(lenBefore);
    });

    it('applying the SAME id twice yields exactly one row for that id (no dup)', async () => {
      const { result } = renderHook(() => useHarness(), { wrapper });
      await act(async () => {
        await result.current.session.authenticate(QR);
      });
      await waitFor(() => expect(result.current.orders.status).toBe('ready'));

      act(() =>
        result.current.orders.applyLiveOrder(makeOrder({ id: 'order-dup' })),
      );
      act(() =>
        result.current.orders.applyLiveOrder(
          makeOrder({ id: 'order-dup', status: 'READY' }),
        ),
      );

      const matches = result.current.orders.orders.filter(
        (o) => o.id === 'order-dup',
      );
      expect(matches).toHaveLength(1);
      expect(matches[0].status).toBe('READY');
    });

    it("from an empty list, the first applyLiveOrder flips status 'empty' → 'ready'", async () => {
      server.use(
        mswHttp.get('*/api/v1/guest/orders/:sessionId', () =>
          HttpResponse.json([] satisfies OrderResponse[]),
        ),
      );
      const { result } = renderHook(() => useHarness(), { wrapper });
      await act(async () => {
        await result.current.session.authenticate(QR);
      });
      await waitFor(() => expect(result.current.orders.status).toBe('empty'));

      act(() =>
        result.current.orders.applyLiveOrder(makeOrder({ id: 'order-first' })),
      );

      expect(result.current.orders.status).toBe('ready');
      expect(result.current.orders.orders).toHaveLength(1);
      expect(result.current.orders.orders[0].id).toBe('order-first');
    });
  });
});
