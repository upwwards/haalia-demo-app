import { useContext } from 'react';
import { OrdersCtx, type OrdersState, type OrdersStatus } from './OrdersProvider';

// Backward-compatible aliases for the pre-gapfix names so any existing references keep working.
export type { OrdersStatus };
export type UseOrdersResult = OrdersState;

// RT-02 gapfix: useOrders() is now a thin context consumer over the shared OrdersProvider
// (mirrors useSession/useToast). All state/effect/refresh/applyLiveOrder logic moved into the
// provider so RealtimeProvider and TrackingPage observe ONE shared instance — the public shape
// (orders, status, error, refresh, applyLiveOrder) is identical to the old plain hook.
export function useOrders(): OrdersState {
  const v = useContext(OrdersCtx);
  if (!v) throw new Error('useOrders must be used inside <OrdersProvider>');
  return v;
}
