import { describe, expect, it } from 'vitest';
import type { GuestEffectiveMenuResponse, MenuItemVariantOverrideResponse } from '../../api/types';
import { displayPrice, priceLabel } from './price';

// Minimal DTO factory — only the fields the price layer reads matter; the rest are
// filled with contract-valid defaults so the test stays focused on price logic.
function dto(over: Partial<GuestEffectiveMenuResponse>): GuestEffectiveMenuResponse {
  return {
    menuItemId: 'x',
    name: 'X',
    description: '',
    primaryImageUrl: null,
    modelUrl: null,
    type: 'VEG',
    preparationTimeInMinutes: 0,
    categoryId: 'c',
    categoryName: 'C',
    price: null,
    available: true,
    tags: [],
    hasVariants: false,
    variants: [],
    ...over,
  };
}

function variant(over: Partial<MenuItemVariantOverrideResponse>): MenuItemVariantOverrideResponse {
  return {
    variantId: 'v',
    label: 'L',
    effectivePrice: null,
    displayOrder: 0,
    available: true,
    isOverridden: false,
    ...over,
  };
}

describe('displayPrice (MENU-03, Pitfall 1)', () => {
  it('base item returns the top-level price', () => {
    expect(displayPrice(dto({ hasVariants: false, price: 349 }))).toBe(349);
  });

  it('variant item returns the MIN of available effectivePrices', () => {
    const item = dto({
      hasVariants: true,
      price: null,
      variants: [
        variant({ variantId: 'a', effectivePrice: 180, available: true }),
        variant({ variantId: 'b', effectivePrice: 320, available: true }),
      ],
    });
    expect(displayPrice(item)).toBe(180);
  });

  it('variant item with NO available variants returns null (never NaN)', () => {
    const item = dto({
      hasVariants: true,
      price: null,
      variants: [
        variant({ variantId: 'a', effectivePrice: 180, available: false }),
        variant({ variantId: 'b', effectivePrice: null, available: true }),
      ],
    });
    const p = displayPrice(item);
    expect(p).toBeNull();
    expect(Number.isNaN(p as unknown as number)).toBe(false);
  });

  it('base item with null price returns null', () => {
    expect(displayPrice(dto({ hasVariants: false, price: null }))).toBeNull();
  });
});

describe('priceLabel (MENU-03, D-Q2/D-Q4)', () => {
  it('base item renders ₹X.XX', () => {
    expect(priceLabel(dto({ hasVariants: false, price: 349 }))).toBe('₹349.00');
  });

  it('variant item renders from ₹<min>.XX', () => {
    const item = dto({
      hasVariants: true,
      price: null,
      variants: [
        variant({ variantId: 'a', effectivePrice: 180, available: true }),
        variant({ variantId: 'b', effectivePrice: 320, available: true }),
      ],
    });
    expect(priceLabel(item)).toBe('from ₹180.00');
  });

  it('no-available-price renders Unavailable with NO null/NaN in the string', () => {
    const item = dto({ hasVariants: true, price: null, variants: [] });
    const label = priceLabel(item);
    expect(label).toBe('Unavailable');
    expect(label).not.toContain('null');
    expect(label).not.toContain('NaN');
  });
});
