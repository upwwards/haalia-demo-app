import type { GuestEffectiveMenuResponse } from '../../api/types';

// Resolve the numeric display price for a menu item, or null when none is available.
// Base items use the top-level `price`; variant items (hasVariants) derive the MINIMUM
// available variant `effectivePrice`. Returns null (never NaN) when no price is available
// — `Math.min()` of an empty array is Infinity, so the empty case is short-circuited.
export function displayPrice(dto: GuestEffectiveMenuResponse): number | null {
  if (!dto.hasVariants) return dto.price ?? null;
  const prices = (dto.variants ?? [])
    .filter((v) => v.available !== false && typeof v.effectivePrice === 'number')
    .map((v) => v.effectivePrice as number);
  return prices.length ? Math.min(...prices) : null;
}

// Render a user-facing price label. Currency defaults to ₹ (D-Q4: contract is INR).
// Variant items read 'from ₹X' (D-Q2); base items read '₹X'; absent prices read
// 'Unavailable' — a null price is NEVER passed into `.toFixed`, so no 'NaN'/'₹null' leaks.
export function priceLabel(dto: GuestEffectiveMenuResponse, currency = '₹'): string {
  const p = displayPrice(dto);
  if (p === null) return 'Unavailable';
  return dto.hasVariants ? `from ${currency}${p.toFixed(2)}` : `${currency}${p.toFixed(2)}`;
}
