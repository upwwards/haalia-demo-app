import { useEffect, useState } from 'react';
import type { Category } from '@halia/ui';
import { getEffectiveMenu } from '../../api/endpoints/menu';
import { ApiError } from '../../api/ApiError';
import { useSession } from '../session/useSession';
import { deriveCategories, toMenuItem, type MenuItemView } from './menuAdapter';

export type MenuStatus = 'idle' | 'loading' | 'empty' | 'error' | 'ready';

export interface UseMenuResult {
  items: MenuItemView[];
  categories: Category[];
  status: MenuStatus;
  error: ApiError | null;
  reload: () => void;
}

// Fetch-on-session-ready menu hook. Stays 'idle' (no fetch) until the session token is
// present, then fetches ALL menu pages via getEffectiveMenu (Pitfall 2), maps each DTO
// through toMenuItem, derives the category tabs, and exposes loading/empty/error/ready
// state. A `cancelled` flag in the effect cleanup prevents setState-after-unmount under
// StrictMode's double-invoke. Errors are stored as typed ApiError — the token is never
// logged or surfaced (T-02-06).
export function useMenu(): UseMenuResult {
  const { token } = useSession();
  const [items, setItems] = useState<MenuItemView[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [status, setStatus] = useState<MenuStatus>('idle');
  const [error, setError] = useState<ApiError | null>(null);
  // Bump to re-run the fetch effect (error-state retry, MENU-aligned with sibling screens).
  const [reloadTick, setReloadTick] = useState(0);
  const reload = () => setReloadTick((n) => n + 1);

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    setStatus('loading');
    setError(null);
    getEffectiveMenu()
      .then((dtos) => {
        if (cancelled) return;
        const views = dtos.map(toMenuItem);
        setItems(views);
        setCategories(deriveCategories(views));
        setStatus(views.length ? 'ready' : 'empty');
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        setError(e instanceof ApiError ? e : new ApiError(0, String(e)));
        setStatus('error');
      });
    return () => {
      cancelled = true;
    };
  }, [token, reloadTick]);

  return { items, categories, status, error, reload };
}
