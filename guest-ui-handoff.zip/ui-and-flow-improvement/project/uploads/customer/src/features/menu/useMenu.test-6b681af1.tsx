import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { act, renderHook, waitFor } from '@testing-library/react';
import { http as mswHttp, HttpResponse } from 'msw';
import type { ReactNode } from 'react';
import { server } from '../../test/server';
import { errorHandlers } from '../../test/handlers';
import { ApiError } from '../../api/ApiError';
import type { PageGuestEffectiveMenuResponse } from '../../api/types';
import { SessionProvider } from '../session/SessionProvider';
import { useSession } from '../session/useSession';
import { priceLabel } from './price';
import { useMenu } from './useMenu';

const QR = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'v1',
  serviceLocationId: 'l1',
};

function wrapper({ children }: { children: ReactNode }) {
  return <SessionProvider>{children}</SessionProvider>;
}

// Drive both useSession (to authenticate) and useMenu (the unit under test) in one render.
function useHarness() {
  return { session: useSession(), menu: useMenu() };
}

beforeEach(() => sessionStorage.clear());
afterEach(() => sessionStorage.clear());

describe('useMenu (MENU-03/MENU-04)', () => {
  it("stays 'idle' and does not fetch before the session token is set", async () => {
    const { result } = renderHook(() => useHarness(), { wrapper });
    expect(result.current.menu.status).toBe('idle');
    expect(result.current.menu.items).toHaveLength(0);
  });

  it('after auth transitions loading→ready and aggregates ALL pages (Pitfall 2)', async () => {
    const { result } = renderHook(() => useHarness(), { wrapper });
    await act(async () => {
      await result.current.session.authenticate(QR);
    });
    await waitFor(() => expect(result.current.menu.status).toBe('ready'));

    // 2-page MSW menu: [baseItem, variantItem] then [unavailableItem] = 3 total.
    expect(result.current.menu.items).toHaveLength(3);
    const ids = result.current.menu.items.map((i) => i.id);
    expect(ids).toContain('item-1');
    expect(ids).toContain('item-2'); // only on page 0
    expect(ids).toContain('item-3'); // only on page 1 — proves multi-page aggregation

    // Categories derived (deduped): cat-mains (2) + cat-desserts (1).
    const mains = result.current.menu.categories.find((c) => c.id === 'cat-mains');
    expect(mains?.count).toBe(2);
  });

  it("renders the variant item as 'from ₹' and never 'null'/'NaN' (Pitfall 1)", async () => {
    const { result } = renderHook(() => useHarness(), { wrapper });
    await act(async () => {
      await result.current.session.authenticate(QR);
    });
    await waitFor(() => expect(result.current.menu.status).toBe('ready'));

    const variantItem = result.current.menu.items.find((i) => i.id === 'item-2');
    expect(variantItem?.hasVariants).toBe(true);
    const label = priceLabel({
      menuItemId: variantItem!.id,
      name: variantItem!.name,
      description: variantItem!.desc,
      primaryImageUrl: null,
      modelUrl: variantItem!.modelUrl,
      type: 'NON_VEG',
      preparationTimeInMinutes: variantItem!.time,
      categoryId: variantItem!.cat,
      categoryName: variantItem!.categoryName,
      price: null,
      available: variantItem!.available,
      tags: variantItem!.tags,
      hasVariants: variantItem!.hasVariants,
      variants: variantItem!.variants,
    });
    expect(label).toMatch(/^from ₹/);
    expect(label).not.toContain('null');
    expect(label).not.toContain('NaN');
  });

  it("becomes 'empty' when the menu has no content", async () => {
    server.use(
      mswHttp.get('*/api/v1/guest/menu/effective', () =>
        HttpResponse.json({
          content: [],
          totalPages: 1,
          totalElements: 0,
          number: 0,
          size: 20,
          numberOfElements: 0,
          first: true,
          last: true,
          empty: true,
        } satisfies PageGuestEffectiveMenuResponse),
      ),
    );
    const { result } = renderHook(() => useHarness(), { wrapper });
    await act(async () => {
      await result.current.session.authenticate(QR);
    });
    await waitFor(() => expect(result.current.menu.status).toBe('empty'));
    expect(result.current.menu.items).toHaveLength(0);
  });

  it("becomes 'error' with an ApiError on a 404 override", async () => {
    server.use(errorHandlers.notFoundGet('/guest/menu/effective'));
    const { result } = renderHook(() => useHarness(), { wrapper });
    await act(async () => {
      await result.current.session.authenticate(QR);
    });
    await waitFor(() => expect(result.current.menu.status).toBe('error'));
    expect(result.current.menu.error).toBeInstanceOf(ApiError);
    expect(result.current.menu.error?.status).toBe(404);
  });
});
