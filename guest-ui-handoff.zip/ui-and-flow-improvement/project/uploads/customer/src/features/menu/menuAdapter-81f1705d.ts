import type { MenuItem, Category } from '@halia/ui';
import type {
  GuestEffectiveMenuResponse,
  MenuItemVariantOverrideResponse,
} from '../../api/types';
import { displayPrice } from './price';

// The @halia/ui MenuItem (the component contract) extended with the live-only fields the
// guest screens need (availability, variants, 3D model, category name). Extending — rather
// than replacing — keeps the existing component contract intact while swapping the data source.
export interface MenuItemView extends MenuItem {
  available: boolean;
  hasVariants: boolean;
  variants: MenuItemVariantOverrideResponse[];
  modelUrl: string | null;
  categoryName: string;
  // The raw backend DTO, retained so consumers can route the nullable price through
  // priceLabel/displayPrice (the flattened `price` above is coerced to 0 for the
  // @halia/ui contract and must NOT be used for display).
  dto: GuestEffectiveMenuResponse;
}

// Map a live GuestEffectiveMenuResponse onto the @halia/ui MenuItem shape (plus live fields).
// Every absent field is given a safe default so no `undefined` leaks into JSX, and the price
// is routed through `displayPrice` (never NaN/₹null). Strings pass through unchanged — React
// escapes them on render, so no XSS surface is introduced here (T-02-05).
export function toMenuItem(dto: GuestEffectiveMenuResponse): MenuItemView {
  const tags = dto.tags ?? [];
  return {
    id: dto.menuItemId,
    cat: dto.categoryId ?? '',
    name: dto.name ?? '',
    desc: dto.description ?? '',
    price: displayPrice(dto) ?? 0,
    tags,
    time: dto.preparationTimeInMinutes ?? 0,
    hot: tags.includes('popular'),
    slot: dto.name ?? '',
    available: dto.available ?? true,
    hasVariants: dto.hasVariants ?? false,
    variants: dto.variants ?? [],
    modelUrl: dto.modelUrl ?? null,
    categoryName: dto.categoryName ?? 'Menu',
    dto,
  };
}

// Derive the category tabs from the aggregated items (there is no categories endpoint).
// Dedups by categoryId, accumulating a per-category count, and preserves first-appearance
// order (Pitfall 3). Output matches the @halia/ui Category shape { id, name, count } exactly,
// so the existing MenuPage category render needs no structural change.
export function deriveCategories(items: MenuItemView[]): Category[] {
  const map = new Map<string, { name: string; count: number }>();
  for (const it of items) {
    const prev = map.get(it.cat);
    map.set(it.cat, { name: it.categoryName, count: (prev?.count ?? 0) + 1 });
  }
  return [...map.entries()].map(([id, v]) => ({ id, name: v.name, count: v.count }));
}
