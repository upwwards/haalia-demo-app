import { describe, expect, it } from 'vitest';
import type { GuestEffectiveMenuResponse } from '../../api/types';
import { deriveCategories, toMenuItem } from './menuAdapter';

function dto(over: Partial<GuestEffectiveMenuResponse>): GuestEffectiveMenuResponse {
  return {
    menuItemId: 'item-1',
    name: 'Margherita',
    description: 'Tomato, mozzarella',
    primaryImageUrl: null,
    modelUrl: null,
    type: 'VEG',
    preparationTimeInMinutes: 12,
    categoryId: 'cat-mains',
    categoryName: 'Mains',
    price: 349,
    available: true,
    tags: ['popular'],
    hasVariants: false,
    variants: [],
    ...over,
  };
}

describe('toMenuItem (MENU-04)', () => {
  it('maps the core MenuItem fields from the live DTO', () => {
    const v = toMenuItem(dto({}));
    expect(v.id).toBe('item-1');
    expect(v.cat).toBe('cat-mains');
    expect(v.name).toBe('Margherita');
    expect(v.desc).toBe('Tomato, mozzarella');
    expect(v.price).toBe(349);
    expect(v.tags).toEqual(['popular']);
    expect(v.time).toBe(12);
    expect(v.hot).toBe(true); // tags includes 'popular'
    expect(v.slot).toBe('Margherita');
  });

  it('extends the view with the live-only fields', () => {
    const v = toMenuItem(
      dto({
        modelUrl: 'https://models.example/x.glb',
        categoryName: 'Mains',
        available: false,
        hasVariants: true,
        variants: [
          { variantId: 'a', label: '250g', effectivePrice: 180, displayOrder: 1, available: true, isOverridden: false },
        ],
        price: null,
      }),
    );
    expect(v.available).toBe(false);
    expect(v.hasVariants).toBe(true);
    expect(v.variants).toHaveLength(1);
    expect(v.modelUrl).toBe('https://models.example/x.glb');
    expect(v.categoryName).toBe('Mains');
    expect(v.price).toBe(180); // variant price routed through displayPrice
  });

  it('applies safe defaults for missing fields — no undefined leaks', () => {
    // Cast a sparse object to exercise the ?? defaults on absent fields.
    const sparse = { menuItemId: 'bare' } as unknown as GuestEffectiveMenuResponse;
    const v = toMenuItem(sparse);
    expect(v.id).toBe('bare');
    expect(v.cat).toBe('');
    expect(v.desc).toBe('');
    expect(v.tags).toEqual([]);
    expect(v.time).toBe(0);
    expect(v.available).toBe(true);
    expect(v.hot).toBe(false);
    expect(v.price).toBe(0);
    expect(Object.values(v).some((x) => x === undefined)).toBe(false);
  });
});

describe('deriveCategories (MENU-04, Pitfall 3)', () => {
  it('dedups by categoryId: two same-categoryId items yield one Category with count 2', () => {
    const items = [
      toMenuItem(dto({ menuItemId: 'a', categoryId: 'cat-mains', categoryName: 'Mains' })),
      toMenuItem(dto({ menuItemId: 'b', categoryId: 'cat-mains', categoryName: 'Mains' })),
    ];
    const cats = deriveCategories(items);
    expect(cats).toHaveLength(1);
    expect(cats[0]).toEqual({ id: 'cat-mains', name: 'Mains', count: 2 });
  });

  it('produces the @halia/ui Category shape { id, name, count } and preserves first-appearance order', () => {
    const items = [
      toMenuItem(dto({ menuItemId: 'a', categoryId: 'cat-mains', categoryName: 'Mains' })),
      toMenuItem(dto({ menuItemId: 'b', categoryId: 'cat-desserts', categoryName: 'Desserts' })),
      toMenuItem(dto({ menuItemId: 'c', categoryId: 'cat-mains', categoryName: 'Mains' })),
    ];
    const cats = deriveCategories(items);
    expect(cats).toEqual([
      { id: 'cat-mains', name: 'Mains', count: 2 },
      { id: 'cat-desserts', name: 'Desserts', count: 1 },
    ]);
    expect(Object.keys(cats[0]).sort()).toEqual(['count', 'id', 'name']);
  });
});
