import {
  createContext,
  useCallback,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { Icon } from '@halia/ui';

// ---------- Toast primitive (customer app) ----------
// Distilled from the dashboard's `useDash` toast slice (apps/dashboard/src/store.tsx:7-10,53-65,89-97,204-238).
// Toasts ONLY — no notifications panel, confirm dialog, or command palette (D-11, A4).
// Reusable by cart submit/write error paths (Phase 3), service requests (Phase 4),
// and the error-UX closeout (Phase 5).

export type ToastKind = 'info' | 'success' | 'warning' | 'danger';

export interface Toast {
  id: string;
  kind: ToastKind;
  title: string;
  body?: string;
}

export interface ToastState {
  toast(t: Omit<Toast, 'id'>): void;
  toasts: Toast[];
}

export const ToastCtx = createContext<ToastState | null>(null);

// Auto-dismiss timeout (ms). Carried verbatim from the dashboard pattern.
const AUTO_DISMISS_MS = 3500;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Source: store.tsx:59-65 — generate an id, append, schedule auto-dismiss.
  const toast = useCallback((t: Omit<Toast, 'id'>) => {
    const id = `t${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev, { ...t, id }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((x) => x.id !== id));
    }, AUTO_DISMISS_MS);
  }, []);

  const value = useMemo<ToastState>(() => ({ toast, toasts }), [toast, toasts]);

  return (
    <ToastCtx.Provider value={value}>
      {children}
      <Toaster toasts={toasts} />
    </ToastCtx.Provider>
  );
}

// ---------- Toaster tray ----------
// Ported verbatim from the dashboard's ToastTray (store.tsx:206-238): fixed-position
// shell, per-kind palette map, @halia/ui Icon, `card` class, --*-soft/--* CSS vars,
// and the haliaToastIn animation (all available via @halia/ui/theme.css).
// SECURITY (T-03-04): toast text is rendered as React children (auto-escaped); no
// dangerouslySetInnerHTML.
function Toaster({ toasts }: { toasts: Toast[] }) {
  if (!toasts.length) return null;
  const palette: Record<ToastKind, { bg: string; fg: string; icon: string }> = {
    info: { bg: 'var(--info-soft)', fg: 'var(--info)', icon: 'info' },
    success: { bg: 'var(--success-soft)', fg: 'var(--success)', icon: 'check' },
    warning: { bg: 'var(--warning-soft)', fg: 'var(--warning)', icon: 'alert' },
    danger: { bg: 'var(--danger-soft)', fg: 'var(--danger)', icon: 'alert' },
  };
  return (
    <div
      style={{
        position: 'fixed', right: 20, bottom: 20, zIndex: 300,
        display: 'flex', flexDirection: 'column', gap: 8,
        maxWidth: 360, pointerEvents: 'none',
      }}
    >
      {toasts.map((t) => {
        const p = palette[t.kind];
        return (
          <div
            key={t.id}
            className="card"
            style={{
              padding: '12px 14px', display: 'flex', gap: 12,
              boxShadow: 'var(--shadow-3)', pointerEvents: 'auto',
              animation: 'haliaToastIn .25s ease',
            }}
          >
            <div
              style={{
                width: 28, height: 28, borderRadius: 8, background: p.bg, color: p.fg,
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}
            >
              <Icon name={p.icon} size={15} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 540 }}>{t.title}</div>
              {t.body && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{t.body}</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}
