import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { act, render, renderHook, screen } from '@testing-library/react';
import type { ReactNode } from 'react';
import { ToastProvider } from './ToastProvider';
import { useToast } from './useToast';

// A tiny consumer that pushes a toast when its button is clicked.
function Pusher() {
  const { toast } = useToast();
  return (
    <button onClick={() => toast({ kind: 'danger', title: 'Could not update your cart' })}>
      push
    </button>
  );
}

function wrapper({ children }: { children: ReactNode }) {
  return <ToastProvider>{children}</ToastProvider>;
}

describe('ToastProvider / useToast (D-11)', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });
  afterEach(() => {
    vi.runOnlyPendingTimers();
    vi.useRealTimers();
  });

  it('renders the toast title in the tray after toast() is called', () => {
    render(<Pusher />, { wrapper });
    expect(screen.queryByText('Could not update your cart')).toBeNull();

    act(() => {
      screen.getByRole('button', { name: 'push' }).click();
    });

    expect(screen.getByText('Could not update your cart')).toBeInTheDocument();
  });

  it('auto-dismisses the toast after the timeout elapses', () => {
    render(<Pusher />, { wrapper });

    act(() => {
      screen.getByRole('button', { name: 'push' }).click();
    });
    expect(screen.getByText('Could not update your cart')).toBeInTheDocument();

    // Advance past the ~3500ms auto-dismiss window.
    act(() => {
      vi.advanceTimersByTime(4000);
    });

    expect(screen.queryByText('Could not update your cart')).toBeNull();
  });

  it('useToast throws when used outside <ToastProvider>', () => {
    expect(() => renderHook(() => useToast())).toThrow(
      'useToast must be used inside <ToastProvider>',
    );
  });
});
