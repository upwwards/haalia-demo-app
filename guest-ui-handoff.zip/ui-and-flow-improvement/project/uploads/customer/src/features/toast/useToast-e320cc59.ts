import { useContext } from 'react';
import { ToastCtx, type ToastState } from './ToastProvider';

export function useToast(): ToastState {
  const v = useContext(ToastCtx);
  if (!v) throw new Error('useToast must be used inside <ToastProvider>');
  return v;
}
