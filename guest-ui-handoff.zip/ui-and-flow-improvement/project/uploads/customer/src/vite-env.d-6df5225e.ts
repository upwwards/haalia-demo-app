/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE_URL?: string;
  readonly VITE_API_MOCKING?: string;
  readonly VITE_GUEST_CLIENT_ID?: string;
  readonly VITE_GUEST_CLIENT_SECRET?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

// Test-only hook: set ONLY behind config.mocking (main.tsx) so Playwright can drive
// deterministic STOMP frames into the app. Never present in a production build.
interface Window {
  __stompPush?: (
    dest: string,
    frame: { destination: string; data: unknown },
  ) => void;
}
