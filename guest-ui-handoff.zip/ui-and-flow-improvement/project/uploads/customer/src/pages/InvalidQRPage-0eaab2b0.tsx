import { useNavigate } from 'react-router-dom';
import { Icon } from '@halia/ui';

export function InvalidQRPage() {
  const navigate = useNavigate();
  return (
    <>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 28, textAlign: 'center' }}>
        <div>
          <div
            style={{
              width: 80, height: 80, borderRadius: 40, background: 'var(--danger-soft)',
              color: 'var(--danger)', display: 'flex', alignItems: 'center', justifyContent: 'center',
              margin: '0 auto 20px',
            }}
          >
            <Icon name="alert" size={36} />
          </div>
          <div className="serif" style={{ fontSize: 28, lineHeight: 1.1, marginBottom: 10 }}>
            This table isn't <span className="serif-i" style={{ color: 'var(--brand)' }}>available</span> right now
          </div>
          <div style={{ fontSize: 14, color: 'var(--text-muted)', lineHeight: 1.5, marginBottom: 24 }}>
            The QR you scanned is for a table that's been disabled or removed. Ask a server to seat you at an active table.
          </div>
          <div className="card" style={{ padding: 14, textAlign: 'left', marginBottom: 22, background: 'var(--surface-2)', borderColor: 'transparent' }}>
            <div className="label" style={{ marginBottom: 6 }}>Error details</div>
            <div className="mono" style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>
              code: HTTP 403
              <br />
              venue_id: verbena-dt
              <br />
              location_id: T17
              <br />
              reason: location_inactive
            </div>
          </div>
          <button onClick={() => navigate('/welcome')} className="btn btn-primary btn-lg btn-block" style={{ marginBottom: 8 }}>
            Try again
          </button>
          <button className="btn btn-ghost btn-block">
            <Icon name="waiter" size={14} /> Call a server
          </button>
        </div>
      </div>
    </>
  );
}
