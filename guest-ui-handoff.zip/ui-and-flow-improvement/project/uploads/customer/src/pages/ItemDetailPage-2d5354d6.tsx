import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Icon, ImageSlot } from '@halia/ui';
import { getMenuItem } from '../api/endpoints/menu';
import { ApiError } from '../api/ApiError';
import { useVenue } from '../features/venue/useVenue';
import { useCart } from '../features/cart/useCart';
import type { GuestEffectiveMenuResponse } from '../api/types';
import { priceLabel } from '../features/menu/price';

type DetailStatus = 'loading' | 'ready' | 'error';

// ₹ formatter for a concrete numeric price (variant effectivePrice), null-safe.
function money(p: number | null): string {
  return p === null ? 'Unavailable' : `₹${p.toFixed(2)}`;
}

export function ItemDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { hasFeature } = useVenue();
  const { add } = useCart();

  const [item, setItem] = useState<GuestEffectiveMenuResponse | null>(null);
  const [status, setStatus] = useState<DetailStatus>('loading');
  const [error, setError] = useState<ApiError | null>(null);
  const [variant, setVariant] = useState<string>('');
  const [qty, setQty] = useState(1);
  const [notes, setNotes] = useState('');

  // Fetch the single item by itemId. A 404 (bad/wrong-venue id) surfaces an error state,
  // never a crash (T-02-15). `cancelled` guards setState-after-unmount under StrictMode.
  useEffect(() => {
    if (!id) return;
    let cancelled = false;
    setStatus('loading');
    setError(null);
    getMenuItem(id)
      .then((dto) => {
        if (cancelled) return;
        setItem(dto);
        // Default to the first available variant (if any) for selection.
        const firstAvail = (dto.variants ?? []).find((v) => v.available !== false);
        setVariant(firstAvail?.variantId ?? '');
        setStatus('ready');
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        setError(e instanceof ApiError ? e : new ApiError(0, String(e)));
        setStatus('error');
      });
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (status === 'loading') {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-faint)', fontSize: 14 }}>
        Loading item…
      </div>
    );
  }

  if (status === 'error' || !item) {
    return (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 14, padding: 24 }}>
        <div style={{ color: 'var(--danger)', fontSize: 15, textAlign: 'center' }}>
          {/* User-safe copy off ApiError.status — never leaks the token/raw internals (T-02-16). */}
          We couldn't load this item{error?.status ? ` (error ${error.status})` : ''}.
        </div>
        <button className="btn btn-primary" onClick={() => navigate('/menu')}>Back to menu</button>
      </div>
    );
  }

  const variants = item.variants ?? [];
  const canOrder = hasFeature('ORDER_PLACEMENT');
  // 3D/AR affordance shows ONLY when the feature is enabled AND the item has a model URL
  // (A5: show/hide the affordance, do NOT build a viewer).
  const show3d = hasFeature('MODEL_3D') && !!item.modelUrl;

  // Total/label routed through the price layer in ₹ — never NaN/$ deltas. For a variant item
  // the selected variant's effectivePrice drives the total; otherwise the base price label.
  const selected = variants.find((v) => v.variantId === variant);
  const unitPrice = item.hasVariants ? selected?.effectivePrice ?? null : item.price;
  const totalLabel =
    unitPrice === null ? priceLabel(item) : `₹${(unitPrice * qty).toFixed(2)}`;

  // Real cart write (D-04): pass the selected variantId for variant items, undefined otherwise.
  // The shared cart's `add` increments by one; call it once per chosen quantity, then route to
  // the cart so the guest can review the optimistic line + server total.
  const onAddToOrder = () => {
    const variantId = item.hasVariants ? variant || undefined : undefined;
    const note = notes.trim() || undefined;
    for (let i = 0; i < qty; i++) add(item.menuItemId, variantId, note);
    navigate('/cart');
  };

  return (
    <>
      <div style={{ position: 'relative', height: 320, flexShrink: 0 }}>
        <ImageSlot placeholder={item.name} radius={0} />
        <div style={{ position: 'absolute', top: 56, left: 16, right: 16, display: 'flex', justifyContent: 'space-between' }}>
          <button
            onClick={() => navigate(-1)}
            className="icon-btn"
            style={{ background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)', color: 'var(--text)' }}
          >
            <Icon name="arrowLeft" size={16} />
          </button>
          <div style={{ display: 'flex', gap: 6 }}>
            {show3d && (
              <button
                aria-label="View in 3D / AR"
                className="icon-btn"
                style={{ background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)', color: 'var(--text)' }}
              >
                <Icon name="cube" size={16} />
              </button>
            )}
            <button className="icon-btn" style={{ background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)', color: 'var(--text)' }}>
              <Icon name="bookmark" size={16} />
            </button>
          </div>
        </div>
        <div style={{ position: 'absolute', bottom: 14, left: 16, display: 'flex', gap: 6 }}>
          {show3d && (
            <span className="pill" style={{ background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)', borderColor: 'transparent' }}>
              <Icon name="cube" size={11} /> 3D · AR
            </span>
          )}
          {item.tags?.includes('popular') && (
            <span className="pill" style={{ background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)', borderColor: 'transparent' }}>
              <Icon name="fire" size={11} style={{ color: 'var(--brand)' }} /> Popular
            </span>
          )}
        </div>
      </div>
      <div className="scroll-y" style={{ flex: 1, padding: '20px 20px 200px' }}>
        <div className="serif" style={{ fontSize: 30, lineHeight: 1.05, marginBottom: 6 }}>{item.name}</div>
        <div style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 14, lineHeight: 1.45 }}>
          {item.description}
        </div>
        <div style={{ display: 'flex', gap: 16, marginBottom: 22, fontSize: 13, color: 'var(--text-muted)' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
            <Icon name="clock" size={13} /> ~{item.preparationTimeInMinutes} min
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
            <Icon name="leaf" size={13} style={{ color: item.type === 'VEG' ? 'var(--success)' : 'var(--brand)' }} />
            {item.type === 'VEG' ? 'Veg' : 'Non-veg'}
          </span>
          {item.calories != null && (
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
              <Icon name="flame" size={13} /> {item.calories} kcal
            </span>
          )}
        </div>

        {/* Live variant list (replaces the hardcoded ribeye sizes). ₹ via priceLabel/effectivePrice. */}
        {variants.length > 0 && (
          <>
            <div className="label" style={{ marginBottom: 10 }}>Options</div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 22, flexWrap: 'wrap' }}>
              {variants.map((v) => {
                const soldOut = v.available === false;
                return (
                  <button
                    key={v.variantId}
                    disabled={soldOut}
                    onClick={() => !soldOut && setVariant(v.variantId)}
                    style={{
                      flex: '1 1 30%', padding: '12px 8px', borderRadius: 10,
                      border: `1.5px solid ${variant === v.variantId ? 'var(--brand)' : 'var(--hairline)'}`,
                      background: variant === v.variantId ? 'var(--brand-tint)' : 'var(--surface)',
                      cursor: soldOut ? 'not-allowed' : 'pointer', fontFamily: 'inherit',
                      color: 'var(--text)', textAlign: 'left', opacity: soldOut ? 0.5 : 1,
                    }}
                  >
                    <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 2 }}>{v.label}</div>
                    <div style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>
                      {money(v.effectivePrice)}{soldOut ? ' · sold out' : ''}
                    </div>
                  </button>
                );
              })}
            </div>
          </>
        )}

        {/* Special instructions — free-text note sent with the cart line (e.g. doneness, allergies). */}
        {canOrder && (
          <div style={{ marginBottom: 22 }}>
            <div className="label" style={{ marginBottom: 10 }}>Special instructions</div>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="No salt, allergy notes, plating preferences…"
              maxLength={200}
              rows={3}
              className="input"
              style={{ width: '100%', resize: 'none', fontFamily: 'inherit', fontSize: 14, padding: 12, background: 'var(--surface-2)', borderColor: 'transparent' }}
            />
          </div>
        )}
      </div>
      <div
        style={{
          position: 'absolute', left: 0, right: 0, bottom: 0, background: 'var(--surface)',
          borderTop: '1px solid var(--hairline)', padding: '14px 20px 22px',
          display: 'flex', alignItems: 'center', gap: 12,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, border: '1px solid var(--hairline-strong)', borderRadius: 999, padding: 4 }}>
          <button onClick={() => setQty(Math.max(1, qty - 1))} style={{ width: 32, height: 32, border: 0, background: 'transparent', cursor: 'pointer', color: 'var(--text)' }}>
            <Icon name="minus" size={14} />
          </button>
          <span style={{ fontSize: 14, fontWeight: 600, minWidth: 14, textAlign: 'center' }}>{qty}</span>
          <button onClick={() => setQty(qty + 1)} style={{ width: 32, height: 32, border: 0, background: 'transparent', cursor: 'pointer', color: 'var(--text)' }}>
            <Icon name="plus" size={14} />
          </button>
        </div>
        {/* Order entry point is gated on ORDER_PLACEMENT (cart writes are Phase 3). */}
        {canOrder ? (
          <button className="btn btn-primary btn-lg" style={{ flex: 1 }} onClick={onAddToOrder}>
            Add to order · {totalLabel}
          </button>
        ) : (
          <div style={{ flex: 1, textAlign: 'center', fontSize: 14, fontWeight: 600, color: 'var(--text-muted)' }}>
            {totalLabel}
          </div>
        )}
      </div>
    </>
  );
}
