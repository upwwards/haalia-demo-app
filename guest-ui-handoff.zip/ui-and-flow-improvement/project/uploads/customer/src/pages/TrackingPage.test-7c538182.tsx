import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { MemoryRouter, Route, Routes, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import { server } from '../test/server';
import { errorHandlers } from '../test/handlers';
import type { GuestLoginRequest, OrderResponse } from '../api/types';
import { SessionProvider } from '../features/session/SessionProvider';
import { useSession } from '../features/session/useSession';
import { VenueProvider } from '../features/venue/VenueProvider';
import { ToastProvider } from '../features/toast/ToastProvider';
import { CartProvider } from '../features/cart/CartProvider';
import { OrdersProvider } from '../features/orders/OrdersProvider';
import { TrackingPage } from './TrackingPage';

const QR: GuestLoginRequest = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'venue-1',
  serviceLocationId: 'loc-1',
};

function AuthGate({ children }: { children: ReactNode }) {
  const { token, authenticate } = useSession();
  if (!token) void authenticate(QR);
  return <>{children}</>;
}

// Surfaces the current pathname so navigate-on-success / stay-on-screen can be asserted.
function LocationProbe() {
  const loc = useLocation();
  return <div data-testid="pathname">{loc.pathname}</div>;
}

function renderTracking() {
  return render(
    <MemoryRouter initialEntries={['/track']}>
      <SessionProvider>
        <VenueProvider>
          <ToastProvider>
            <CartProvider>
              <OrdersProvider>
                <AuthGate>
                  <Routes>
                    <Route path="/track" element={<TrackingPage />} />
                    {/* Stub destination so a successful checkout navigation is observable. */}
                    <Route path="/checkout" element={<div>checkout-screen</div>} />
                    <Route path="*" element={<TrackingPage />} />
                  </Routes>
                  <LocationProbe />
                </AuthGate>
              </OrdersProvider>
            </CartProvider>
          </ToastProvider>
        </VenueProvider>
      </SessionProvider>
    </MemoryRouter>,
  );
}

// Records {method, path} for every outbound request so single-submit assertions read real calls.
function spyRequests() {
  const calls: { method: string; path: string }[] = [];
  const listener = ({ request }: { request: Request }) => {
    calls.push({ method: request.method, path: new URL(request.url).pathname });
  };
  server.events.on('request:start', listener);
  return {
    matching: (method: string, re: RegExp) =>
      calls.filter((c) => c.method === method && re.test(c.path)),
    stop: () => server.events.removeListener('request:start', listener),
  };
}

beforeEach(() => sessionStorage.clear());
afterEach(() => {
  sessionStorage.clear();
  server.events.removeAllListeners();
});

describe('TrackingPage (ORDER-02)', () => {
  it('renders live order history: orderNumber, items, and the server totalPrice', async () => {
    const { container } = renderTracking();
    // Default GET /orders handler: order #1042, PREPARING, one line (2× Margherita), total 698.
    await waitFor(() => expect(screen.getByText('#1042')).toBeInTheDocument());
    expect(screen.getByText(/Margherita Pizza/)).toBeInTheDocument();
    // 698 is both the single line itemTotal and the order total here → appears twice.
    expect(screen.getAllByText('₹698.00').length).toBeGreaterThan(0);
    // Server money only — no $/NaN/₹null.
    expect(container.textContent).not.toContain('$');
    expect(container.textContent).not.toMatch(/NaN/);
    expect(container.textContent).not.toMatch(/₹null/);
  });

  it('maps the live OrderStatus enum onto the display step (PREPARING → Preparing)', async () => {
    renderTracking();
    // The default order is PREPARING → the active stage label is "Preparing".
    await waitFor(() => expect(screen.getByText('#1042')).toBeInTheDocument());
    // Stage label in the header reflects the mapped step.
    expect(screen.getAllByText('Preparing').length).toBeGreaterThan(0);
  });

  it('renders an order item variantLabel when the line carries one', async () => {
    const order: OrderResponse = {
      id: 'order-9',
      orderNumber: 2001,
      venueId: 'venue-1',
      serviceLocationId: 'loc-1',
      locationName: 'Table 12',
      serviceSessionId: 'session-1',
      status: 'READY',
      source: 'GUEST',
      notes: '',
      totalPrice: 320,
      orderItems: [
        {
          id: 'oi-9',
          menuItemId: 'item-2',
          itemName: 'Ribeye Steak',
          categoryName: 'Mains',
          variantLabel: '500g',
          itemPrice: 320,
          quantity: 1,
          itemTotal: 320,
        },
      ],
      created: '',
      placedAt: '',
      confirmedAt: '',
      preparingAt: '',
      readyAt: '',
      deliveredAt: '',
      assignedWaiterId: '',
      assignedWaiterName: '',
      allergyFlag: false,
      allergyNote: '',
      priorityFlag: '',
      priorityNote: '',
    };
    server.use(
      http.get('*/api/v1/guest/orders/:sessionId', () => HttpResponse.json([order])),
    );
    renderTracking();
    await waitFor(() => expect(screen.getByText('#2001')).toBeInTheDocument());
    expect(screen.getByText(/500g/)).toBeInTheDocument();
    // READY status maps to the "Ready" step.
    expect(screen.getAllByText('Ready').length).toBeGreaterThan(0);
  });

  it('shows an error state when the orders fetch 404s (no token leak)', async () => {
    server.use(errorHandlers.notFoundGet('/guest/orders/:sessionId'));
    const { container } = renderTracking();
    await waitFor(() =>
      expect(screen.getByText(/couldn't load your order/i)).toBeInTheDocument(),
    );
    expect(screen.queryByText('#1042')).not.toBeInTheDocument();
    expect(container.textContent).not.toMatch(/eyJ/);
  });

  it('shows an empty state when there are no orders', async () => {
    server.use(
      http.get('*/api/v1/guest/orders/:sessionId', () =>
        HttpResponse.json([] satisfies OrderResponse[]),
      ),
    );
    renderTracking();
    await waitFor(() => expect(screen.getByText(/no orders yet/i)).toBeInTheDocument());
    expect(screen.queryByText('#1042')).not.toBeInTheDocument();
  });
});

describe('TrackingPage checkout (SESS-01)', () => {
  const CHECKOUT_PATH = '/guest/service-sessions/:sessionId/checkout';

  it('requires a two-step inline confirm before any checkout POST fires', async () => {
    const user = userEvent.setup();
    const spy = spyRequests();
    renderTracking();
    await waitFor(() => expect(screen.getByText('#1042')).toBeInTheDocument());

    // First tap only reveals the confirm affordance — NO POST yet.
    await user.click(screen.getByRole('button', { name: /close the bill/i }));
    expect(screen.getByRole('button', { name: /confirm — this closes your table/i })).toBeInTheDocument();
    expect(spy.matching('POST', /\/checkout$/)).toHaveLength(0);

    spy.stop();
  });

  it('confirming with the happy handler navigates to /checkout', async () => {
    const user = userEvent.setup();
    renderTracking();
    await waitFor(() => expect(screen.getByText('#1042')).toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: /close the bill/i }));
    await user.click(screen.getByRole('button', { name: /confirm — this closes your table/i }));

    await waitFor(() => expect(screen.getByText('checkout-screen')).toBeInTheDocument());
    expect(screen.getByTestId('pathname').textContent).toBe('/checkout');
  });

  it('confirming with a 404 shows a toast and does NOT navigate', async () => {
    server.use(errorHandlers.notFoundPost(CHECKOUT_PATH));
    const user = userEvent.setup();
    renderTracking();
    await waitFor(() => expect(screen.getByText('#1042')).toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: /close the bill/i }));
    await user.click(screen.getByRole('button', { name: /confirm — this closes your table/i }));

    await waitFor(() => expect(screen.getByText(/couldn't close your table/i)).toBeInTheDocument());
    expect(screen.queryByText('checkout-screen')).not.toBeInTheDocument();
    expect(screen.getByTestId('pathname').textContent).toBe('/track');
  });

  it('confirming with a 403 shows a toast and does NOT navigate', async () => {
    server.use(errorHandlers.forbiddenPost(CHECKOUT_PATH));
    const user = userEvent.setup();
    renderTracking();
    await waitFor(() => expect(screen.getByText('#1042')).toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: /close the bill/i }));
    await user.click(screen.getByRole('button', { name: /confirm — this closes your table/i }));

    await waitFor(() => expect(screen.getByText(/couldn't close your table/i)).toBeInTheDocument());
    expect(screen.queryByText('checkout-screen')).not.toBeInTheDocument();
    expect(screen.getByTestId('pathname').textContent).toBe('/track');
  });

  it('guards double-submit: two taps during the in-flight checkout issue a single POST', async () => {
    const user = userEvent.setup();
    const spy = spyRequests();
    renderTracking();
    await waitFor(() => expect(screen.getByText('#1042')).toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: /close the bill/i }));
    const confirm = screen.getByRole('button', { name: /confirm — this closes your table/i });
    // Fire two confirm clicks back-to-back; the in-flight guard collapses them to one POST.
    await user.click(confirm);
    await user.click(confirm);

    await waitFor(() => expect(screen.getByText('checkout-screen')).toBeInTheDocument());
    expect(spy.matching('POST', /\/checkout$/)).toHaveLength(1);
    spy.stop();
  });

  it('when the session is CLOSED, add-to-order + checkout are gated off while history still renders', async () => {
    // Harness that closes the session via checkout() WITHOUT navigating, so TrackingPage stays
    // mounted and re-renders in its read-only (closed) state.
    function CloseSessionGate({ children }: { children: ReactNode }) {
      const { token, closed, checkout } = useSession();
      if (token && !closed) void checkout();
      return <>{children}</>;
    }

    render(
      <MemoryRouter initialEntries={['/track']}>
        <SessionProvider>
          <VenueProvider>
            <ToastProvider>
              <CartProvider>
                <OrdersProvider>
                  <AuthGate>
                    <CloseSessionGate>
                      <Routes>
                        <Route path="*" element={<TrackingPage />} />
                      </Routes>
                    </CloseSessionGate>
                  </AuthGate>
                </OrdersProvider>
              </CartProvider>
            </ToastProvider>
          </VenueProvider>
        </SessionProvider>
      </MemoryRouter>,
    );

    // Order history still renders (read-only review stays available, D-11).
    await waitFor(() => expect(screen.getByText('#1042')).toBeInTheDocument());
    // The closed banner appears and the action controls are gone.
    await waitFor(() => expect(screen.getByTestId('track-closed')).toBeInTheDocument());
    expect(screen.queryByRole('button', { name: /add to order/i })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /close the bill/i })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /confirm — this closes your table/i })).not.toBeInTheDocument();
  });
});
