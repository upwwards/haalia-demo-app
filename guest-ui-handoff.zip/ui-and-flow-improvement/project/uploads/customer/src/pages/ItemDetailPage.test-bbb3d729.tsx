import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http as mswHttp, HttpResponse } from 'msw';
import { MemoryRouter, Navigate, Route, Routes, useParams } from 'react-router-dom';
import type { ReactNode } from 'react';
import { server } from '../test/server';
import { errorHandlers } from '../test/handlers';
import type {
  Feature,
  GuestEffectiveMenuResponse,
  GuestLoginRequest,
} from '../api/types';
import { SessionProvider } from '../features/session/SessionProvider';
import { useSession } from '../features/session/useSession';
import { VenueProvider } from '../features/venue/VenueProvider';
import { ToastProvider } from '../features/toast/ToastProvider';
import { CartProvider } from '../features/cart/CartProvider';
import { useCart } from '../features/cart/useCart';
import { ItemDetailPage } from './ItemDetailPage';

const QR: GuestLoginRequest = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'venue-1',
  serviceLocationId: 'loc-1',
};

// Fires authenticate() on mount so the venue features load (gates depend on them).
function AuthGate({ children }: { children: ReactNode }) {
  const { token, authenticate } = useSession();
  if (!token) void authenticate(QR);
  return <>{children}</>;
}

// Render the detail page at /menu/:id within the provider tree. `initialEntry` lets the
// redirect test enter at /menu/:id/variants instead.
// Cart destination probe: ItemDetailPage navigates to /cart after a real add. This route
// surfaces the shared cart's lines (menuItemId::variantId × quantity) so the add-writes test
// can assert the cart actually received the selected line — not just that we navigated.
function CartProbe() {
  const { lines, count } = useCart();
  return (
    <div data-testid="cart-probe">
      {count}|{lines.map((l) => `${l.menuItemId}::${l.variantId ?? ''}x${l.quantity}`).join(',')}
    </div>
  );
}

function renderAt(initialEntry: string) {
  return render(
    <MemoryRouter initialEntries={[initialEntry]}>
      <SessionProvider>
        <VenueProvider>
          <ToastProvider>
            <CartProvider>
              <AuthGate>
                <Routes>
                  <Route path="/menu/:id" element={<ItemDetailPage />} />
                  {/* Mirror App.tsx: the folded variants route redirects into the detail page. */}
                  <Route path="/menu/:id/variants" element={<NavigateToDetail />} />
                  <Route path="/cart" element={<CartProbe />} />
                </Routes>
              </AuthGate>
            </CartProvider>
          </ToastProvider>
        </VenueProvider>
      </SessionProvider>
    </MemoryRouter>,
  );
}

// Local mirror of App.tsx's MenuVariantsRedirect for the folded variants route.
function NavigateToDetail() {
  const { id } = useParams<{ id: string }>();
  return <Navigate to={id ? `/menu/${id}` : '/menu'} replace />;
}

beforeEach(() => sessionStorage.clear());
afterEach(() => sessionStorage.clear());

describe('ItemDetailPage (MENU-01/04)', () => {
  it('fetches the item and renders the live variant labels (not hardcoded ribeye sizes)', async () => {
    renderAt('/menu/item-2');
    // Live variant labels from the MSW variantItem fixture.
    await waitFor(() => expect(screen.getByText('250g')).toBeInTheDocument());
    expect(screen.getByText('500g')).toBeInTheDocument();
    // The old hardcoded ribeye sizes must NOT appear.
    expect(screen.queryByText('10oz')).not.toBeInTheDocument();
    expect(screen.queryByText('16oz')).not.toBeInTheDocument();
  });

  it('renders variant prices in ₹ via the price layer — no $ / NaN / ₹null', async () => {
    const { container } = renderAt('/menu/item-2');
    await waitFor(() => expect(screen.getByText('250g')).toBeInTheDocument());
    // ₹180.00 appears in the variant button and the order total — both must be ₹-formatted.
    expect(screen.getAllByText('₹180.00').length).toBeGreaterThan(0);
    expect(container.textContent).not.toContain('$');
    expect(container.textContent).not.toMatch(/NaN/);
    expect(container.textContent).not.toMatch(/₹null/);
  });

  it('shows the 3D/AR affordance when MODEL_3D is enabled AND the item has a modelUrl', async () => {
    // Default MSW: features include MODEL_3D and variantItem has a modelUrl.
    renderAt('/menu/item-2');
    await waitFor(() => expect(screen.getByLabelText(/view in 3d/i)).toBeInTheDocument());
    expect(screen.getByText('3D · AR')).toBeInTheDocument();
  });

  it('hides the 3D/AR affordance when MODEL_3D is disabled (even with a modelUrl)', async () => {
    server.use(
      mswHttp.get('*/api/v1/guest/venue/features', () =>
        HttpResponse.json(['ORDER_PLACEMENT'] satisfies Feature[]),
      ),
    );
    renderAt('/menu/item-2');
    await waitFor(() => expect(screen.getByText('250g')).toBeInTheDocument());
    expect(screen.queryByLabelText(/view in 3d/i)).not.toBeInTheDocument();
    expect(screen.queryByText('3D · AR')).not.toBeInTheDocument();
  });

  it('hides the 3D/AR affordance when the item has no modelUrl (even with MODEL_3D on)', async () => {
    const noModel: GuestEffectiveMenuResponse = {
      menuItemId: 'item-9',
      name: 'No-Model Dish',
      description: 'Flat item',
      primaryImageUrl: null,
      modelUrl: null,
      type: 'VEG',
      preparationTimeInMinutes: 10,
      categoryId: 'cat-mains',
      categoryName: 'Mains',
      price: 200,
      available: true,
      tags: [],
      hasVariants: false,
      variants: [],
    };
    server.use(
      mswHttp.get('*/api/v1/guest/menu/item/:itemId', () => HttpResponse.json(noModel)),
    );
    renderAt('/menu/item-9');
    await waitFor(() => expect(screen.getAllByText('No-Model Dish').length).toBeGreaterThan(0));
    expect(screen.queryByText('3D · AR')).not.toBeInTheDocument();
  });

  it('gates the "Add to order" entry point on ORDER_PLACEMENT', async () => {
    server.use(
      mswHttp.get('*/api/v1/guest/venue/features', () =>
        HttpResponse.json([] satisfies Feature[]),
      ),
    );
    renderAt('/menu/item-2');
    await waitFor(() => expect(screen.getByText('250g')).toBeInTheDocument());
    expect(screen.queryByRole('button', { name: /add to order/i })).not.toBeInTheDocument();
  });

  it('performs a real cart add with the selected variantId and routes to /cart (D-04)', async () => {
    const user = userEvent.setup();
    renderAt('/menu/item-2');
    // Select the 500g variant (var-2), then add to order.
    await waitFor(() => expect(screen.getByText('500g')).toBeInTheDocument());
    await user.click(screen.getByText('500g'));
    await user.click(screen.getByRole('button', { name: /add to order/i }));
    // Navigated to /cart AND the shared cart received item-2 with the selected variant var-2.
    await waitFor(() => expect(screen.getByTestId('cart-probe')).toBeInTheDocument());
    expect(screen.getByTestId('cart-probe').textContent).toContain('item-2::var-2x1');
  });

  it('shows an error state on a 404 from /menu/item/:itemId (no crash, no token leak)', async () => {
    server.use(errorHandlers.notFoundGet('/guest/menu/item/:itemId'));
    const { container } = renderAt('/menu/item-missing');
    await waitFor(() =>
      expect(screen.getByText(/couldn't load this item/i)).toBeInTheDocument(),
    );
    expect(container.textContent).not.toMatch(/eyJ/);
  });

  it('redirects /menu/:id/variants to the live ItemDetailPage variant view (folded)', async () => {
    renderAt('/menu/item-2/variants');
    // The redirect lands on ItemDetailPage, which renders the LIVE variants…
    await waitFor(() => expect(screen.getByText('250g')).toBeInTheDocument());
    // …and never the old hardcoded ribeye screen.
    expect(screen.queryByText('16oz')).not.toBeInTheDocument();
    expect(screen.queryByText(/well-done/i)).not.toBeInTheDocument();
  });
});
