import { useNavigate } from 'react-router-dom';
import { Icon, HaliaLogo } from '@halia/ui';
import { useSession } from '../features/session/useSession';
import { useVenue } from '../features/venue/useVenue';

export function CheckoutPage() {
  const navigate = useNavigate();
  // Server checkout summary, rendered verbatim — never a client-computed total (D-09).
  const { checkoutSummary } = useSession();
  // Real table identity from the JWT-bound location (matches the reference's table line).
  const { location } = useVenue();

  // Null-guard so a direct nav (no prior checkout) never renders NaN / ₹null (D-09).
  const totalOrders = checkoutSummary?.totalOrders ?? 0;
  // Mirror CartPage's `'₹' + (total ?? 0).toFixed(2)` convention — ₹, never $.
  const totalSpentLabel = '₹' + (checkoutSummary?.totalSpent ?? 0).toFixed(2);

  return (
    <>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '24px 28px', alignItems: 'center', textAlign: 'center', justifyContent: 'center' }}>
        <div
          style={{
            width: 84, height: 84, borderRadius: 42, background: 'var(--brand-soft)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: 28, color: 'var(--brand-deep)',
          }}
        >
          <Icon name="check" size={36} sw={2} />
        </div>
        <div className="serif" style={{ fontSize: 44, lineHeight: 1, marginBottom: 14 }}>
          Thank you<span className="serif-i" style={{ color: 'var(--brand)' }}>.</span>
        </div>
        <div style={{ fontSize: 15, color: 'var(--text-muted)', lineHeight: 1.5, maxWidth: 280, marginBottom: 36 }}>
          Your bill is settled and the table is closed. We hope to see you again soon.
        </div>

        {/* Server totals only — totalOrders (count) + totalSpent (₹), rendered verbatim (D-09).
            All values are React children (auto-escaped, T-04-03); no client-side math. */}
        <div className="card" style={{ width: '100%', padding: 18, marginBottom: 20, textAlign: 'left' }}>
          {location?.name && (
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Table</span>
              <span style={{ fontSize: 12.5 }} data-testid="checkout-table">{location.name}</span>
            </div>
          )}
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
            <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Orders</span>
            <span style={{ fontSize: 12.5 }} data-testid="checkout-total-orders">
              {totalOrders} {totalOrders === 1 ? 'order' : 'orders'}
            </span>
          </div>
          <hr className="hr" style={{ margin: '10px 0' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Total paid</span>
            <span style={{ fontSize: 14, fontWeight: 600 }} data-testid="checkout-total-spent">
              {totalSpentLabel}
            </span>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, width: '100%' }}>
          <button className="btn btn-ghost btn-block" onClick={() => navigate('/welcome')}>
            Start a new session
          </button>
        </div>
        <div style={{ marginTop: 28, fontSize: 11.5, color: 'var(--text-faint)' }}>
          <HaliaLogo size={14} />
        </div>
      </div>
    </>
  );
}
