import { useNavigate } from 'react-router-dom';
import { Icon, MENU } from '@halia/ui';

export function SessionExpiredPage() {
  const navigate = useNavigate();
  return (
    <>
      <div style={{ padding: '18px 18px 80px', filter: 'blur(2px) saturate(0.6)', opacity: 0.4, pointerEvents: 'none' }}>
        <div className="serif" style={{ fontSize: 28, marginBottom: 16 }}>Mains</div>
        {MENU.slice(3, 6).map((m) => (
          <div key={m.id} className="card" style={{ padding: 14, marginBottom: 12, display: 'flex', gap: 12 }}>
            <div className="img-ph" style={{ width: 72, height: 72, borderRadius: 8 }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600 }}>{m.name}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{m.desc}</div>
            </div>
          </div>
        ))}
      </div>
      <div
        style={{
          position: 'absolute', inset: 0, background: 'rgba(20, 18, 14, 0.5)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 22,
        }}
      >
        <div className="card" style={{ padding: 28, textAlign: 'center', maxWidth: 320 }}>
          <div
            style={{
              width: 56, height: 56, borderRadius: 28, background: 'var(--warning-soft)',
              color: 'var(--warning)', display: 'flex', alignItems: 'center', justifyContent: 'center',
              margin: '0 auto 16px',
            }}
          >
            <Icon name="clock" size={26} />
          </div>
          <div className="serif" style={{ fontSize: 22, lineHeight: 1.2, marginBottom: 8 }}>Session expired</div>
          <div style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.5, marginBottom: 20 }}>
            For your security, table sessions close after 4 hours. Scan the table's QR again to reopen.
          </div>
          <button onClick={() => navigate('/welcome')} className="btn btn-primary btn-lg btn-block" style={{ marginBottom: 8 }}>
            <Icon name="qr" size={14} /> Scan QR again
          </button>
          <button className="btn btn-quiet btn-block" style={{ fontSize: 12 }}>
            Close browser
          </button>
        </div>
      </div>
    </>
  );
}
