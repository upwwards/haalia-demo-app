import { Navigate, useParams } from 'react-router-dom';

// FOLDED into ItemDetailPage (Plan 02-04). The full live variant list now renders on the
// item detail screen, so this screen's previous hardcoded sizes/price deltas were pure
// duplication and have been removed. This component is no longer routed by App.tsx (the
// /menu/:id/variants route redirects to /menu/:id). It is kept only as a defensive no-op:
// if anything still mounts it, it redirects to the live item detail page rather than
// rendering stale data.
export function ItemVariantsPage() {
  const { id } = useParams<{ id: string }>();
  return <Navigate to={id ? `/menu/${id}` : '/menu'} replace />;
}
