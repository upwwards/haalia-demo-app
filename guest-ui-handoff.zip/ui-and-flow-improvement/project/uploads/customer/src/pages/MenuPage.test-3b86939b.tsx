import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http as mswHttp, HttpResponse } from 'msw';
import { MemoryRouter, Route, Routes, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import { server } from '../test/server';
import { errorHandlers } from '../test/handlers';
import type { Feature, GuestLoginRequest } from '../api/types';
import { SessionProvider } from '../features/session/SessionProvider';
import { useSession } from '../features/session/useSession';
import { VenueProvider } from '../features/venue/VenueProvider';
import { ToastProvider } from '../features/toast/ToastProvider';
import { CartProvider } from '../features/cart/CartProvider';
import { MenuPage } from './MenuPage';

const QR: GuestLoginRequest = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'venue-1',
  serviceLocationId: 'loc-1',
};

// Fires authenticate() on mount so the session token exists, which in turn triggers the
// useMenu + VenueProvider fetches. Renders MenuPage under the SAME provider tree.
function AuthGate({ children }: { children: ReactNode }) {
  const { token, authenticate } = useSession();
  if (!token) void authenticate(QR);
  return <>{children}</>;
}

// Surfaces the current pathname so navigation assertions (variant-routing vs quick-add) can
// observe where the page sent the guest.
function LocationProbe() {
  const loc = useLocation();
  return <div data-testid="pathname">{loc.pathname}</div>;
}

function renderMenu() {
  return render(
    <MemoryRouter>
      <SessionProvider>
        <VenueProvider>
          <ToastProvider>
            <CartProvider>
              <AuthGate>
                <Routes>
                  <Route path="*" element={<MenuPage />} />
                </Routes>
                <LocationProbe />
              </AuthGate>
            </CartProvider>
          </ToastProvider>
        </VenueProvider>
      </SessionProvider>
    </MemoryRouter>,
  );
}

beforeEach(() => sessionStorage.clear());
afterEach(() => sessionStorage.clear());

describe('MenuPage (MENU-01/02/03)', () => {
  it('does not render the order/cart bar while the venue is loading', () => {
    // Synchronous render: before authenticate resolves, venueStatus is idle/loading.
    renderMenu();
    expect(screen.queryByText(/view cart/i)).not.toBeInTheDocument();
  });

  it('renders live menu items with derived categories once data loads', async () => {
    renderMenu();
    // Name appears twice (row title + ImageSlot placeholder) — getAllByText handles that.
    await waitFor(() => expect(screen.getAllByText('Margherita Pizza').length).toBeGreaterThan(0));
    // Derived category tabs from the items (not the old mock CATEGORIES): Mains + Desserts.
    expect(screen.getByRole('button', { name: /Mains/ })).toBeInTheDocument();
    // Desserts tab proves item-3 (page-1 only) aggregated into a derived category.
    expect(screen.getByRole('button', { name: /Desserts/ })).toBeInTheDocument();
  });

  it('shows a variant item as "from ₹" and never NaN/₹null', async () => {
    const { container } = renderMenu();
    await waitFor(() => expect(screen.getAllByText('Ribeye Steak').length).toBeGreaterThan(0));
    expect(screen.getByText(/from ₹180\.00/)).toBeInTheDocument();
    expect(container.textContent).not.toMatch(/NaN/);
    expect(container.textContent).not.toMatch(/₹null/);
    expect(container.textContent).not.toContain('$');
  });

  it('renders an available=false item visibly disabled (shown, not addable)', async () => {
    const user = userEvent.setup();
    renderMenu();
    // The sold-out dessert lives in the Desserts category — switch to it.
    await waitFor(() => expect(screen.getByRole('button', { name: /Desserts/ })).toBeInTheDocument());
    await user.click(screen.getByRole('button', { name: /Desserts/ }));
    await waitFor(() => expect(screen.getAllByText('Seasonal Dessert').length).toBeGreaterThan(0));
    // Sold-out marker is present and there is no Add control for that item.
    expect(screen.getAllByText(/sold out/i).length).toBeGreaterThan(0);
    expect(screen.queryByLabelText('Add Seasonal Dessert')).not.toBeInTheDocument();
  });

  it('renders the order bar add controls when ORDER_PLACEMENT is enabled', async () => {
    renderMenu();
    // With the default MSW features (['ORDER_PLACEMENT','MODEL_3D']) the order UI appears
    // for available items once venue + menu resolve.
    await waitFor(() => expect(screen.getByLabelText('Add Margherita Pizza')).toBeInTheDocument());
  });

  it('hides the order UI entirely when ORDER_PLACEMENT is off (features [])', async () => {
    server.use(
      mswHttp.get('*/api/v1/guest/venue/features', () =>
        HttpResponse.json([] satisfies Feature[]),
      ),
    );
    renderMenu();
    // Menu still loads, but no add controls and no cart bar are ever rendered.
    await waitFor(() => expect(screen.getAllByText('Margherita Pizza').length).toBeGreaterThan(0));
    expect(screen.queryByLabelText('Add Margherita Pizza')).not.toBeInTheDocument();
    expect(screen.queryByText(/view cart/i)).not.toBeInTheDocument();
  });

  it('quick-adds a non-variant item to the shared cart (badge appears, stays on page)', async () => {
    const user = userEvent.setup();
    renderMenu();
    await waitFor(() => expect(screen.getByLabelText('Add Margherita Pizza')).toBeInTheDocument());
    await user.click(screen.getByLabelText('Add Margherita Pizza'));
    // Quick-add writes to the shared cart → the view-cart bar appears; we did NOT navigate away.
    await waitFor(() => expect(screen.getByText(/view cart/i)).toBeInTheDocument());
    expect(screen.getByTestId('pathname').textContent).toBe('/');
  });

  it('routes a variant item to its detail page instead of quick-adding (D-03)', async () => {
    const user = userEvent.setup();
    renderMenu();
    // Ribeye Steak (item-2) has variants — its add control must open detail, never add directly.
    await waitFor(() => expect(screen.getByLabelText('Add Ribeye Steak')).toBeInTheDocument());
    await user.click(screen.getByLabelText('Add Ribeye Steak'));
    await waitFor(() =>
      expect(screen.getByTestId('pathname').textContent).toBe('/menu/item-2'),
    );
    // No cart bar — the variant item was NOT quick-added.
    expect(screen.queryByText(/view cart/i)).not.toBeInTheDocument();
  });

  it('shows an error state when the menu fetch fails (no token leak)', async () => {
    server.use(errorHandlers.notFoundGet('/guest/menu/effective'));
    const { container } = renderMenu();
    await waitFor(() =>
      expect(screen.getByText(/couldn't load the menu/i)).toBeInTheDocument(),
    );
    // The raw token / JWT must never appear in the error UI.
    expect(container.textContent).not.toMatch(/eyJ/);
  });
});
