import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon } from '@halia/ui';
import { useServiceRequests } from '../features/serviceRequests/useServiceRequests';
import { useSession } from '../features/session/useSession';
import type {
  GuestServiceRequestResponse,
  ServiceRequestStatus,
  ServiceRequestType,
} from '../api/types';

// The 7 contract request types (D-01). `id` is the EXACT enum value the API expects;
// `label`/`sub` are cosmetic only. Icons are existing @halia/ui glyphs; CUSTOM reuses `edit`.
const TILES: {
  id: ServiceRequestType;
  icon: string;
  label: string;
  sub: string;
}[] = [
  { id: 'WATER', icon: 'water', label: 'Water', sub: 'Still or sparkling' },
  { id: 'BILL', icon: 'bill', label: 'Bill', sub: 'Ready to settle' },
  { id: 'WAITER', icon: 'waiter', label: 'Server', sub: 'Need assistance' },
  { id: 'CLEAN_TABLE', icon: 'broom', label: 'Clean table', sub: 'Clear dishes' },
  { id: 'REFILL', icon: 'refill', label: 'Refill', sub: 'Drinks or sides' },
  { id: 'ORDER_ASSISTANCE', icon: 'help', label: 'Help ordering', sub: 'Allergy / menu' },
  { id: 'CUSTOM', icon: 'edit', label: 'Something else', sub: 'Tell us what you need' },
] as const;

// Human-friendly labels for the 5 lifecycle statuses (rendered verbatim, all 5 covered, D-04).
const STATUS_LABEL: Record<ServiceRequestStatus, string> = {
  OPEN: 'Open',
  ACKNOWLEDGED: 'Acknowledged',
  COMPLETED: 'Completed',
  IGNORED: 'Ignored',
  CANCELLED: 'Cancelled',
};

// Per-status palette for the row badge (cosmetic, brand CSS vars only).
const STATUS_TONE: Record<ServiceRequestStatus, { bg: string; fg: string }> = {
  OPEN: { bg: 'var(--warning-soft)', fg: 'var(--warning)' },
  ACKNOWLEDGED: { bg: 'var(--info-soft)', fg: 'var(--info)' },
  COMPLETED: { bg: 'var(--success-soft)', fg: 'var(--success)' },
  IGNORED: { bg: 'var(--surface-2)', fg: 'var(--text-muted)' },
  CANCELLED: { bg: 'var(--surface-2)', fg: 'var(--text-muted)' },
};

const TYPE_LABEL: Record<ServiceRequestType, string> = {
  WATER: 'Water',
  BILL: 'Bill',
  WAITER: 'Server',
  CLEAN_TABLE: 'Clean table',
  REFILL: 'Refill',
  ORDER_ASSISTANCE: 'Help ordering',
  CUSTOM: 'Custom request',
};

// Best-effort relative-ish timestamp. Renders the server time as a locale string; never
// computes lifecycle from it (timing is purely display, D-05 — requestedAt/completedAt only).
function fmtTime(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function RequestRow({
  row,
  onCancel,
}: {
  row: GuestServiceRequestResponse;
  onCancel(id: string): void;
}) {
  const tone = STATUS_TONE[row.status];
  // Timing is display-only: completedAt when present, else requestedAt (D-05). NEVER `created`.
  const when = fmtTime(row.completedAt ?? row.requestedAt);

  return (
    <div
      data-testid={`sr-row-${row.id}`}
      className="card"
      style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}
    >
      <div
        style={{
          width: 32, height: 32, borderRadius: 16, background: tone.bg, color: tone.fg,
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}
      >
        <Icon name="bell" size={15} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 13.5, fontWeight: 540 }}>{TYPE_LABEL[row.requestType]}</span>
          {/* Status label rendered verbatim (all 5 statuses), auto-escaped React children. */}
          <span
            style={{
              fontSize: 10.5, fontWeight: 600, padding: '2px 7px', borderRadius: 999,
              background: tone.bg, color: tone.fg,
            }}
          >
            {STATUS_LABEL[row.status]}
          </span>
        </div>
        {/* Server-provided free text — rendered as React children (auto-escaped, T-04-03);
            never injected as raw HTML. */}
        {row.message ? (
          <div style={{ fontSize: 12, color: 'var(--text)', marginTop: 3 }}>{row.message}</div>
        ) : null}
        {when ? (
          <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 2 }}>{when}</div>
        ) : null}
      </div>
      {/* Cancel ONLY on OPEN rows (D-07); reconciliation is server-authoritative (D-08). */}
      {row.status === 'OPEN' && (
        <button className="btn btn-quiet btn-sm" onClick={() => onCancel(row.id)}>
          Cancel
        </button>
      )}
    </div>
  );
}

export function ServiceRequestPage() {
  const navigate = useNavigate();
  // Live data layer: list status-machine + guarded create/cancel (toasts + refetch inside).
  const { requests, status, create, cancel } = useServiceRequests();
  const { sessionId, closed } = useSession();

  const [active, setActive] = useState<ServiceRequestType>('WATER');
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // CUSTOM requires a non-empty message (D-02); the server is also authoritative (400/422).
  const customMissingMessage = active === 'CUSTOM' && !note.trim();

  async function onSend() {
    if (submitting || closed || !sessionId || customMissingMessage) return;
    setSubmitting(true);
    try {
      // create() toasts (success/validation/danger) and refetches the list on success (D-03/D-06).
      const row = await create({
        serviceSessionId: sessionId,
        requestType: active,
        message: note.trim() || null,
      });
      if (row) setNote(''); // clear the note only on a confirmed send
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <div style={{ padding: '6px 20px 14px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => navigate(-1)} className="icon-btn outline">
          <Icon name="arrowLeft" size={16} />
        </button>
        <div className="serif" style={{ fontSize: 26, lineHeight: 1, flex: 1 }}>How can we help?</div>
      </div>
      <div className="scroll-y" style={{ flex: 1, padding: '4px 20px 24px' }}>
        {/* ---------- Raise UI (read-only when the session is closed, D-11) ---------- */}
        {closed ? (
          <div
            data-testid="sr-closed"
            style={{
              padding: 14, borderRadius: 12, background: 'var(--surface-2)',
              color: 'var(--text-muted)', fontSize: 13, marginBottom: 18, lineHeight: 1.45,
            }}
          >
            This session is closed. You can review past requests below, but new requests can't
            be raised.
          </div>
        ) : (
          <div style={{ fontSize: 13.5, color: 'var(--text-muted)', marginBottom: 18, lineHeight: 1.45 }}>
            Tap a request — your server is alerted instantly. Most are acknowledged within a minute.
          </div>
        )}

        <div
          data-testid="sr-tiles"
          style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 22 }}
        >
          {TILES.map((r) => (
            <button
              key={r.id}
              data-testid={`sr-tile-${r.id}`}
              disabled={closed}
              onClick={() => setActive(r.id)}
              style={{
                padding: 14, borderRadius: 12,
                border: `1.5px solid ${active === r.id ? 'var(--brand)' : 'var(--hairline)'}`,
                background: active === r.id ? 'var(--brand-tint)' : 'var(--surface)',
                cursor: closed ? 'not-allowed' : 'pointer', textAlign: 'left', fontFamily: 'inherit',
                opacity: closed ? 0.5 : 1,
              }}
            >
              <Icon name={r.icon} size={20} style={{ color: active === r.id ? 'var(--brand)' : 'var(--text-muted)', marginBottom: 10 }} />
              <div style={{ fontSize: 14, fontWeight: 540, color: 'var(--text)' }}>{r.label}</div>
              <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 2 }}>{r.sub}</div>
            </button>
          ))}
        </div>

        <div className="label" style={{ marginBottom: 8 }}>
          {active === 'CUSTOM' ? 'Tell us what you need' : 'Add a note (optional)'}
        </div>
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Sparkling water, please."
          className="input"
          disabled={closed}
          style={{ height: 80, padding: 12, resize: 'none', fontFamily: 'inherit', marginBottom: 16 }}
        />
        <button
          className="btn btn-primary btn-lg btn-block"
          disabled={submitting || closed || customMissingMessage}
          onClick={() => void onSend()}
        >
          {submitting ? (
            <>
              <span className="dot pulse" style={{ width: 8, height: 8, background: '#fff', marginRight: 8 }} />
              Sending…
            </>
          ) : (
            <>Send request <Icon name="send" size={14} /></>
          )}
        </button>

        {/* ---------- Live aggregated request list (status-machine, mirrors TrackingPage) ---------- */}
        <div style={{ marginTop: 26 }}>
          <div className="label" style={{ marginBottom: 10 }}>Your requests</div>

          {status === 'loading' && (
            <div data-testid="sr-loading" style={{ padding: '40px 0', textAlign: 'center', color: 'var(--text-faint)', fontSize: 14 }}>
              Loading your requests…
            </div>
          )}

          {status === 'error' && (
            <div
              data-testid="sr-list-error"
              style={{ padding: '32px 16px', textAlign: 'center', color: 'var(--danger)', fontSize: 14 }}
            >
              {/* User-safe copy — never leaks the token/raw internals. */}
              We couldn't load your requests.
            </div>
          )}

          {status === 'empty' && (
            <div data-testid="sr-empty" style={{ padding: '40px 0', textAlign: 'center' }}>
              <Icon name="bell" size={36} style={{ color: 'var(--text-faint)', marginBottom: 10 }} />
              <div style={{ fontSize: 15, fontWeight: 540, marginBottom: 4 }}>No requests yet</div>
              <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                Tap a request above and your server will be alerted.
              </div>
            </div>
          )}

          {status === 'ready' &&
            requests.map((row) => (
              <RequestRow key={row.id} row={row} onCancel={(id) => void cancel(id)} />
            ))}
        </div>
      </div>
    </>
  );
}
