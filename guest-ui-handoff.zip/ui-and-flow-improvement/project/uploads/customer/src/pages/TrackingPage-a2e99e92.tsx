import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon } from '@halia/ui';
import { useOrders } from '../features/orders/useOrders';
import { useSession } from '../features/session/useSession';
import { useToast } from '../features/toast/useToast';
import type { OrderResponse, OrderStatus } from '../api/types';

// The prototype's five display steps, in lifecycle order. The live OrderStatus enum maps
// onto these (D-09 / RESEARCH §Order status enum): PENDING→received, CONFIRMED→confirmed,
// PREPARING→preparing, READY→ready, COMPLETED→served. CANCELLED is handled separately.
const STEPS = [
  { k: 'received', label: 'Received', sub: 'Sent to kitchen' },
  { k: 'confirmed', label: 'Confirmed', sub: 'Order accepted' },
  { k: 'preparing', label: 'Preparing', sub: 'On the grill' },
  { k: 'ready', label: 'Ready', sub: 'Plating up' },
  { k: 'served', label: 'Served', sub: 'Enjoy your meal' },
] as const;

// Index into STEPS for each live status. COMPLETED lands on the final step; CANCELLED is -1
// (no active step — the cancelled banner renders instead).
const STATUS_STEP: Record<OrderStatus, number> = {
  PENDING: 0,
  CONFIRMED: 1,
  PREPARING: 2,
  READY: 3,
  COMPLETED: 4,
  CANCELLED: -1,
};

function OrderCard({ order }: { order: OrderResponse }) {
  const step = STATUS_STEP[order.status];
  const cancelled = order.status === 'CANCELLED';

  return (
    <div style={{ background: 'var(--surface)', border: '1px solid var(--hairline)', borderRadius: 14, padding: 20, marginBottom: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }}>
        <div>
          <div className="label">Order</div>
          <div className="serif" style={{ fontSize: 28, lineHeight: 1, marginTop: 4 }}>
            #{order.orderNumber}
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div className="label">Stage</div>
          <div style={{ fontSize: 14, fontWeight: 540, marginTop: 6, color: cancelled ? 'var(--danger)' : 'var(--brand)' }}>
            {cancelled ? 'Cancelled' : STEPS[step].label}
          </div>
        </div>
      </div>

      {cancelled ? (
        <div style={{ padding: 14, background: 'var(--surface-2)', borderRadius: 10, fontSize: 13, color: 'var(--text-muted)', marginBottom: 18 }}>
          This order was cancelled.
        </div>
      ) : (
        <>
          {/* Approximate "Ready in" ETA derived from the live status stage (design-source hero).
              Updates in real time as the order advances through its statuses. */}
          {step < 3 ? (
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 16 }}>
              <span className="label">Ready in</span>
              <span className="serif" style={{ fontSize: 34, lineHeight: 1 }}>
                ~{[18, 13, 7][step] ?? 7}
                <span style={{ fontSize: 16, color: 'var(--text-muted)', marginLeft: 4 }}>min</span>
              </span>
            </div>
          ) : step === 3 ? (
            <div style={{ marginBottom: 16, fontSize: 14, fontWeight: 540, color: 'var(--success)' }}>
              Ready now — your server is bringing it over.
            </div>
          ) : null}
          <div className="bar" style={{ marginBottom: 18 }}>
            <i style={{ width: `${((step + 1) / STEPS.length) * 100}%`, transition: 'width .5s' }} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {STEPS.map((s, i) => (
              <div key={s.k} style={{ display: 'flex', gap: 12, alignItems: 'center', opacity: i <= step ? 1 : 0.35 }}>
                <div
                  style={{
                    width: 28, height: 28, borderRadius: 14,
                    background: i <= step ? 'var(--brand)' : 'var(--surface-2)',
                    color: i <= step ? '#fff' : 'var(--text-faint)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  }}
                >
                  {i < step ? (
                    <Icon name="check" size={14} />
                  ) : i === step ? (
                    <span className="dot pulse" style={{ width: 8, height: 8, background: '#fff' }} />
                  ) : (
                    <span style={{ fontSize: 11, fontWeight: 600 }}>{i + 1}</span>
                  )}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: i === step ? 600 : 500 }}>{s.label}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{s.sub}</div>
                </div>
                {i === step && <span className="pill pill-brand" style={{ fontSize: 10 }}>Now</span>}
              </div>
            ))}
          </div>
        </>
      )}

      {/* Live order lines from the response — server names/labels (React auto-escapes, T-03-16). */}
      <div style={{ marginTop: 18, borderTop: '1px solid var(--hairline)', paddingTop: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {order.orderItems.map((line) => (
          <div key={line.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13.5 }}>
            <span style={{ color: 'var(--text)' }}>
              {line.quantity}× {line.itemName}
              {line.variantLabel ? (
                <span style={{ color: 'var(--text-muted)' }}> · {line.variantLabel}</span>
              ) : null}
              {line.notes ? (
                <span style={{ display: 'block', color: 'var(--text-faint)', fontStyle: 'italic', fontSize: 11.5, marginTop: 1 }}>“{line.notes}”</span>
              ) : null}
            </span>
            <span style={{ fontWeight: 540 }}>₹{line.itemTotal.toFixed(2)}</span>
          </div>
        ))}
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 15, fontWeight: 600, marginTop: 4 }}>
          <span>Total</span>
          <span>₹{order.totalPrice.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}

export function TrackingPage() {
  const navigate = useNavigate();
  // Live order history (D-09 — GET /orders/{sessionId} on mount; Phase-5 resync source).
  const { orders, status } = useOrders();
  // Checkout seam (D-10/D-11): guarded server-authoritative close + read-only when CLOSED.
  // checkout() reads the live sessionId internally (sessionIdRef) and returns the server
  // summary on success / undefined on 404/403; the page toasts on undefined (SessionProvider
  // sits ABOVE ToastProvider so it cannot toast itself).
  const { closed, checkout } = useSession();
  const { toast } = useToast();

  // Two-step inline confirm (mirrors CartPage `placed`) + in-flight double-submit guard (D-10).
  const [confirming, setConfirming] = useState(false);
  const [checkingOut, setCheckingOut] = useState(false);

  async function onCheckout() {
    if (checkingOut || closed) return;
    setCheckingOut(true);
    try {
      // No 409 handling (Pitfall 4): checkout() returns undefined on 404/403 and any error.
      const res = await checkout();
      if (res) {
        navigate('/checkout');
      } else {
        toast({ kind: 'danger', title: "Couldn't close your table" });
        setConfirming(false);
      }
    } finally {
      setCheckingOut(false);
    }
  }

  return (
    <>
      <div style={{ padding: '6px 20px 14px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => navigate(-1)} className="icon-btn outline">
          <Icon name="arrowLeft" size={16} />
        </button>
        <div style={{ flex: 1 }}>
          <div className="serif" style={{ fontSize: 24, lineHeight: 1 }}>Your order</div>
          <div style={{ fontSize: 12, color: 'var(--text-faint)', marginTop: 2 }}>Live status from the kitchen</div>
        </div>
        <span className="pill pill-brand">
          <span className="dot pulse" /> Live
        </span>
      </div>
      <div className="scroll-y" style={{ flex: 1, padding: '0 20px 20px' }}>
        {status === 'loading' && (
          <div style={{ padding: '60px 0', textAlign: 'center', color: 'var(--text-faint)', fontSize: 14 }}>
            Loading your order…
          </div>
        )}

        {status === 'error' && (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 14, padding: '48px 24px' }}>
            {/* User-safe copy — never leaks the token/raw internals (T-03-16). */}
            <div style={{ color: 'var(--danger)', fontSize: 15, textAlign: 'center' }}>
              We couldn't load your order.
            </div>
            <button className="btn btn-primary" onClick={() => navigate('/menu')}>Back to menu</button>
          </div>
        )}

        {status === 'empty' && (
          <div style={{ padding: '60px 0', textAlign: 'center' }}>
            <Icon name="receipt" size={40} style={{ color: 'var(--text-faint)', marginBottom: 12 }} />
            <div style={{ fontSize: 16, fontWeight: 540, marginBottom: 6 }}>No orders yet</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>Place an order from the menu to track it here.</div>
            <button className="btn btn-primary" onClick={() => navigate('/menu')}>
              Browse menu
            </button>
          </div>
        )}

        {status === 'ready' && orders.map((order) => <OrderCard key={order.id} order={order} />)}

        {/* ---------- Session-closed banner (read-only, D-11): history stays, actions gated off ---------- */}
        {status === 'ready' && closed && (
          <div
            data-testid="track-closed"
            style={{
              padding: 14, borderRadius: 12, background: 'var(--surface-2)',
              color: 'var(--text-muted)', fontSize: 13, marginTop: 4, lineHeight: 1.45,
            }}
          >
            Your table is closed. You can review your orders above, but you can no longer add to
            this order or check out again.
          </div>
        )}

        {/* ---------- Actions (hidden when closed, D-11) ---------- */}
        {status === 'ready' && !closed && (
          <>
            <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
              <button className="btn btn-ghost btn-block" onClick={() => navigate('/help')}>
                <Icon name="waiter" size={15} /> Need help
              </button>
              <button className="btn btn-ghost btn-block" onClick={() => navigate('/menu')}>
                <Icon name="plus" size={15} /> Add to order
              </button>
            </div>
            {/* Two-step inline confirm + in-flight guard (D-10) — never a bare navigate. */}
            {confirming ? (
              <button
                className="btn btn-primary btn-block"
                disabled={checkingOut}
                onClick={() => void onCheckout()}
                style={{ fontSize: 13 }}
              >
                {checkingOut ? (
                  <>
                    <span className="dot pulse" style={{ width: 8, height: 8, background: '#fff', marginRight: 8 }} />
                    Closing…
                  </>
                ) : (
                  <>Confirm — this closes your table</>
                )}
              </button>
            ) : (
              <button
                className="btn btn-quiet btn-block"
                onClick={() => setConfirming(true)}
                style={{ fontSize: 12 }}
              >
                Done? Close the bill
              </button>
            )}
          </>
        )}
      </div>
    </>
  );
}
