import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Route, Routes, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import type { GuestLoginRequest } from '../api/types';
import { SessionProvider } from '../features/session/SessionProvider';
import { VenueProvider } from '../features/venue/VenueProvider';
import { useSession } from '../features/session/useSession';
import { CheckoutPage } from './CheckoutPage';

const QR: GuestLoginRequest = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'venue-1',
  serviceLocationId: 'loc-1',
};

// Surfaces the current pathname so "Start a new session" → /welcome can be asserted.
function LocationProbe() {
  const loc = useLocation();
  return <div data-testid="pathname">{loc.pathname}</div>;
}

// Authenticate, then fire checkout() so checkoutSummary is primed from the happy handler
// ({ totalOrders: 3, totalSpent: 1516.5 }). Gates rendering of CheckoutPage on a primed summary.
function PrimeCheckoutGate({ children }: { children: ReactNode }) {
  const { token, checkoutSummary, checkout } = useSession();
  if (token && !checkoutSummary) void checkout();
  if (!checkoutSummary) return null;
  return <>{children}</>;
}

function AuthGate({ children }: { children: ReactNode }) {
  const { token, authenticate } = useSession();
  if (!token) void authenticate(QR);
  return <>{children}</>;
}

// Render with a PRIMED checkoutSummary (post-checkout happy path).
function renderPrimed() {
  return render(
    <MemoryRouter initialEntries={['/checkout']}>
      <SessionProvider>
        <VenueProvider>
          <AuthGate>
            <PrimeCheckoutGate>
              <Routes>
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/welcome" element={<div>welcome-screen</div>} />
                <Route path="*" element={<CheckoutPage />} />
              </Routes>
              <LocationProbe />
            </PrimeCheckoutGate>
          </AuthGate>
        </VenueProvider>
      </SessionProvider>
    </MemoryRouter>,
  );
}

// Render with a NULL summary (direct nav, no prior checkout) — must degrade gracefully.
function renderNullSummary() {
  return render(
    <MemoryRouter initialEntries={['/checkout']}>
      <SessionProvider>
        <VenueProvider>
          <Routes>
            <Route path="*" element={<CheckoutPage />} />
          </Routes>
        </VenueProvider>
      </SessionProvider>
    </MemoryRouter>,
  );
}

beforeEach(() => sessionStorage.clear());
afterEach(() => sessionStorage.clear());

describe('CheckoutPage (SESS-01)', () => {
  it('renders the real totalOrders + ₹-formatted totalSpent from checkoutSummary', async () => {
    const { container } = renderPrimed();
    // Happy checkout handler: totalOrders 3, totalSpent 1516.5.
    await waitFor(() =>
      expect(screen.getByTestId('checkout-total-spent')).toHaveTextContent('₹1516.50'),
    );
    expect(screen.getByTestId('checkout-total-orders')).toHaveTextContent('3 orders');
    // Server money only — ₹, never $, no NaN, no ₹null.
    expect(container.textContent).not.toContain('$');
    expect(container.textContent).not.toMatch(/NaN/);
    expect(container.textContent).not.toMatch(/₹null/);
  });

  it('contains none of the fabricated prototype strings', async () => {
    const { container } = renderPrimed();
    await waitFor(() =>
      expect(screen.getByTestId('checkout-total-spent')).toHaveTextContent('₹1516.50'),
    );
    expect(container.textContent).not.toContain('$112.45');
    expect(container.textContent).not.toContain('A12-04');
    expect(container.textContent).not.toContain('Verbena');
    expect(container.textContent).not.toContain('Marco');
    expect(container.textContent).not.toMatch(/Leave a review/i);
    expect(container.textContent).not.toMatch(/Email me the receipt/i);
  });

  it('"Start a new session" navigates to /welcome', async () => {
    const user = userEvent.setup();
    renderPrimed();
    await waitFor(() =>
      expect(screen.getByTestId('checkout-total-spent')).toHaveTextContent('₹1516.50'),
    );
    await user.click(screen.getByRole('button', { name: /start a new session/i }));
    await waitFor(() => expect(screen.getByText('welcome-screen')).toBeInTheDocument());
    expect(screen.getByTestId('pathname').textContent).toBe('/welcome');
  });

  it('degrades gracefully with a null summary — no NaN, no ₹null, no crash', () => {
    const { container } = renderNullSummary();
    // Thank-you heading still renders (no crash).
    expect(screen.getByText(/thank you/i)).toBeInTheDocument();
    // Null-guarded zeros, never NaN/₹null.
    expect(screen.getByTestId('checkout-total-spent')).toHaveTextContent('₹0.00');
    expect(screen.getByTestId('checkout-total-orders')).toHaveTextContent('0 orders');
    expect(container.textContent).not.toMatch(/NaN/);
    expect(container.textContent).not.toMatch(/₹null/);
    expect(container.textContent).not.toContain('$');
  });
});
