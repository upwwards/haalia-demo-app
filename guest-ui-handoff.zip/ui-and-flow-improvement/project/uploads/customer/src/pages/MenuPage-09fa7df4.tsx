import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon, ImageSlot, TAG_META } from '@halia/ui';
import { useMenu } from '../features/menu/useMenu';
import { useVenue } from '../features/venue/useVenue';
import { useCart } from '../features/cart/useCart';
import type { MenuItemView } from '../features/menu/menuAdapter';
import { priceLabel } from '../features/menu/price';

interface RowProps {
  item: MenuItemView;
  qty: number;
  canOrder: boolean;
  onAdd: () => void;
  onSub: () => void;
  onOpen: () => void;
}

function MenuRow({ item, qty, canOrder, onAdd, onSub, onOpen }: RowProps) {
  // available=false items stay visible but are dimmed and cannot be added (A8).
  const soldOut = item.available === false;
  return (
    <div
      style={{
        display: 'flex',
        gap: 14,
        padding: '14px 0',
        borderBottom: '1px solid var(--hairline)',
        opacity: soldOut ? 0.5 : 1,
      }}
    >
      <div style={{ flex: 1, minWidth: 0, cursor: 'pointer' }} onClick={onOpen}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
          {item.tags.map((t) => {
            const m = TAG_META[t];
            if (!m) return null;
            return <Icon key={t} name={m.icon} size={12} style={{ color: m.color }} />;
          })}
          {item.hot && <span className="pill pill-brand" style={{ padding: '1px 6px', fontSize: 10 }}>Hot</span>}
          {soldOut && (
            <span className="pill pill-outline" style={{ padding: '1px 6px', fontSize: 10 }}>Sold out</span>
          )}
        </div>
        <div style={{ fontSize: 16, fontWeight: 540, color: 'var(--text)', marginBottom: 4, lineHeight: 1.25 }}>{item.name}</div>
        <div style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.4, marginBottom: 8 }}>{item.desc}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {/* Price routed through priceLabel: '₹X' for base, 'from ₹X' for variants, never NaN/₹null. */}
          <span style={{ fontSize: 14, fontWeight: 540 }}>{priceLabel(item.dto)}</span>
          <span style={{ fontSize: 12, color: 'var(--text-faint)', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <Icon name="clock" size={11} /> {item.time}m
          </span>
        </div>
      </div>
      <div style={{ width: 92, flexShrink: 0, position: 'relative' }}>
        <ImageSlot placeholder={item.name} radius={10} style={{ width: 92, height: 92 }} />
        {/* Add controls only when ordering is enabled AND the item is available. */}
        {canOrder && !soldOut && (
          qty === 0 ? (
            <button
              onClick={(e) => { e.stopPropagation(); onAdd(); }}
              aria-label={`Add ${item.name}`}
              style={{
                position: 'absolute', bottom: -8, right: -8, width: 32, height: 32, borderRadius: 16,
                background: 'var(--brand)', color: '#fff', border: '3px solid var(--bg)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
              }}
            >
              <Icon name="plus" size={16} />
            </button>
          ) : (
            <div
              style={{
                position: 'absolute', bottom: -8, right: -8, height: 32, background: 'var(--brand)',
                color: '#fff', borderRadius: 16, border: '3px solid var(--bg)',
                display: 'flex', alignItems: 'center', gap: 4, padding: '0 4px',
              }}
            >
              <button onClick={(e) => { e.stopPropagation(); onSub(); }} style={{ background: 'transparent', border: 0, color: '#fff', width: 22, height: 22, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="minus" size={14} />
              </button>
              <span style={{ fontSize: 13, fontWeight: 600, minWidth: 12, textAlign: 'center' }}>{qty}</span>
              <button onClick={(e) => { e.stopPropagation(); onAdd(); }} style={{ background: 'transparent', border: 0, color: '#fff', width: 22, height: 22, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="plus" size={14} />
              </button>
            </div>
          )
        )}
      </div>
    </div>
  );
}

export function MenuPage() {
  const navigate = useNavigate();
  const { items, categories, status: menuStatus, error: menuError, reload: reloadMenu } = useMenu();
  const { hasFeature, venue, location, status: venueStatus } = useVenue();
  // Shared cart is the single source of truth — badge count + server-authoritative total,
  // plus the quick-add/sub writes (D-06: never a client-computed total).
  const { lines, count: cartCount, totalPrice, add, sub } = useCart();

  const [cat, setCat] = useState('');
  const [search, setSearch] = useState('');
  const searchRef = useRef<HTMLInputElement>(null);

  // Per-row quantity = sum of every cart line for that menuItemId (variants of one dish are
  // distinct lines; the menu row shows the combined quantity for the dish).
  const qtyFor = (menuItemId: string): number =>
    lines.reduce((sum, l) => (l.menuItemId === menuItemId ? sum + l.quantity : sum), 0);

  // Pitfall 3: derive the selected category from live data once it loads, rather than a
  // hardcoded 'mains' that may not exist in the backend's category set.
  useEffect(() => {
    if (!cat && categories.length) setCat(categories[0].id);
  }, [cat, categories]);

  // Order/cart UI only renders once the venue resolves AND ORDER_PLACEMENT is enabled —
  // never flashes during load, never shows at a feature-off venue (Pattern 5 / Pitfall 4).
  const canOrder = venueStatus === 'ready' && hasFeature('ORDER_PLACEMENT');

  const visible = items.filter(
    (m) =>
      (cat === '' || m.cat === cat) &&
      (search === '' || m.name.toLowerCase().includes(search.toLowerCase())),
  );

  // Live venue/table header (MENU-02), with a graceful fallback while loading.
  const headerLine = [venue?.venueName, location?.name].filter(Boolean).join(' · ') || 'Loading…';

  return (
    <>
      <div style={{ padding: '4px 20px 14px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <div>
            <div className="mono" style={{ fontSize: 11.5, color: 'var(--text-faint)', letterSpacing: '0.04em' }}>
              {headerLine.toUpperCase()}
            </div>
            <div className="serif" style={{ fontSize: 30, lineHeight: 1, marginTop: 6 }}>Tonight's menu</div>
          </div>
          <button
            className="icon-btn outline"
            aria-label="Call a server"
            onClick={() => navigate('/help')}
          >
            <Icon name="bell" size={16} />
          </button>
        </div>
        <div style={{ position: 'relative' }}>
          <Icon
            name="search"
            size={14}
            style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-faint)' }}
          />
          <input
            ref={searchRef}
            className="input"
            placeholder="Search dishes…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ paddingLeft: 34, height: 40, fontSize: 14, background: 'var(--surface-2)', borderColor: 'transparent' }}
          />
        </div>
      </div>
      <div style={{ borderBottom: '1px solid var(--hairline)', overflowX: 'auto', whiteSpace: 'nowrap' }}>
        <div style={{ display: 'inline-flex', gap: 2, padding: '0 14px' }}>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setCat(c.id)}
              style={{
                background: 'transparent', border: 'none', padding: '12px 12px 14px', cursor: 'pointer',
                fontSize: 14, fontWeight: cat === c.id ? 600 : 500,
                color: cat === c.id ? 'var(--text)' : 'var(--text-muted)',
                borderBottom: `2px solid ${cat === c.id ? 'var(--brand)' : 'transparent'}`,
                marginBottom: -1, fontFamily: 'inherit', letterSpacing: '-0.005em',
              }}
            >
              {c.name} <span style={{ fontSize: 11, color: 'var(--text-faint)', marginLeft: 3 }}>{c.count}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="scroll-y" style={{ flex: 1, padding: '14px 20px 80px' }}>
        {menuStatus === 'loading' || menuStatus === 'idle' ? (
          <div style={{ textAlign: 'center', padding: 40, color: 'var(--text-faint)', fontSize: 14 }}>
            Loading menu…
          </div>
        ) : menuStatus === 'error' ? (
          <div style={{ textAlign: 'center', padding: 40, fontSize: 14 }}>
            {/* User-safe copy off ApiError.status — never leaks the token or raw internals (T-02-16). */}
            <div style={{ color: 'var(--danger)', marginBottom: 14 }}>
              We couldn't load the menu{menuError?.status ? ` (error ${menuError.status})` : ''}. Please try again.
            </div>
            <button className="btn btn-quiet" onClick={() => reloadMenu()}>Try again</button>
          </div>
        ) : menuStatus === 'empty' ? (
          <div style={{ textAlign: 'center', padding: 40, color: 'var(--text-faint)', fontSize: 14 }}>
            The menu is empty right now. Please check back soon.
          </div>
        ) : (
          <>
            {visible.map((m) => (
              <MenuRow
                key={m.id}
                item={m}
                qty={qtyFor(m.id)}
                canOrder={canOrder}
                // D-03: variant items can't be quick-added (no variant chosen yet) — route to
                // detail to pick one; only non-variant items add directly to the shared cart.
                onAdd={() => (m.hasVariants ? navigate(`/menu/${m.id}`) : add(m.id))}
                onSub={() => sub(m.id)}
                onOpen={() => navigate(`/menu/${m.id}`)}
              />
            ))}
            {visible.length === 0 && (
              <div style={{ textAlign: 'center', padding: 40, color: 'var(--text-faint)', fontSize: 14 }}>
                {search ? `No dishes match "${search}".` : 'No dishes in this category.'}
              </div>
            )}
          </>
        )}
      </div>
      {canOrder && cartCount > 0 && (
        <div
          onClick={() => navigate('/cart')}
          className="slide-in"
          style={{
            position: 'absolute', left: 14, right: 14, bottom: 14, background: 'var(--text)',
            color: 'var(--bg)', borderRadius: 14, padding: '12px 16px', display: 'flex',
            alignItems: 'center', gap: 12, boxShadow: 'var(--shadow-3)', cursor: 'pointer',
          }}
        >
          <div
            style={{
              width: 32, height: 32, borderRadius: 16, background: 'var(--brand)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600, fontSize: 13, color: '#fff',
            }}
          >
            {cartCount}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 600 }}>View cart</div>
            <div style={{ fontSize: 12, opacity: 0.6 }}>
              {/* Server-authoritative total only — never a client-computed sum (D-06/Pitfall 2).
                  Until the server confirms a totalPrice we show just the count. */}
              {cartCount} items{totalPrice !== null ? ` · ₹${totalPrice.toFixed(2)}` : ''}
            </div>
          </div>
          <Icon name="arrowRight" size={18} />
        </div>
      )}
    </>
  );
}
