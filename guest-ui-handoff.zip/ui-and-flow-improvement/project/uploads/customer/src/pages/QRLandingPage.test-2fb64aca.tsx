import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { SessionProvider } from '../features/session/SessionProvider';
import { useSession } from '../features/session/useSession';
import { QRLandingPage } from './QRLandingPage';

// clientId/clientSecret come from THIS deployment's env (not the QR URL); the QR carries only
// venueId + serviceLocationId. Mirror the MSW happy-path creds here.
vi.mock('../config', () => ({
  config: {
    apiBaseUrl: 'http://localhost',
    mocking: false,
    guestClientId: 'guest-client',
    guestClientSecret: 'guest-secret',
  },
}));

// Tiny consumer that reads the session token/sessionId into the DOM, rendered inside
// the SAME SessionProvider as the page — so we can assert authenticate() fired.
function SessionProbe() {
  const { token, sessionId } = useSession();
  return (
    <div>
      <span data-testid="token">{token ?? ''}</span>
      <span data-testid="sessionId">{sessionId ?? ''}</span>
    </div>
  );
}

beforeEach(() => sessionStorage.clear());
afterEach(() => sessionStorage.clear());

describe('QRLandingPage auth-trigger (Pitfall 7 smoke)', () => {
  it('clicking "View menu" authenticates (token + session-1) before navigating', async () => {
    const user = userEvent.setup();
    // Real QR path: venueId + serviceLocationId arrive in the QR URL; clientId/clientSecret
    // come from env (mocked above). authenticate() fires on click.
    render(
      <MemoryRouter
        initialEntries={['/?venueId=venue-1&serviceLocationId=loc-1']}
      >
        <SessionProvider>
          <QRLandingPage />
          <SessionProbe />
        </SessionProvider>
      </MemoryRouter>,
    );

    // Before the click there is no session — authenticate has not run.
    expect(screen.getByTestId('token').textContent).toBe('');

    await user.click(screen.getByRole('button', { name: /view menu/i }));

    // After the click the awaited authenticate() must have populated the session
    // (navigate('/menu') runs synchronously right after, so token!=null proves the
    // auth fired before navigation). This guards the fix against silent regression.
    await waitFor(() =>
      expect(screen.getByTestId('token').textContent).not.toBe(''),
    );
    expect(screen.getByTestId('sessionId').textContent).toBe('session-1');
  });
});
