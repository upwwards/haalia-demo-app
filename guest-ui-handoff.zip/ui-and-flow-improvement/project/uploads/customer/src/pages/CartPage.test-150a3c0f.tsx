import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Route, Routes, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import { http, HttpResponse } from 'msw';
import { server } from '../test/server';
import { errorHandlers } from '../test/handlers';
import { errorBody } from '../test/jwt';
import type { GuestLoginRequest } from '../api/types';
import { SessionProvider } from '../features/session/SessionProvider';
import { useSession } from '../features/session/useSession';
import { VenueProvider } from '../features/venue/VenueProvider';
import { ToastProvider } from '../features/toast/ToastProvider';
import { CartProvider } from '../features/cart/CartProvider';
import { CartPage } from './CartPage';

const QR: GuestLoginRequest = {
  clientId: 'c1',
  clientSecret: 'sekret',
  venueId: 'venue-1',
  serviceLocationId: 'loc-1',
};

// Authenticate on mount so the session token + sessionId exist; that gates the cart GET.
function AuthGate({ children }: { children: ReactNode }) {
  const { token, authenticate } = useSession();
  if (!token) void authenticate(QR);
  return <>{children}</>;
}

// Surfaces the current pathname so "no auto-navigate" / "stay on /cart" can be asserted.
function LocationProbe() {
  const loc = useLocation();
  return <div data-testid="pathname">{loc.pathname}</div>;
}

function renderCart() {
  return render(
    <MemoryRouter initialEntries={['/cart']}>
      <SessionProvider>
        <VenueProvider>
          <ToastProvider>
            <CartProvider>
              <AuthGate>
                <Routes>
                  <Route path="*" element={<CartPage />} />
                </Routes>
                <LocationProbe />
              </AuthGate>
            </CartProvider>
          </ToastProvider>
        </VenueProvider>
      </SessionProvider>
    </MemoryRouter>,
  );
}

// Per-test request spy over the MSW server event bus. Records {method, path} for every
// outbound request so DELETE-vs-PUT and single-submit assertions read true network calls.
function spyRequests() {
  const calls: { method: string; path: string }[] = [];
  const listener = ({ request }: { request: Request }) => {
    calls.push({ method: request.method, path: new URL(request.url).pathname });
  };
  server.events.on('request:start', listener);
  return {
    calls,
    matching: (method: string, re: RegExp) =>
      calls.filter((c) => c.method === method && re.test(c.path)),
    stop: () => server.events.removeListener('request:start', listener),
  };
}

beforeEach(() => sessionStorage.clear());
afterEach(() => {
  sessionStorage.clear();
  server.events.removeAllListeners();
});

describe('CartPage (CART-01/CART-03/ORDER-01)', () => {
  it('renders the server totalPrice verbatim, not a computed sum', async () => {
    const { container } = renderCart();
    // GET cart fixture: totalPrice 818, lines 698 + 120 → server total rendered once.
    await waitFor(() => expect(screen.getByText('₹818.00')).toBeInTheDocument());
    expect(screen.getByText('₹698.00')).toBeInTheDocument();
    expect(screen.getByText('₹120.00')).toBeInTheDocument();
    // No fabricated Subtotal/Tax, no $/NaN/₹null.
    expect(screen.queryByText(/subtotal/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/tax/i)).not.toBeInTheDocument();
    expect(container.textContent).not.toContain('$');
    expect(container.textContent).not.toMatch(/NaN/);
    expect(container.textContent).not.toMatch(/₹null/);
  });

  it('guards double-submit: a second click while pending issues a single submit', async () => {
    const user = userEvent.setup();
    const spy = spyRequests();
    renderCart();
    await waitFor(() => expect(screen.getByText('₹818.00')).toBeInTheDocument());

    const btn = screen.getByRole('button', { name: /send to kitchen/i });
    // Fire two clicks back-to-back; the provider's in-flight guard collapses them to one POST.
    await user.click(btn);
    await user.click(btn);

    await waitFor(() => expect(screen.getByText(/order placed/i)).toBeInTheDocument());
    expect(spy.matching('POST', /\/cart\/.+\/submit$/)).toHaveLength(1);
    spy.stop();
  });

  it('submit 200 → cart cleared + inline confirmation with a View order link, no auto-navigate', async () => {
    const user = userEvent.setup();
    renderCart();
    await waitFor(() => expect(screen.getByText('₹818.00')).toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: /send to kitchen/i }));

    // Inline confirmation appears; the View order link points at /track but does not navigate.
    await waitFor(() => expect(screen.getByText(/order placed/i)).toBeInTheDocument());
    expect(screen.getByRole('button', { name: /view order/i })).toBeInTheDocument();
    // No auto-navigation — still on /cart until the guest taps View order.
    expect(screen.getByTestId('pathname').textContent).toBe('/cart');
    // Cart lines were cleared by the success path.
    expect(screen.queryByText('₹698.00')).not.toBeInTheDocument();
  });

  it('submit 409 → "session closed" warning toast, page stays on /cart', async () => {
    server.use(errorHandlers.conflictPost('/guest/cart/:sessionId/submit'));
    const user = userEvent.setup();
    renderCart();
    await waitFor(() => expect(screen.getByText('₹818.00')).toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: /send to kitchen/i }));

    await waitFor(() => expect(screen.getByText(/this session has closed/i)).toBeInTheDocument());
    expect(screen.queryByText(/order placed/i)).not.toBeInTheDocument();
    expect(screen.getByTestId('pathname').textContent).toBe('/cart');
  });

  it('submit 400/422 → "cart is empty" warning toast, page stays on /cart', async () => {
    server.use(errorHandlers.badRequestPost('/guest/cart/:sessionId/submit'));
    const user = userEvent.setup();
    renderCart();
    await waitFor(() => expect(screen.getByText('₹818.00')).toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: /send to kitchen/i }));

    await waitFor(() => expect(screen.getByText(/your cart is empty/i)).toBeInTheDocument());
    expect(screen.queryByText(/order placed/i)).not.toBeInTheDocument();
    expect(screen.getByTestId('pathname').textContent).toBe('/cart');
  });

  it('GET cart fails → explicit error branch (no empty placeholder, no token leak)', async () => {
    // Force the cart GET to fail so useCart().status flips to 'error' (mirrors how the
    // 409/422 tests override the submit handler). The path matches the real GET cart route.
    server.use(
      http.get('*/api/v1/guest/cart/:sessionId', () =>
        HttpResponse.json(errorBody(500, 'SERVER_ERROR'), { status: 500 }),
      ),
    );
    const { container } = renderCart();

    // The user-safe error branch renders…
    await waitFor(() =>
      expect(screen.getByText(/we couldn't load your cart/i)).toBeInTheDocument(),
    );
    // …with a Back to menu CTA…
    expect(screen.getByRole('button', { name: /back to menu/i })).toBeInTheDocument();
    // …error takes precedence over the empty placeholder (a failed GET is NOT "Cart is empty")…
    expect(screen.queryByText(/cart is empty/i)).not.toBeInTheDocument();
    // …and no token/secret leaks into the rendered copy.
    expect(container.textContent).not.toMatch(/Bearer/i);
    expect(container.textContent).not.toMatch(/token/i);
  });

  it('clear issues a DELETE, never a PUT with items:[]', async () => {
    const user = userEvent.setup();
    const spy = spyRequests();
    renderCart();
    await waitFor(() => expect(screen.getByText('₹818.00')).toBeInTheDocument());

    await user.click(screen.getByRole('button', { name: /clear cart/i }));

    // The debounced flush routes an empty cart to DELETE /cart/{sessionId} (D-02).
    await waitFor(() =>
      expect(spy.matching('DELETE', /\/cart\/[^/]+$/)).toHaveLength(1),
    );
    expect(spy.matching('PUT', /\/cart$/)).toHaveLength(0);
    spy.stop();
  });
});
