import { useNavigate, useSearchParams } from 'react-router-dom';
import { Icon, ImageSlot, HaliaLogo } from '@halia/ui';
import { useSession } from '../features/session/useSession';
import { parseQrCreds } from '../features/session/qr';
import { errorUx } from '../api/errorUx';
import { config } from '../config';

// Mock QR credentials — used ONLY when request-mocking is enabled (dev/MSW/Playwright). They
// mirror the MSW happy path so authenticate() returns 200.
const MOCKED_QR = {
  clientId: 'guest-client',
  clientSecret: 'guest-secret',
  venueId: 'venue-1',
  serviceLocationId: 'loc-1',
};

export function QRLandingPage() {
  const navigate = useNavigate();
  const { authenticate } = useSession();
  const [searchParams] = useSearchParams();

  // Resolve guest credentials the way the table QR actually carries them:
  //   • venueId + serviceLocationId come from the scanned QR URL (the table's identity), and
  //   • clientId + clientSecret come from THIS deployment's env (the org's generated credentials,
  //     configured in .env — never embedded in the QR for security).
  // Mock mode falls back to the MSW happy-path constant so dev/tests work with no backend.
  const resolveQrCreds = () => {
    const live = parseQrCreds({
      clientId: config.guestClientId,
      clientSecret: config.guestClientSecret,
      venueId: searchParams.get('venueId'),
      serviceLocationId: searchParams.get('serviceLocationId'),
    });
    if (live) return live;
    return config.mocking ? parseQrCreds(MOCKED_QR) : null;
  };

  // Authenticate from the QR creds BEFORE navigating, so token/sessionId exist and downstream
  // menu/venue GETs carry the bearer (closes the blocking auth-trigger gap).
  const handleViewMenu = async () => {
    const qr = resolveQrCreds();
    if (!qr) {
      // No valid QR creds (live, opened without a scan) → invalid-QR state.
      navigate('/error');
      return;
    }
    try {
      await authenticate(qr);
    } catch (e) {
      // Map the auth failure through the single per-status UX policy (UX-01). Route to the
      // descriptor's target (404 → /error, unrecoverable 401 → /expired) or the safe default
      // (/error) — an unauthenticated guest cannot proceed to the menu. NEVER log the error:
      // it must never surface the token/secret (T-05-14 / SECURITY).
      navigate(errorUx(e).route ?? '/error');
      return;
    }
    navigate('/menu');
  };

  return (
    <>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '8px 28px 24px' }}>
        <div style={{ flex: '0 0 36%', display: 'flex', alignItems: 'flex-end' }}>
          <div>
            <div className="pill pill-outline" style={{ marginBottom: 16 }}>
              <Icon name="location" size={11} /> QR scan confirmed
            </div>
            <div className="serif" style={{ fontSize: 56, lineHeight: 1, color: 'var(--text)', marginBottom: 14 }}>
              Welcome
              <span className="serif-i" style={{ color: 'var(--brand)' }}>.</span>
            </div>
            <div style={{ fontSize: 15, color: 'var(--text-muted)', lineHeight: 1.4 }}>
              Your table session is open. Order, call a server, or just browse — no app needed.
            </div>
          </div>
        </div>
        <div style={{ flex: 1, position: 'relative', margin: '32px -8px 0' }}>
          <ImageSlot placeholder="hero photo" radius={18} />
        </div>
        <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <button className="btn btn-primary btn-lg btn-block" onClick={handleViewMenu}>
            View menu <Icon name="arrowRight" size={16} />
          </button>
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn btn-ghost btn-block" onClick={() => navigate('/help')}>
              <Icon name="waiter" size={16} /> Call server
            </button>
            <button className="btn btn-ghost btn-block" onClick={() => navigate('/help')}>
              <Icon name="bill" size={16} /> Ask for bill
            </button>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', marginTop: 20, fontSize: 11.5, color: 'var(--text-faint)' }}>
          <HaliaLogo size={16} />
        </div>
      </div>
    </>
  );
}
