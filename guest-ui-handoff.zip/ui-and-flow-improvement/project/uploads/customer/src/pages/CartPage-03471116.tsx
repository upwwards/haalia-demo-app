import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icon, ImageSlot } from '@halia/ui';
import { useCart } from '../features/cart/useCart';
import { useVenue } from '../features/venue/useVenue';

export function CartPage() {
  const navigate = useNavigate();
  // Live cart: server-authoritative lines + total (D-06 — never compute a total client-side).
  const { serverLines, totalPrice, estimatedWaitMinutes, status, submitting, add, sub, clear, submit } = useCart();
  // Real table identity from the JWT-bound location (no hardcoded "Table 12").
  const { location } = useVenue();
  const tableLabel = location?.name ?? 'Your table';
  // Header count reflects the server-authoritative lines shown below (survives a page refresh,
  // where the optimistic local `count` would reset to 0 while the server cart still has items).
  const shownCount = serverLines.reduce((sum, l) => sum + l.quantity, 0);
  // Inline post-submit confirmation (D-07 — we do NOT auto-navigate to /track).
  const [placed, setPlaced] = useState(false);

  // Render the server total verbatim; never a computed sum, never $/NaN (₹ matches MenuPage).
  const totalLabel = '₹' + (totalPrice ?? 0).toFixed(2);

  async function onSubmit() {
    const order = await submit(); // guard + 409/400/422 toasts live in the provider (D-08/D-10)
    if (order) setPlaced(true); // success → inline confirmation, stay on /cart
  }

  // ---------- Inline order confirmation (success — no auto-navigate, D-07) ----------
  if (placed) {
    return (
      <>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, padding: 24, textAlign: 'center' }}>
          <div
            style={{
              width: 64, height: 64, borderRadius: 32, background: 'var(--brand)', color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <Icon name="check" size={28} />
          </div>
          <div className="serif" style={{ fontSize: 26, lineHeight: 1.1 }}>Order placed</div>
          <div style={{ fontSize: 13.5, color: 'var(--text-muted)', maxWidth: 280 }}>
            Your order is on its way to the kitchen. Track its progress any time.
          </div>
          <button className="btn btn-primary btn-lg" onClick={() => navigate('/track')}>
            View order
          </button>
          <button className="btn btn-quiet" onClick={() => navigate('/menu')} style={{ fontSize: 12 }}>
            Back to menu
          </button>
        </div>
      </>
    );
  }

  const isEmpty = serverLines.length === 0;

  return (
    <>
      <div style={{ padding: '6px 20px 12px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => navigate(-1)} className="icon-btn outline">
          <Icon name="arrowLeft" size={16} />
        </button>
        <div style={{ flex: 1 }}>
          <div className="serif" style={{ fontSize: 26, lineHeight: 1 }}>Your order</div>
          <div style={{ fontSize: 12, color: 'var(--text-faint)', marginTop: 2 }}>
            {tableLabel} · {shownCount} {shownCount === 1 ? 'item' : 'items'}
          </div>
        </div>
        {/* Trash routes to DELETE via clear() — never a PUT with items:[] (D-02 / CART-03). */}
        <button className="icon-btn" aria-label="Clear cart" onClick={() => clear()}>
          <Icon name="trash" size={16} />
        </button>
      </div>
      <div className="scroll-y" style={{ flex: 1, padding: '0 20px' }}>
        {serverLines.map((it) => (
          <div key={it.menuItemId} style={{ display: 'flex', gap: 12, padding: '14px 0', borderBottom: '1px solid var(--hairline)' }}>
            <ImageSlot placeholder={it.menuItemName} radius={10} style={{ width: 68, height: 68, flexShrink: 0 }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 15, fontWeight: 540, marginBottom: 2 }}>{it.menuItemName}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: it.notes ? 2 : 6 }}>{it.categoryName}</div>
              {it.notes && (
                <div style={{ fontSize: 11.5, color: 'var(--text-faint)', fontStyle: 'italic', marginBottom: 6 }}>“{it.notes}”</div>
              )}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 }}>
                {/* Server itemTotal — never client price*qty math (D-06). */}
                <span style={{ fontSize: 14, fontWeight: 540 }}>₹{it.itemTotal.toFixed(2)}</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, border: '1px solid var(--hairline)', borderRadius: 999, padding: 2 }}>
                  <button
                    aria-label={`Decrease ${it.menuItemName}`}
                    onClick={() => sub(it.menuItemId)}
                    style={{ border: 0, background: 'transparent', width: 26, height: 26, cursor: 'pointer', color: 'var(--text-muted)' }}
                  >
                    <Icon name="minus" size={12} />
                  </button>
                  <span style={{ fontSize: 13, fontWeight: 600, minWidth: 16, textAlign: 'center' }}>{it.quantity}</span>
                  <button
                    aria-label={`Increase ${it.menuItemName}`}
                    onClick={() => add(it.menuItemId)}
                    style={{ border: 0, background: 'transparent', width: 26, height: 26, cursor: 'pointer', color: 'var(--text-muted)' }}
                  >
                    <Icon name="plus" size={12} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {status === 'loading' && isEmpty && (
          <div style={{ padding: '60px 0', textAlign: 'center', color: 'var(--text-faint)', fontSize: 14 }}>
            Loading your cart…
          </div>
        )}
        {/* Explicit error branch (UX-02), mirroring TrackingPage 167-175. Takes precedence
            over the empty placeholder so a failed GET is never shown as "Cart is empty"
            (T-05-15). User-safe copy — NEVER renders the token or raw error.message (T-05-13). */}
        {status === 'error' && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 14, padding: '48px 24px' }}>
            <div style={{ color: 'var(--danger)', fontSize: 15, textAlign: 'center' }}>
              We couldn't load your cart.
            </div>
            <button className="btn btn-primary" onClick={() => navigate('/menu')}>Back to menu</button>
          </div>
        )}
        {isEmpty && status !== 'loading' && status !== 'error' && (
          <div style={{ padding: '60px 0', textAlign: 'center' }}>
            <Icon name="cart" size={40} style={{ color: 'var(--text-faint)', marginBottom: 12 }} />
            <div style={{ fontSize: 16, fontWeight: 540, marginBottom: 6 }}>Cart is empty</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>Browse the menu and add a dish.</div>
            <button className="btn btn-primary" onClick={() => navigate('/menu')}>
              Browse menu
            </button>
          </div>
        )}
        {!isEmpty && (
          <div style={{ marginTop: 14, marginBottom: 220 }}>
            {/* Estimated wait — server-derived from the cart items' real prep times (null when unknown). */}
            {estimatedWaitMinutes != null && (
              <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start', padding: 14, background: 'var(--surface-2)', borderRadius: 10, marginBottom: 12 }}>
                <Icon name="clock" size={16} style={{ color: 'var(--brand)', marginTop: 1 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 540, marginBottom: 2 }}>Estimated wait · {estimatedWaitMinutes} min</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>From the kitchen once your order is placed.</div>
                </div>
              </div>
            )}
            {/* Single server-authoritative total — no Subtotal/Tax/computed lines (D-06 / CART-01). */}
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', fontSize: 17, fontWeight: 600 }}>
              <span>Total</span>
              <span>{totalLabel}</span>
            </div>
          </div>
        )}
      </div>
      {!isEmpty && (
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, background: 'var(--surface)', borderTop: '1px solid var(--hairline)', padding: '14px 20px 22px' }}>
          <button
            className="btn btn-primary btn-lg btn-block"
            disabled={submitting}
            onClick={() => void onSubmit()}
          >
            {submitting ? (
              <>
                <span className="dot pulse" style={{ width: 8, height: 8, background: '#fff', marginRight: 8 }} />
                Sending…
              </>
            ) : (
              <>Send to kitchen · {totalLabel}</>
            )}
          </button>
          <div style={{ textAlign: 'center', fontSize: 11.5, color: 'var(--text-faint)', marginTop: 10 }}>
            Pay at end of meal. Bill closes when you check out.
          </div>
        </div>
      )}
    </>
  );
}
