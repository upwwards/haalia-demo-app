import { setupServer } from 'msw/node';
import { handlers } from './handlers';

// Shared MSW server instance used by Vitest (lifecycle in src/test/setup.ts).
export const server = setupServer(...handlers);
