import type { ErrorResponse } from '../api/types';

function base64url(input: string): string {
  // Environment-agnostic base64: the SAME handlers run under Node (vitest, `Buffer`) AND the
  // browser MSW worker (Playwright, no `Buffer` but `btoa`). Picking the available primitive lets
  // signedFakeJwt() produce a decodable token in both — a hard `Buffer.from` throws
  // "Buffer is not defined" in the browser and 500s the authenticate handler (05-06 E2E).
  const base64 =
    typeof Buffer !== 'undefined'
      ? Buffer.from(input, 'utf-8').toString('base64')
      : btoa(input);
  return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

// Build an unsigned-but-decodable JWT (header.payload.sig) carrying the given claims.
// jwt-decode only base64url-decodes the payload (no signature check), so this is enough
// for Plan 03's tests to read the `exp` claim.
export function signedFakeJwt(claims: { exp: number } & Record<string, unknown>): string {
  const header = base64url(JSON.stringify({ alg: 'none', typ: 'JWT' }));
  const payload = base64url(JSON.stringify(claims));
  return `${header}.${payload}.sig`;
}

// Seconds-since-epoch helper for building future/past `exp` values in tests.
export function nowPlus(seconds: number): number {
  return Math.floor(Date.now() / 1000) + seconds;
}

// Standard ErrorResponse envelope for MSW error handlers (re-exported for handler use).
export function errorBody(status: number, code: string, message?: string): ErrorResponse {
  return {
    status,
    code,
    message: message ?? code,
    timestamp: new Date().toISOString(),
    path: '/api/v1',
    validationErrors: [],
  };
}
