import '@testing-library/jest-dom';
import { afterAll, afterEach, beforeAll } from 'vitest';
import { server } from './server';

// Start MSW before all tests; fail loudly on any request without a handler.
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }));
// Reset per-test handler overrides so tests stay isolated.
afterEach(() => server.resetHandlers());
afterAll(() => server.close());
