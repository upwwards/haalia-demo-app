import { setupWorker } from 'msw/browser';
import { handlers } from './handlers';

// Browser sibling of server.ts (Node): the SAME handlers array, registered via
// msw/browser's setupWorker so a real dev-server / Playwright run intercepts REST.
// Only started behind config.mocking (main.tsx) — never in a production build (Pitfall 1).
export const worker = setupWorker(...handlers);
