import { http, HttpResponse } from 'msw';
import type {
  Feature,
  GuestCartResponse,
  GuestCartUpsertRequest,
  GuestCheckoutResponse,
  GuestEffectiveMenuResponse,
  GuestJwtResponse,
  GuestLoginRequest,
  GuestServiceLocationResponse,
  GuestServiceRequestCreateRequest,
  GuestServiceRequestResponse,
  GuestServiceSessionResponse,
  GuestVenueResponse,
  OrderResponse,
  PageGuestEffectiveMenuResponse,
  PageGuestServiceRequestResponse,
} from '../api/types';
import { errorBody, nowPlus, signedFakeJwt } from './jwt';

const BASE = '*/api/v1';

// ---------- Phase-2 menu fixtures ----------
// baseItem: no variants → top-level numeric price.
const baseItem: GuestEffectiveMenuResponse = {
  menuItemId: 'item-1',
  name: 'Margherita Pizza',
  description: 'Tomato, mozzarella, basil',
  primaryImageUrl: null,
  modelUrl: null,
  type: 'VEG',
  preparationTimeInMinutes: 12,
  categoryId: 'cat-mains',
  categoryName: 'Mains',
  price: 349,
  available: true,
  tags: ['popular'],
  hasVariants: false,
  variants: [],
};

// variantItem: hasVariants → top-level price is null; display derives from variants[].
const variantItem: GuestEffectiveMenuResponse = {
  menuItemId: 'item-2',
  name: 'Ribeye Steak',
  description: 'Choose your cut',
  primaryImageUrl: null,
  modelUrl: 'https://models.example/ribeye.glb',
  type: 'NON_VEG',
  preparationTimeInMinutes: 20,
  categoryId: 'cat-mains',
  categoryName: 'Mains',
  price: null,
  available: true,
  tags: [],
  hasVariants: true,
  variants: [
    {
      variantId: 'var-1',
      label: '250g',
      effectivePrice: 180,
      displayOrder: 1,
      available: true,
      isOverridden: false,
    },
    {
      variantId: 'var-2',
      label: '500g',
      effectivePrice: 320,
      displayOrder: 2,
      available: true,
      isOverridden: false,
    },
  ],
};

// unavailableItem: sold out — exercises available=false rendering. Lives on page 1.
const unavailableItem: GuestEffectiveMenuResponse = {
  menuItemId: 'item-3',
  name: 'Seasonal Dessert',
  description: 'Sold out',
  primaryImageUrl: null,
  modelUrl: null,
  type: 'VEG',
  preparationTimeInMinutes: 8,
  categoryId: 'cat-desserts',
  categoryName: 'Desserts',
  price: 120,
  available: false,
  tags: [],
  hasVariants: false,
  variants: [],
};

// Contract-typed default handlers (200 happy path), typed from api-docs.json.
export const handlers = [
  http.post(`${BASE}/auth/guest/authenticate`, async ({ request }) => {
    const body = (await request.json()) as GuestLoginRequest;
    if (body.clientSecret === 'wrong') {
      return HttpResponse.json(
        errorBody(401, 'INVALID_CREDENTIALS', 'Invalid guest credentials'),
        { status: 401 },
      );
    }
    return HttpResponse.json({
      accessToken: signedFakeJwt({ exp: nowPlus(3600) }),
      tokenType: 'Bearer',
      organizationId: 'org-1',
      venueId: 'venue-1',
      serviceLocationId: 'loc-1',
      role: 'GUEST',
    } satisfies GuestJwtResponse);
  }),

  http.post(`${BASE}/guest/service-sessions/get-or-create`, () =>
    HttpResponse.json({
      id: 'session-1',
      serviceLocationId: 'loc-1',
      status: 'ACTIVE',
      startedAt: new Date().toISOString(),
      endedAt: '',
    } satisfies GuestServiceSessionResponse),
  ),

  // ---------- Phase-2 GET happy-path handlers ----------
  http.get(`${BASE}/guest/venue/features`, () =>
    HttpResponse.json(['ORDER_PLACEMENT', 'MODEL_3D'] satisfies Feature[]),
  ),

  http.get(`${BASE}/guest/venue/get-venue-info`, () =>
    HttpResponse.json({
      id: 'venue-1',
      venueName: 'Verbena',
      phoneNumber: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      operationHours: [],
    } satisfies GuestVenueResponse),
  ),

  http.get(`${BASE}/guest/service-locations/current`, () =>
    HttpResponse.json({
      id: 'loc-1',
      name: 'Table 12',
      locationType: 'TABLE',
      venueId: 'venue-1',
      venueName: 'Verbena',
      active: true,
      showOrderHistory: true,
    } satisfies GuestServiceLocationResponse),
  ),

  // Two-page menu so the aggregator loop is exercised (Pitfall 2). Reads the EXACT
  // `pageNumber` param (Pitfall 5) — a wrong param name fails the multi-page assertion.
  http.get(`${BASE}/guest/menu/effective`, ({ request }) => {
    const url = new URL(request.url);
    const pageNumber = Number(url.searchParams.get('pageNumber') ?? '0');
    const isLast = pageNumber >= 1;
    return HttpResponse.json({
      content: isLast ? [unavailableItem] : [baseItem, variantItem],
      totalPages: 2,
      totalElements: 3,
      number: pageNumber,
      size: 20,
      numberOfElements: isLast ? 1 : 2,
      first: pageNumber === 0,
      last: isLast,
      empty: false,
    } satisfies PageGuestEffectiveMenuResponse);
  }),

  http.get(`${BASE}/guest/menu/item/:itemId`, () =>
    HttpResponse.json(variantItem satisfies GuestEffectiveMenuResponse),
  ),

  // ---------- Phase-3 cart handlers ----------
  // GET cart — Sync-on-Read default with two priced lines. sessionId is a PATH param.
  http.get(`${BASE}/guest/cart/:sessionId`, ({ params }) =>
    HttpResponse.json({
      serviceSessionId: String(params.sessionId),
      totalPrice: 818, // 349*2 + 120
      status: 'ACTIVE',
      items: [
        {
          menuItemId: 'item-1',
          menuItemName: 'Margherita Pizza',
          categoryName: 'Mains',
          quantity: 2,
          unitPrice: 349,
          itemTotal: 698,
        },
        {
          menuItemId: 'item-3',
          menuItemName: 'Seasonal Dessert',
          categoryName: 'Desserts',
          quantity: 1,
          unitPrice: 120,
          itemTotal: 120,
        },
      ],
    } satisfies GuestCartResponse),
  ),

  // PUT cart — full-replace. PATH has NO :sessionId (Pitfall 4); sessionId is in the body.
  // Echoes the posted items so debounce/full-replace reconcile tests can assert on the result;
  // unitPrice is looked up from the known menu fixtures, itemTotal/totalPrice are recomputed.
  http.put(`${BASE}/guest/cart`, async ({ request }) => {
    const body = (await request.json()) as GuestCartUpsertRequest;
    const priceOf = (menuItemId: string): number => {
      if (menuItemId === 'item-1') return 349;
      if (menuItemId === 'item-2') return 180; // variant var-1 (250g)
      if (menuItemId === 'item-3') return 120;
      return 100;
    };
    const items = body.items.map((i) => {
      const unitPrice = priceOf(i.menuItemId);
      return {
        menuItemId: i.menuItemId,
        menuItemName: `Item ${i.menuItemId}`,
        categoryName: 'Mains',
        quantity: i.quantity,
        unitPrice,
        itemTotal: unitPrice * i.quantity,
      };
    });
    return HttpResponse.json({
      serviceSessionId: body.serviceSessionId,
      totalPrice: items.reduce((sum, i) => sum + i.itemTotal, 0),
      status: 'ACTIVE',
      items,
    } satisfies GuestCartResponse);
  }),

  // DELETE cart — clear. 204 No Content (http() resolves to undefined). sessionId is a PATH param.
  http.delete(`${BASE}/guest/cart/:sessionId`, () => new HttpResponse(null, { status: 204 })),

  // POST submit — places the order, returns a PENDING OrderResponse. No request body.
  http.post(`${BASE}/guest/cart/:sessionId/submit`, ({ params }) =>
    HttpResponse.json({
      id: 'order-1',
      orderNumber: 1042,
      venueId: 'venue-1',
      serviceLocationId: 'loc-1',
      locationName: 'Table 12',
      serviceSessionId: String(params.sessionId),
      status: 'PENDING',
      source: 'GUEST',
      notes: '',
      totalPrice: 818,
      orderItems: [
        {
          id: 'oi-1',
          menuItemId: 'item-1',
          itemName: 'Margherita Pizza',
          categoryName: 'Mains',
          variantLabel: '',
          itemPrice: 349,
          quantity: 2,
          itemTotal: 698,
        },
        {
          id: 'oi-2',
          menuItemId: 'item-3',
          itemName: 'Seasonal Dessert',
          categoryName: 'Desserts',
          variantLabel: '',
          itemPrice: 120,
          quantity: 1,
          itemTotal: 120,
        },
      ],
      created: new Date().toISOString(),
      placedAt: new Date().toISOString(),
      confirmedAt: '',
      preparingAt: '',
      readyAt: '',
      deliveredAt: '',
      assignedWaiterId: '',
      assignedWaiterName: '',
      allergyFlag: false,
      allergyNote: '',
      priorityFlag: '',
      priorityNote: '',
    } satisfies OrderResponse),
  ),

  // ---------- Phase-3 orders handler ----------
  // GET orders — returns a BARE OrderResponse[] (not a Page envelope, unlike the menu).
  http.get(`${BASE}/guest/orders/:sessionId`, ({ params }) =>
    HttpResponse.json([
      {
        id: 'order-1',
        orderNumber: 1042,
        venueId: 'venue-1',
        serviceLocationId: 'loc-1',
        locationName: 'Table 12',
        serviceSessionId: String(params.sessionId),
        status: 'PREPARING',
        source: 'GUEST',
        notes: '',
        totalPrice: 698,
        orderItems: [
          {
            id: 'oi-1',
            menuItemId: 'item-1',
            itemName: 'Margherita Pizza',
            categoryName: 'Mains',
            variantLabel: '',
            itemPrice: 349,
            quantity: 2,
            itemTotal: 698,
          },
        ],
        created: new Date().toISOString(),
        placedAt: new Date().toISOString(),
        confirmedAt: new Date().toISOString(),
        preparingAt: new Date().toISOString(),
        readyAt: '',
        deliveredAt: '',
        assignedWaiterId: '',
        assignedWaiterName: '',
        allergyFlag: false,
        allergyNote: '',
        priorityFlag: '',
        priorityNote: '',
      },
    ] satisfies OrderResponse[]),
  ),

  // ---------- Phase-4 service-request handlers ----------
  // POST create — sessionId is in the BODY (serviceSessionId), NOT the path. Echoes the
  // posted requestType/message back on a fresh OPEN row (server-authoritative reconcile).
  http.post(`${BASE}/guest/service-requests`, async ({ request }) => {
    const body = (await request.json()) as GuestServiceRequestCreateRequest;
    return HttpResponse.json({
      id: 'sr-new',
      serviceLocationId: 'loc-1',
      serviceSessionId: body.serviceSessionId,
      requestType: body.requestType,
      status: 'OPEN',
      message: body.message ?? null,
      requestedAt: new Date().toISOString(),
      completedAt: null,
    } satisfies GuestServiceRequestResponse);
  }),

  // GET list — TWO pages keyed on the EXACT `pageNumber` param so the aggregator loop is
  // exercised; a wrong param name returns page 0 forever and fails the multi-page assertion.
  http.get(`${BASE}/guest/service-requests/:sessionId`, ({ request }) => {
    const url = new URL(request.url);
    const pageNumber = Number(url.searchParams.get('pageNumber') ?? '0');
    const isLast = pageNumber >= 1;
    const row = (id: string, status: GuestServiceRequestResponse['status']) =>
      ({
        id,
        serviceLocationId: 'loc-1',
        serviceSessionId: 'session-1',
        requestType: 'WATER',
        status,
        message: null,
        requestedAt: new Date().toISOString(),
        completedAt: status === 'COMPLETED' ? new Date().toISOString() : null,
      }) satisfies GuestServiceRequestResponse;
    const content = isLast
      ? [row('sr-3', 'COMPLETED')]
      : [row('sr-1', 'OPEN'), row('sr-2', 'ACKNOWLEDGED')];
    return HttpResponse.json({
      content,
      totalPages: 2,
      totalElements: 3,
      number: pageNumber,
      size: 20,
      numberOfElements: content.length,
      first: pageNumber === 0,
      last: isLast,
      empty: false,
    } satisfies PageGuestServiceRequestResponse);
  }),

  // POST cancel — BOTH ids in the path, no body. Returns the reconciled CANCELLED row.
  http.post(
    `${BASE}/guest/service-requests/:sessionId/:requestId/cancel`,
    ({ params }) =>
      HttpResponse.json({
        id: String(params.requestId),
        serviceLocationId: 'loc-1',
        serviceSessionId: String(params.sessionId),
        requestType: 'WATER',
        status: 'CANCELLED',
        message: null,
        requestedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      } satisfies GuestServiceRequestResponse),
  ),

  // ---------- Phase-4 checkout handler ----------
  // POST checkout — sessionId in the path, no body. Returns the real session summary.
  http.post(`${BASE}/guest/service-sessions/:sessionId/checkout`, ({ params }) =>
    HttpResponse.json({
      sessionId: String(params.sessionId),
      totalOrders: 3,
      totalSpent: 1516.5,
    } satisfies GuestCheckoutResponse),
  ),
];

// Reusable error-shape handlers (ErrorResponse envelope) for 403/404/409/422.
// Tests opt in per-case via `server.use(errorHandlers.forbidden('/some/path'))`.
export const errorHandlers = {
  forbidden: (path: string) =>
    http.post(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(403, 'FORBIDDEN'), { status: 403 }),
    ),
  notFound: (path: string) =>
    http.post(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(404, 'NOT_FOUND'), { status: 404 }),
    ),
  conflict: (path: string) =>
    http.post(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(409, 'CONFLICT'), { status: 409 }),
    ),
  unprocessable: (path: string) =>
    http.post(`${BASE}${path}`, () =>
      HttpResponse.json(
        {
          ...errorBody(422, 'VALIDATION_FAILED'),
          validationErrors: [
            { field: 'clientId', message: 'must not be blank', rejectedValue: '' },
          ],
        },
        { status: 422 },
      ),
    ),
  // GET variants — the POST-based factories above never intercept GET menu/venue
  // endpoints, so a 403/404 test would silently hit the default 200 handler (Pitfall 6 /
  // T-02-04). These intercept the real GET paths so error UX asserts against true status.
  forbiddenGet: (path: string) =>
    http.get(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(403, 'FORBIDDEN'), { status: 403 }),
    ),
  notFoundGet: (path: string) =>
    http.get(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(404, 'NOT_FOUND'), { status: 404 }),
    ),
  // ---------- Phase-3 verb-specific factories (Pitfall 7) ----------
  // The POST-based factories above never intercept a PUT or DELETE, so a cart-write or
  // clear error test would silently hit the 200/204 default. These match the real verb so
  // the error UX asserts against a true non-2xx status.
  conflictPost: (path: string) =>
    http.post(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(409, 'CONFLICT'), { status: 409 }),
    ),
  badRequestPost: (path: string) =>
    http.post(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(400, 'BAD_REQUEST'), { status: 400 }),
    ),
  badRequestPut: (path: string) =>
    http.put(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(400, 'BAD_REQUEST'), { status: 400 }),
    ),
  notFoundDelete: (path: string) =>
    http.delete(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(404, 'NOT_FOUND'), { status: 404 }),
    ),

  // ---------- Phase-4 verb-specific factories (service-requests + checkout) ----------
  // Every Phase-4 mutating endpoint is a POST, so each factory is a POST factory taking the
  // exact path. All bodies are the standard ErrorResponse envelope via `errorBody(...)` — NEVER
  // a GuestServiceRequestResponse (Pitfall 6: the spec mistypes SR 4xx bodies as the success
  // DTO, but the codebase's `ApiError.from` parses the ErrorResponse envelope). Opt-in per test
  // via `server.use(errorHandlers.<factory>(path))`; NONE are in the default `handlers` array.
  //
  // Mapping (documented errors verified against api-docs.json):
  //   create   POST /guest/service-requests                       → 400 (badRequestPost) + 422 (unprocessable, Pitfall 3)
  //   cancel   POST /guest/service-requests/:s/:r/cancel          → 409 (conflictPost "already processed") + 404 (notFoundPost)
  //   checkout POST /guest/service-sessions/:s/checkout           → 404 (notFoundPost) + 403 (forbiddenPost). NO 409 (Pitfall 4).

  // create — 422 validation (CUSTOM-without-message / empty). Pitfall 3: create's documented
  // status is 400, but Spring bean-validation can surface 422, so handle BOTH (mirrors
  // CartProvider.submit's `s === 400 || s === 422` branch). 400 is covered by `badRequestPost`.
  unprocessablePost: (path: string) =>
    http.post(`${BASE}${path}`, () =>
      HttpResponse.json(
        {
          ...errorBody(422, 'VALIDATION_FAILED'),
          validationErrors: [
            { field: 'message', message: 'must not be blank', rejectedValue: '' },
          ],
        },
        { status: 422 },
      ),
    ),

  // cancel/checkout — 404 (request/session not found). Explicit POST-named factory so a Phase-4
  // 404 test targets the real verb (the generic `notFound` above is also a POST factory; this
  // alias makes the verb unambiguous and matches the research/plan naming `notFoundPost`).
  notFoundPost: (path: string) =>
    http.post(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(404, 'NOT_FOUND'), { status: 404 }),
    ),

  // checkout — 403 (session not in guest's location). Explicit POST-named factory (the generic
  // `forbidden` above is also a POST factory; this alias mirrors `notFoundPost` for symmetry).
  // NOTE: there is deliberately NO checkout-409 factory — the checkout path documents only
  // 401/403/404 (Pitfall 4). The cancel-409 case uses `conflictPost`, where 409 IS documented.
  forbiddenPost: (path: string) =>
    http.post(`${BASE}${path}`, () =>
      HttpResponse.json(errorBody(403, 'FORBIDDEN'), { status: 403 }),
    ),
};
