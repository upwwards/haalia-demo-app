// Derive the SockJS /ws endpoint from config.apiBaseUrl — NEVER a hardcoded local WS URL
// (RT-01). The single env-driven origin (VITE_API_BASE_URL -> config.apiBaseUrl) is the only
// source of truth, so pointing the app at ngrok/prod needs no code change.
import { config } from '../config';

// Decision A2: pass the http(s) ORIGIN + /ws to new SockJS(...). SockJS negotiates the
// secure transport itself, so an https origin yields a secure (wss) connection — satisfying
// the "secure-from-https, never an insecure local socket" criterion WITHOUT emitting a raw
// websocket scheme of our own.
export function wsUrl(): string {
  const u = new URL(config.apiBaseUrl);
  return `${u.protocol}//${u.host}/ws`;
}
