// Real STOMP-over-SockJS transport behind the Phase-1 seam (RT-01/RT-02/RT-03). The fake
// (createFakeStompFactory) stays a drop-in test double because this implements the SAME
// StompFactory/StompClientLike contract. No live socket is opened in unit tests — the fake
// covers the seam; this is the production factory the RealtimeProvider injects.
import { Client, type IMessage } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import type {
  StompClientLike,
  StompConnectHandle,
  StompFactory,
} from './stompSeam';
import { wsUrl } from './wsUrl';

export const realStompFactory: StompFactory = ({
  token,
  getToken,
  onConnect,
}) => {
  let client: Client | null = null;
  // Track active subscriptions so deactivate() can unsubscribe them all (RT-03 no-storm).
  const subs = new Map<string, { unsubscribe(): void }>();

  // RT-03: read the CURRENT token at each (re)connect. @stomp/stompjs@7 captures
  // connectHeaders at activate() time, so a static `Bearer ${token}` string would re-present
  // the STALE token on every managed reconnect. The lazy getter (mirroring SessionProvider's
  // tokenRef live-mirror that reAuth() refreshes) reads the fresh JWT instead. Fall back to
  // the captured `token` only if no getter was supplied (backward-compat with the seam opts).
  const currentToken = (): string | null => (getToken ? getToken() : token);

  const subscribe: StompClientLike['subscribe'] = (dest, cb) => {
    // Delegates to the live Client; maps IMessage.body to the seam's { body } shape. The
    // envelope decode stays in unwrapFrame() at the provider — this layer never parses the
    // body inline (it passes the raw body string through untouched).
    const s = client!.subscribe(dest, (m: IMessage) => cb({ body: m.body }));
    subs.set(dest, s);
    return {
      unsubscribe() {
        s.unsubscribe();
        subs.delete(dest);
      },
    };
  };

  return {
    activate() {
      client = new Client({
        // CONTRACT (RT-01): SockJS endpoint via webSocketFactory, never the raw-broker-URL
        // option (the backend speaks SockJS, so the raw-WS option would fail the handshake). wsUrl()
        // derives the http(s) origin + /ws from config; SockJS negotiates wss from https.
        webSocketFactory: () => new SockJS(wsUrl()),
        reconnectDelay: 4000, // >0 enables the managed reconnect loop
        heartbeatIncoming: 0, // contract: heart-beat 0,0
        heartbeatOutgoing: 0,
        // RT-03: rebuild connectHeaders from the LAZY token getter immediately before EVERY
        // (re)connect, so a reconnect after reAuth() carries the FRESH Bearer token — never a
        // value captured at first activate(). The token lives ONLY in the CONNECT frame
        // (never in the URL); never logged.
        beforeConnect: () => {
          if (client) {
            client.connectHeaders = {
              Authorization: `Bearer ${currentToken() ?? ''}`,
            };
          }
        },
        // RT-01/Pitfall 2: subscriptions register ONLY after the CONNECTED frame. The factory
        // owns connect-timing (RESEARCH Open-Q1 rec (a)) and hands the provider a subscribe
        // handle here so the two guest topics are registered at connect time.
        onConnect: () => {
          const handle: StompConnectHandle = { subscribe };
          onConnect?.(handle);
        },
      });
      client.activate();
    },
    subscribe,
    async deactivate() {
      // RT-03 (Pitfall 3): unsubscribe all, then await the v7 deactivate() Promise which
      // stops the reconnect loop, then null the client so a CLOSED/expired session is not
      // hammered with reconnects.
      subs.forEach((s) => s.unsubscribe());
      subs.clear();
      await client?.deactivate();
      client = null;
    },
  } satisfies StompClientLike;
};
