import { describe, expect, it } from 'vitest';
import { createFakeStompFactory, unwrapFrame } from './stompSeam';

describe('STOMP seam (TEST-02)', () => {
  it('delivers the unwrapped .data of a { destination, data } envelope', () => {
    const { factory, push } = createFakeStompFactory();
    const client = factory({ token: 't', sessionId: 's1' });
    client.activate();

    const dest = '/topic/guest/session/s1/orders';
    const received: Array<{ status: string } | null> = [];
    client.subscribe(dest, (msg) =>
      received.push(unwrapFrame<{ status: string }>(msg.body)),
    );

    push(dest, { destination: dest, data: { status: 'PREPARING' } });

    expect(received).toEqual([{ status: 'PREPARING' }]);
  });

  it('CR-03: safely returns null for a malformed/unparseable frame (never throws)', () => {
    // A non-JSON body, a non-object frame, and a frame missing `.data` must all be ignored
    // safely — unwrapFrame is called on UNTRUSTED socket input and must never throw into the
    // STOMP message dispatcher nor hand the caller a value it would deref as `undefined.id`.
    expect(unwrapFrame('not json at all {')).toBeNull();
    expect(unwrapFrame('"a bare string"')).toBeNull();
    expect(unwrapFrame('42')).toBeNull();
    expect(unwrapFrame('null')).toBeNull();
    expect(unwrapFrame(JSON.stringify({ destination: '/x' }))).toBeNull(); // no .data
    expect(
      unwrapFrame(JSON.stringify({ destination: '/x', data: null })),
    ).toBeNull();
    // The happy path still unwraps `.data`.
    expect(
      unwrapFrame(JSON.stringify({ destination: '/x', data: { id: 'o1' } })),
    ).toEqual({ id: 'o1' });
  });

  it('stops delivery after deactivate()', () => {
    const { factory, push } = createFakeStompFactory();
    const client = factory({ token: 't', sessionId: 's1' });
    client.activate();

    const dest = '/topic/x';
    const received: unknown[] = [];
    client.subscribe(dest, (msg) => received.push(unwrapFrame(msg.body)));

    client.deactivate();
    push(dest, { destination: dest, data: { n: 1 } });

    expect(received).toHaveLength(0);
  });
});
