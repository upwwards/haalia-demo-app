import { useContext } from 'react';
import { RealtimeCtx, type RealtimeState } from './RealtimeProvider';

// Context consumer hook mirroring useSession verbatim: read the context, null-guard-throw if
// used outside the provider, return the typed state.
export function useRealtime(): RealtimeState {
  const v = useContext(RealtimeCtx);
  if (!v) throw new Error('useRealtime must be used inside <RealtimeProvider>');
  return v;
}
