import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { act, render, waitFor } from '@testing-library/react';
import { useMemo, useState, type ReactNode } from 'react';
import {
  SessionCtx,
  type SessionState,
} from '../features/session/SessionProvider';
import {
  createFakeStompFactory,
  type StompClientLike,
  type StompConnectHandle,
  type StompFactory,
} from './stompSeam';
import type {
  GuestServiceRequestResponse,
  OrderResponse,
} from '../api/types';

const SESSION_ID = 'session-1';
const ORDERS_TOPIC = `/topic/guest/session/${SESSION_ID}/orders`;
const SR_TOPIC = `/topic/guest/session/${SESSION_ID}/service-requests`;

// Mock the two data hooks so the RealtimeProvider's useOrders()/useServiceRequests() resolve to
// SHARED spy instances the test owns. These hooks are NOT context-backed (each call is its own
// state), so the only deterministic way to assert "the push reached applyLiveOrder/refresh" is to
// observe the very instance the provider wires into — a module mock gives us exactly that. The
// real merge-by-id semantics are already proven in useOrders/useServiceRequests' own test suites
// (RT-02); here we prove the PROVIDER's connect/unwrap/merge/reconnect/resync/deactivate wiring.
const ordersSpies = {
  applyLiveOrder: vi.fn<(o: OrderResponse) => void>(),
  refresh: vi.fn<() => void>(),
  orders: [] as OrderResponse[],
};
const srSpies = {
  applyLiveRequest: vi.fn<(sr: GuestServiceRequestResponse) => void>(),
  refresh: vi.fn<() => void>(),
  requests: [] as GuestServiceRequestResponse[],
};

vi.mock('../features/orders/useOrders', () => ({
  useOrders: () => ({
    orders: ordersSpies.orders,
    status: 'ready' as const,
    error: null,
    refresh: ordersSpies.refresh,
    applyLiveOrder: ordersSpies.applyLiveOrder,
  }),
}));
vi.mock('../features/serviceRequests/useServiceRequests', () => ({
  useServiceRequests: () => ({
    requests: srSpies.requests,
    status: 'ready' as const,
    error: null,
    create: vi.fn(),
    cancel: vi.fn(),
    refresh: srSpies.refresh,
    applyLiveRequest: srSpies.applyLiveRequest,
  }),
}));

// Imported AFTER the mocks are registered (vi.mock is hoisted, so order is safe).
import { RealtimeProvider } from './RealtimeProvider';

// A test SessionProvider whose token/closed live in REACT STATE — mirroring the real
// SessionProvider, where reAuth() calls setTokenState (a re-render) so the fresh token flows down
// to the RealtimeProvider's tokenRef mirror.
function ControlledSession({
  token,
  closed,
  reAuth,
  children,
}: {
  token: string;
  closed: boolean;
  reAuth: SessionState['reAuth'];
  children: ReactNode;
}) {
  const value = useMemo<SessionState>(
    () =>
      ({
        token,
        expiresAt: null,
        sessionId: SESSION_ID,
        venueId: 'venue-1',
        serviceLocationId: 'loc-1',
        status: closed ? 'CLOSED' : 'ACTIVE',
        closed,
        authenticate: vi.fn(async () => {}),
        reAuth,
        checkout: vi.fn(async () => undefined),
        checkoutSummary: null,
      }) as SessionState,
    [token, closed, reAuth],
  );
  return <SessionCtx.Provider value={value}>{children}</SessionCtx.Provider>;
}

// Wrap a fake factory so the test can: capture the getToken handed to it, re-fire onConnect to
// simulate a managed reconnect, and observe deactivate(). Delegates push/subscribe to the inner
// fake so frames still flow through the real seam (and so the provider's unwrapFrame runs).
function instrumentedFactory(): {
  factory: StompFactory;
  push: (dest: string, frame: { destination: string; data: unknown }) => void;
  reconnect: () => void;
  deactivateCount: () => number;
  capturedGetToken: () => (() => string | null) | undefined;
} {
  const fake = createFakeStompFactory();
  let onConnectCb: ((h: StompConnectHandle) => void) | undefined;
  let getTokenOpt: (() => string | null) | undefined;
  let deactivations = 0;
  let lastHandle: StompConnectHandle | undefined;

  const factory: StompFactory = (opts) => {
    getTokenOpt = opts.getToken;
    onConnectCb = opts.onConnect;
    const inner = fake.factory({
      ...opts,
      onConnect: (handle) => {
        lastHandle = handle;
        onConnectCb?.(handle);
      },
    });
    const wrapped: StompClientLike = {
      activate: inner.activate,
      subscribe: inner.subscribe,
      async deactivate() {
        deactivations += 1;
        await inner.deactivate();
      },
    };
    return wrapped;
  };

  return {
    factory,
    push: fake.push,
    // A managed reconnect: the factory's onConnect fires AGAIN with a fresh subscribe handle.
    reconnect: () => {
      if (lastHandle) onConnectCb?.(lastHandle);
    },
    deactivateCount: () => deactivations,
    capturedGetToken: () => getTokenOpt,
  };
}

function orderFrame(id: string, status: OrderResponse['status'] = 'PREPARING') {
  const data: OrderResponse = {
    id,
    orderNumber: 1,
    venueId: 'venue-1',
    serviceLocationId: 'loc-1',
    locationName: 'Table 12',
    serviceSessionId: SESSION_ID,
    status,
    source: 'GUEST',
    notes: '',
    totalPrice: 100,
    orderItems: [],
    created: '',
    placedAt: '',
    confirmedAt: '',
    preparingAt: '',
    readyAt: '',
    deliveredAt: '',
    assignedWaiterId: '',
    assignedWaiterName: '',
    allergyFlag: false,
    allergyNote: '',
    priorityFlag: '',
    priorityNote: '',
  };
  return { destination: ORDERS_TOPIC, data };
}

function srFrame(
  id: string,
  status: GuestServiceRequestResponse['status'] = 'OPEN',
) {
  const data: GuestServiceRequestResponse = {
    id,
    serviceLocationId: 'loc-1',
    serviceSessionId: SESSION_ID,
    requestType: 'WATER',
    status,
    message: null,
    requestedAt: '',
    completedAt: null,
  };
  return { destination: SR_TOPIC, data };
}

beforeEach(() => {
  ordersSpies.applyLiveOrder.mockClear();
  ordersSpies.refresh.mockClear();
  srSpies.applyLiveRequest.mockClear();
  srSpies.refresh.mockClear();
});
afterEach(() => vi.clearAllMocks());

// Mount RealtimeProvider with a controlled session + injected fake factory. Returns helpers + a
// setter to flip `closed` and the reAuth spy (which drives the token state on call).
function mount(inst: ReturnType<typeof instrumentedFactory>) {
  let setClosed: (v: boolean) => void = () => {};
  const reAuth = vi.fn(async () => {});

  function Root() {
    const [closed, _setClosed] = useState(false);
    const [token, setToken] = useState('token-initial');
    setClosed = _setClosed;
    // Like the real SessionProvider, reAuth sets the token STATE → re-render → the provider's
    // tokenRef mirror picks up the fresh token (so the lazy getter reads it on the re-CONNECT).
    reAuth.mockImplementation(async () => {
      act(() => setToken('token-refreshed'));
    });
    return (
      <ControlledSession token={token} closed={closed} reAuth={reAuth}>
        <RealtimeProvider factory={inst.factory} />
      </ControlledSession>
    );
  }

  const utils = render(<Root />);
  return {
    ...utils,
    reAuth,
    setClosed: (v: boolean) => act(() => setClosed(v)),
  };
}

describe('RealtimeProvider (RT-01/RT-02/RT-03)', () => {
  it('subscribes to BOTH topics on connect and merges an order push (applyLiveOrder ran on .data)', async () => {
    const inst = instrumentedFactory();
    mount(inst);

    act(() => inst.push(ORDERS_TOPIC, orderFrame('order-live')));

    await waitFor(() =>
      expect(ordersSpies.applyLiveOrder).toHaveBeenCalledTimes(1),
    );
    // The provider unwrapped the {destination,data} envelope and passed `.data` to applyLiveOrder.
    expect(ordersSpies.applyLiveOrder.mock.calls[0][0]).toMatchObject({
      id: 'order-live',
      status: 'PREPARING',
    });
  });

  it('merges a service-request push via applyLiveRequest', async () => {
    const inst = instrumentedFactory();
    mount(inst);

    act(() => inst.push(SR_TOPIC, srFrame('sr-live')));

    await waitFor(() =>
      expect(srSpies.applyLiveRequest).toHaveBeenCalledTimes(1),
    );
    expect(srSpies.applyLiveRequest.mock.calls[0][0]).toMatchObject({
      id: 'sr-live',
      requestType: 'WATER',
    });
  });

  it('routes a push to the CORRECT merge seam by topic (orders push never hits the SR seam)', async () => {
    const inst = instrumentedFactory();
    mount(inst);

    act(() => inst.push(ORDERS_TOPIC, orderFrame('order-x')));
    await waitFor(() => expect(ordersSpies.applyLiveOrder).toHaveBeenCalled());
    // The two topics are wired to distinct seams (RT-02 idempotency lives in those seams).
    expect(srSpies.applyLiveRequest).not.toHaveBeenCalled();
  });

  it('reconnect triggers reAuth() THEN both refresh() resyncs (RT-03)', async () => {
    const inst = instrumentedFactory();
    const m = mount(inst);

    // First connect already happened on mount — no reAuth/resync on the initial connect.
    expect(m.reAuth).not.toHaveBeenCalled();
    expect(ordersSpies.refresh).not.toHaveBeenCalled();
    expect(srSpies.refresh).not.toHaveBeenCalled();

    await act(async () => {
      inst.reconnect();
      await Promise.resolve();
    });

    await waitFor(() => expect(m.reAuth).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(ordersSpies.refresh).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(srSpies.refresh).toHaveBeenCalledTimes(1));

    // reAuth ran BEFORE the resyncs (await reAuth() precedes refresh() in the provider).
    expect(m.reAuth.mock.invocationCallOrder[0]).toBeLessThan(
      ordersSpies.refresh.mock.invocationCallOrder[0],
    );
    expect(m.reAuth.mock.invocationCallOrder[0]).toBeLessThan(
      srSpies.refresh.mock.invocationCallOrder[0],
    );
  });

  it("reconnect's getToken() returns the post-reAuth token (RT-03 token propagation)", async () => {
    const inst = instrumentedFactory();
    const m = mount(inst);

    const getToken = inst.capturedGetToken();
    expect(getToken).toBeTypeOf('function');
    // Before reAuth the live getter reads the initial token.
    expect(getToken!()).toBe('token-initial');

    await act(async () => {
      await m.reAuth();
    });

    // After reAuth swapped the session token, the SAME captured getter (the value 05-01 reads in
    // beforeConnect on the re-CONNECT) returns the FRESH token — proving the reconnect CONNECT
    // frame carries the post-reAuth JWT, never a captured stale string.
    await waitFor(() => expect(getToken!()).toBe('token-refreshed'));
  });

  it('flipping closed=true deactivates the client and stops further delivery (RT-03 no-storm)', async () => {
    const inst = instrumentedFactory();
    const m = mount(inst);
    expect(inst.deactivateCount()).toBe(0);

    m.setClosed(true);
    await waitFor(() => expect(inst.deactivateCount()).toBe(1));

    // Subscriptions were torn down on deactivate, so a subsequent push delivers nothing.
    act(() => inst.push(ORDERS_TOPIC, orderFrame('order-after-close')));
    await Promise.resolve();
    expect(ordersSpies.applyLiveOrder).not.toHaveBeenCalled();
  });

  it('CR-03: a malformed frame (missing .data) is safely ignored — the merge seam is never called', async () => {
    const inst = instrumentedFactory();
    mount(inst);

    // A frame with no `data` field: unwrapFrame returns null and the provider drops it, so
    // applyLiveOrder is never invoked with an undefined payload (no `undefined.id` deref/throw).
    act(() =>
      inst.push(ORDERS_TOPIC, {
        destination: ORDERS_TOPIC,
      } as { destination: string; data: unknown }),
    );
    await Promise.resolve();
    expect(ordersSpies.applyLiveOrder).not.toHaveBeenCalled();

    // A subsequent WELL-FORMED frame still merges — the bad frame did not break the subscription.
    act(() => inst.push(ORDERS_TOPIC, orderFrame('order-ok')));
    await waitFor(() =>
      expect(ordersSpies.applyLiveOrder).toHaveBeenCalledTimes(1),
    );
  });

  it('CR-02: a reconnect whose reAuth() rejects does not throw and skips the resyncs (fail safe/quiet)', async () => {
    const inst = instrumentedFactory();
    const m = mount(inst);

    // The reconnect re-auth rejects (e.g. ApiError(401) when the QR creds are gone). The detached
    // task must swallow it (no unhandled rejection) and must NOT run the REST resyncs.
    m.reAuth.mockImplementation(async () => {
      throw new Error('reAuth failed on reconnect');
    });

    await act(async () => {
      inst.reconnect();
      await Promise.resolve();
      await Promise.resolve();
    });

    await waitFor(() => expect(m.reAuth).toHaveBeenCalledTimes(1));
    // reAuth threw → resyncs are skipped (the catch bailed before refresh()).
    expect(ordersSpies.refresh).not.toHaveBeenCalled();
    expect(srSpies.refresh).not.toHaveBeenCalled();
  });

  it('never connects for a CLOSED session (gate) and never subscribes', async () => {
    const inst = instrumentedFactory();
    const m = mount(inst);
    m.setClosed(true);
    await waitFor(() => expect(inst.deactivateCount()).toBe(1));

    act(() => inst.push(SR_TOPIC, srFrame('sr-blocked')));
    await Promise.resolve();
    expect(srSpies.applyLiveRequest).not.toHaveBeenCalled();
  });
});
