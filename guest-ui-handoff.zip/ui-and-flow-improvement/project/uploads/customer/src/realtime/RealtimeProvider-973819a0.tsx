// RealtimeProvider (RT-01/RT-02/RT-03): the orchestration layer where the Phase 1–4 seams
// meet the new STOMP transport. It activates an INJECTABLE STOMP client (defaulting to the
// real SockJS-backed realStompFactory) ONLY while the session is ACTIVE && !closed && has a
// token && a sessionId; subscribes — inside the factory's onConnect affordance only — to the
// two verified guest topics; unwraps each {destination,data} envelope via unwrapFrame<T>()
// into useOrders.applyLiveOrder / useServiceRequests.applyLiveRequest; and on a reconnect
// re-authenticates (SessionProvider.reAuth — fresh JWT), re-subscribes from scratch, and
// REST-resyncs via both refresh() seams. On checkout/expiry (closed flips true) or unmount it
// deactivates the client so a CLOSED session is not hammered with reconnects (no storm).
//
// The factory is injectable so the SAME provider runs the real client in production and the
// deterministic createFakeStompFactory double in tests / the 05-04 E2E.
//
// MOUNT ORDER: this provider consumes useOrders/useServiceRequests (which need SessionProvider
// + ToastProvider above them), so it mounts BELOW SessionProvider/ToastProvider/CartProvider in
// main.tsx (05-04 owns the mount). It is written assuming those contexts exist above it.
import {
  createContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { useSession } from '../features/session/useSession';
import { useOrders } from '../features/orders/useOrders';
import { useServiceRequests } from '../features/serviceRequests/useServiceRequests';
import { realStompFactory } from './stompClient';
import { unwrapFrame, type StompFactory } from './stompSeam';
import type {
  GuestServiceRequestResponse,
  OrderResponse,
} from '../api/types';

// Minimal consumer-facing state. `connected` is the only signal a page/test needs today;
// the provider's real job (lifecycle + wiring) is all side effect, not rendered value.
export interface RealtimeState {
  connected: boolean;
}

export const RealtimeCtx = createContext<RealtimeState | null>(null);

// The two verified guest topics (per the WS contract / 05-PATTERNS). The provider ONLY ever
// builds its OWN /topic/guest/session/${sessionId}/* paths from the session's sessionId — it
// never subscribes to a venue/other-session topic (T-05-09).
const ordersTopic = (sessionId: string): string =>
  `/topic/guest/session/${sessionId}/orders`;
const serviceRequestsTopic = (sessionId: string): string =>
  `/topic/guest/session/${sessionId}/service-requests`;

export function RealtimeProvider({
  children,
  factory = realStompFactory,
}: {
  children?: ReactNode;
  factory?: StompFactory;
}) {
  const { token, sessionId, status, closed, reAuth } = useSession();
  const { applyLiveOrder, refresh: refreshOrders } = useOrders();
  const { applyLiveRequest, refresh: refreshSRs } = useServiceRequests();

  const [connected, setConnected] = useState(false);

  // RT-03 lazy token source: the factory is handed a getToken GETTER (NOT a captured token
  // string), so 05-01's beforeConnect reads the CURRENT token at EVERY (re)connect. A reconnect
  // after reAuth() then carries the FRESH JWT onto the re-CONNECT frame with no deactivate()/
  // activate() cycle. The ref mirrors the session token (the SessionProvider.tokenRef idiom).
  const tokenRef = useRef<string | null>(token);
  useEffect(() => {
    tokenRef.current = token;
  }, [token]);

  // Gate on token PRESENCE, not its value: a reAuth() that swaps the token string must NOT
  // re-run the activate effect (which would deactivate/reactivate the live client mid-session
  // and defeat the seamless-reconnect goal). The lazy tokenRef getter carries the fresh value
  // to the next CONNECT frame; the effect only cares whether a token exists at all.
  const hasToken = token != null && token !== '';

  // Keep the latest session-derived callbacks/values in refs so the activate effect can read
  // current values from inside onConnect without re-running (and re-activating) every time a
  // hook identity changes. The effect itself is keyed only on the gate inputs below.
  const reAuthRef = useRef(reAuth);
  const refreshOrdersRef = useRef(refreshOrders);
  const refreshSRsRef = useRef(refreshSRs);
  const applyLiveOrderRef = useRef(applyLiveOrder);
  const applyLiveRequestRef = useRef(applyLiveRequest);
  useEffect(() => {
    reAuthRef.current = reAuth;
    refreshOrdersRef.current = refreshOrders;
    refreshSRsRef.current = refreshSRs;
    applyLiveOrderRef.current = applyLiveOrder;
    applyLiveRequestRef.current = applyLiveRequest;
  });

  useEffect(() => {
    // Session-gate (T-05-03): the socket may exist ONLY for an ACTIVE, open session that has a
    // token and a sessionId. Any other state → no client (and the cleanup below tears down an
    // existing one), so a CLOSED/expired session is never reconnected against.
    if (!(status === 'ACTIVE' && !closed && hasToken && sessionId)) return;

    // First-connect-vs-reconnect discriminator. The factory's onConnect fires once per CONNECTED
    // frame: the first is the initial connect (no reAuth/resync); every subsequent fire is a
    // managed reconnect and triggers the re-auth + REST resync path (RT-03).
    let hasConnected = false;

    // CR-02 liveness flag: the reconnect re-auth/resync runs across await boundaries, so the
    // session can be torn down (checkout/expiry/unmount → cleanup) mid-flight. The detached
    // task re-checks this before each subsequent step and bails if the effect was cleaned up,
    // so a closed/unmounted session is never resynced behind its own teardown.
    let live = true;

    const client = factory({
      // RT-03: pass the lazy getter, NEVER a captured token string. The factory reads this in
      // beforeConnect at each (re)connect, so the post-reAuth() token propagates automatically.
      // The seam's `token` field is backward-compat only; sourced from the same live ref (never
      // a value frozen at activate-time) so even the fallback path can't present a stale token.
      token: tokenRef.current ?? '',
      getToken: () => tokenRef.current,
      sessionId,
      // RT-01 / Pitfall 2: subscriptions register ONLY here, inside onConnect (after CONNECTED),
      // never at activate-time. The handle is re-supplied on every (re)connect, so reconnects
      // re-subscribe from scratch.
      onConnect: (handle) => {
        const id = sessionId;
        // Re-subscribe from scratch on every connect. CR-03: unwrapFrame is total — a
        // malformed/unparseable frame (or one missing `.data`) returns null and is dropped
        // here, so the merge seam only ever receives a well-formed payload (no `undefined.id`).
        handle.subscribe(ordersTopic(id), (msg) => {
          const o = unwrapFrame<OrderResponse>(msg.body);
          if (o && o.id) applyLiveOrderRef.current(o);
        });
        handle.subscribe(serviceRequestsTopic(id), (msg) => {
          const sr = unwrapFrame<GuestServiceRequestResponse>(msg.body);
          if (sr && sr.id) applyLiveRequestRef.current(sr);
        });
        setConnected(true);

        if (hasConnected) {
          // RECONNECT path (RT-03): re-auth FIRST (single-flight — refreshes the session token,
          // which the tokenRef-mirror effect picks up so the getter reads it on the re-CONNECT),
          // THEN REST-resync both hooks (the server buffers nothing across the gap).
          //
          // CR-02: this detached task is wrapped in try/catch so a rejecting reAuth() (it throws
          // ApiError(401) when the QR creds are gone) can NEVER become an unhandled rejection, and
          // liveness is re-checked after each await so a session torn down mid-flight (cleanup ran,
          // live=false) bails before re-subscribing/resyncing against a closing session. Failures
          // fail safe and quiet (no console logging — app convention); the existing session-gate +
          // http() 401 re-auth path own recovery, never this background task.
          void (async () => {
            try {
              await reAuthRef.current();
              if (!live) return;
              refreshOrdersRef.current();
              if (!live) return;
              refreshSRsRef.current();
            } catch {
              // reAuth/resync failed on reconnect — fail safe/quiet; do not log (token safety).
            }
          })();
        } else {
          hasConnected = true;
        }
      },
    });

    client.activate();

    return () => {
      // Checkout (closed → true), expiry, gate-failure, or unmount: stop the client (and its
      // managed reconnect loop) — no storm against a closed session (T-05-03 / Pitfall 3).
      // CR-02: mark the in-flight reconnect task dead so it bails before resyncing a torn-down
      // session (it re-checks `live` after each await).
      live = false;
      setConnected(false);
      void client.deactivate();
    };
    // Keyed ONLY on the gate inputs: identity churn of the hook callbacks (read via refs) must
    // not deactivate/reactivate the live client mid-session.
  }, [status, closed, hasToken, sessionId, factory]);

  const value = useMemo<RealtimeState>(() => ({ connected }), [connected]);

  return <RealtimeCtx.Provider value={value}>{children}</RealtimeCtx.Provider>;
}
