import { afterEach, describe, expect, it, vi } from 'vitest';

// wsUrl() derives the SockJS /ws endpoint from config.apiBaseUrl. We stub the config
// module per-case so the http-origin and https-origin paths are both asserted (RT-01).
vi.mock('../config', () => ({
  config: { apiBaseUrl: 'http://localhost:8080', mocking: false },
}));

afterEach(() => {
  vi.resetModules();
});

async function wsUrlWith(apiBaseUrl: string): Promise<string> {
  vi.resetModules();
  vi.doMock('../config', () => ({ config: { apiBaseUrl, mocking: false } }));
  const { wsUrl } = await import('./wsUrl');
  return wsUrl();
}

describe('wsUrl() (RT-01)', () => {
  it('derives http origin + /ws from an http apiBaseUrl', async () => {
    const url = await wsUrlWith('http://localhost:8080');
    expect(url).toBe('http://localhost:8080/ws');
  });

  it('yields an https origin + /ws for an https apiBaseUrl (SockJS upgrades to wss)', async () => {
    const url = await wsUrlWith('https://abc.ngrok.app');
    expect(url).toBe('https://abc.ngrok.app/ws');
  });

  it('preserves host and port and always ends in /ws', async () => {
    const url = await wsUrlWith('http://127.0.0.1:9999');
    expect(url).toBe('http://127.0.0.1:9999/ws');
    expect(url.endsWith('/ws')).toBe(true);
  });

  it('never produces a raw ws://localhost / wss://localhost scheme', async () => {
    const http = await wsUrlWith('http://localhost:8080');
    const https = await wsUrlWith('https://localhost:8443');
    expect(http).not.toContain('ws://localhost');
    expect(http).not.toContain('wss://localhost');
    expect(https).not.toContain('ws://localhost');
    expect(https).not.toContain('wss://localhost');
  });
});
