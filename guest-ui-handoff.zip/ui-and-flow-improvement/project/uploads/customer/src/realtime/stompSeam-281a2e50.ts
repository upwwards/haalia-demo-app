// Injectable realtime seam (TEST-02). Phase 1 ships the SEAM only — no live SockJS/STOMP
// connection (those deps are installed for Phase 5). Tests substitute the fake factory;
// MSW cannot intercept SockJS, so realtime is tested at this seam.

export interface StompClientLike {
  activate(): void;
  deactivate(): Promise<void> | void;
  subscribe(
    dest: string,
    cb: (msg: { body: string }) => void,
  ): { unsubscribe(): void };
}

// The RestoMaster STOMP envelope: the message body is JSON { destination, data }.
export type StompFrame<T> = { destination: string; data: T };

// A connect-time handle the factory passes to onConnect (RT-01): subscriptions register
// ONLY after the CONNECTED frame. It exposes exactly StompClientLike['subscribe'] so the
// provider stays transport-agnostic and the change to the seam is purely additive.
export interface StompConnectHandle {
  subscribe: StompClientLike['subscribe'];
}

// Factory opts. `token` stays for backward-compat (the existing fake/tests pass a string),
// but the JWT SHOULD be supplied via the LAZY `getToken` getter so the real client reads the
// CURRENT token at each CONNECT — a reconnect after reAuth() then carries the fresh token
// (RT-03), never a value captured at first activate(). `onConnect` lets the factory own
// connect-timing (RESEARCH Open-Q1 rec (a)): it is invoked once CONNECTED with a subscribe
// handle so the provider can register topics without sending SUBSCRIBE before CONNECTED.
export type StompFactory = (opts: {
  token: string;
  sessionId: string;
  getToken?: () => string | null;
  onConnect?: (client: StompConnectHandle) => void;
}) => StompClientLike;

// Typed unwrap of the envelope. Consumers MUST read `.data`; baking it into this helper
// (and the StompFrame type) means Phase 5 cannot forget the JSON.parse(msg.body).data step.
//
// CR-03 (RESEARCH §V5 — treat WS payloads as untrusted input): the body arrives off an
// untrusted socket, so this is TOTAL — it never throws into the STOMP message dispatcher.
// A non-JSON body, a non-object frame, or a frame missing `.data` returns null; the caller
// skips a null and never derefs an undefined payload (e.g. `undefined.id`). On a well-formed
// `{ destination, data }` envelope it returns `.data` exactly as before.
export function unwrapFrame<T>(body: string): T | null {
  try {
    const parsed = JSON.parse(body) as unknown;
    if (
      parsed != null &&
      typeof parsed === 'object' &&
      'data' in parsed &&
      (parsed as { data: unknown }).data != null
    ) {
      return (parsed as StompFrame<T>).data;
    }
    return null;
  } catch {
    return null;
  }
}

// Test fake: returns a StompFactory plus a push() to deliver framed messages to subscribers.
export function createFakeStompFactory(): {
  factory: StompFactory;
  push(dest: string, frame: StompFrame<unknown>): void;
} {
  interface Sub {
    dest: string;
    cb: (msg: { body: string }) => void;
  }
  let subs: Sub[] = [];
  let active = false;

  const factory: StompFactory = (opts) => {
    const subscribe: StompClientLike['subscribe'] = (dest, cb) => {
      const sub: Sub = { dest, cb };
      subs.push(sub);
      return {
        unsubscribe() {
          subs = subs.filter((s) => s !== sub);
        },
      };
    };
    return {
      activate() {
        active = true;
        // Model "subscribe inside onConnect" (RT-01): if the provider supplied an
        // onConnect affordance, invoke it synchronously on activate with a subscribe
        // handle. The existing test path (subscribe directly after activate, no onConnect)
        // is unaffected — onConnect is optional.
        opts?.onConnect?.({ subscribe });
      },
      deactivate() {
        active = false;
        subs = [];
      },
      subscribe,
    };
  };

  function push(dest: string, frame: StompFrame<unknown>): void {
    if (!active) return;
    const body = JSON.stringify(frame);
    subs.filter((s) => s.dest === dest).forEach((s) => s.cb({ body }));
  }

  return { factory, push };
}
