import { Routes, Route, Navigate, useParams, useLocation } from 'react-router-dom';
import { HaliaRoot, Icon, useTheme } from '@halia/ui';
import { QRLandingPage } from './pages/QRLandingPage';
import { MenuPage } from './pages/MenuPage';
import { ItemDetailPage } from './pages/ItemDetailPage';
import { CartPage } from './pages/CartPage';
import { TrackingPage } from './pages/TrackingPage';
import { ServiceRequestPage } from './pages/ServiceRequestPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { SessionExpiredPage } from './pages/SessionExpiredPage';
import { InvalidQRPage } from './pages/InvalidQRPage';

// Folds the legacy variants route into the item detail page: the full live variant list
// now renders on the detail screen, so this preserves any old variant links/bookmarks by
// redirecting to the item detail path (absolute target derived from the :id param).
function MenuVariantsRedirect() {
  const { id } = useParams<{ id: string }>();
  return <Navigate to={id ? `/menu/${id}` : '/menu'} replace />;
}

// Root → /welcome, PRESERVING the query string. A table QR may encode the bare origin with the
// guest creds as ?clientId=…&clientSecret=…&venueId=…&serviceLocationId=… ; a plain Navigate
// would drop them and break live authentication, so carry the search string across.
function RootRedirect() {
  const { search } = useLocation();
  return <Navigate to={`/welcome${search}`} replace />;
}

export function App() {
  const [theme, , toggleTheme] = useTheme();
  return (
    <div className="phone-shell">
      <HaliaRoot theme={theme} style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column' }}>
        <button
          className="icon-btn"
          onClick={toggleTheme}
          title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
          style={{
            position: 'absolute', top: 12, right: 14, zIndex: 60,
            background: 'var(--surface-2)', color: 'var(--text-muted)',
            width: 32, height: 32,
          }}
        >
          <Icon name={theme === 'light' ? 'moon' : 'sun'} size={14} />
        </button>
        <Routes>
          <Route path="/" element={<RootRedirect />} />
          <Route path="/welcome" element={<QRLandingPage />} />
          <Route path="/menu" element={<MenuPage />} />
          <Route path="/menu/:id" element={<ItemDetailPage />} />
          {/* Variants screen folded into the detail page: the full live variant list lives
              on the detail screen, so the legacy variants route redirects to the item
              detail path, eliminating all hardcoded ribeye/$ data. */}
          <Route path="/menu/:id/variants" element={<MenuVariantsRedirect />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/track" element={<TrackingPage />} />
          <Route path="/help" element={<ServiceRequestPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/expired" element={<SessionExpiredPage />} />
          <Route path="/error" element={<InvalidQRPage />} />
          <Route path="*" element={<Navigate to="/welcome" replace />} />
        </Routes>
      </HaliaRoot>
    </div>
  );
}
