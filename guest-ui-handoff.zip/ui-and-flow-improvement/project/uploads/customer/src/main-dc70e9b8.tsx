import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import '@halia/ui/fonts.css';
import '@halia/ui/theme.css';
import './index.css';
import { App } from './App';
import { config } from './config';
import { SessionProvider } from './features/session/SessionProvider';
import { VenueProvider } from './features/venue/VenueProvider';
import { ToastProvider } from './features/toast/ToastProvider';
import { CartProvider } from './features/cart/CartProvider';
import { OrdersProvider } from './features/orders/OrdersProvider';
import { ServiceRequestsProvider } from './features/serviceRequests/ServiceRequestsProvider';
import { RealtimeProvider } from './realtime/RealtimeProvider';
import { createFakeStompFactory, type StompFactory } from './realtime/stompSeam';

// Bootstrap is async because — and ONLY when — config.mocking is on, the MSW browser
// worker must be registered and ready BEFORE the first render so no real REST call
// leaks through (Pitfall 1). In a production build (config.mocking false) NONE of the
// test doubles run: no worker, no fake STOMP factory, and window.__stompPush is never
// set; RealtimeProvider mounts with no factory prop so it uses the real realStompFactory
// (Security Domain / T-05-11). The dynamic import('./test/browser') keeps the test bundle
// out of the production module graph.
async function bootstrap(): Promise<void> {
  // Default (production) realtime path: no injected factory → RealtimeProvider's default
  // realStompFactory ships. Stays undefined unless mocking flips it to the fake below.
  let factory: StompFactory | undefined;

  if (config.mocking) {
    const { worker } = await import('./test/browser');
    await worker.start({ onUnhandledRequest: 'warn' });

    const fake = createFakeStompFactory();
    factory = fake.factory;
    // Expose the deterministic push() so Playwright (05-06) can drive order/SR status
    // changes. Strictly inside this branch → never present in a production build.
    window.__stompPush = fake.push;
  }

  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <BrowserRouter>
        <SessionProvider>
          <VenueProvider>
            <ToastProvider>
              <CartProvider>
                {/* OrdersProvider + ServiceRequestsProvider hold the SHARED order/SR state
                    (RT-02 gapfix). They sit ABOVE RealtimeProvider (which consumes them to
                    apply live STOMP pushes) AND above the routed pages (TrackingPage /
                    ServiceRequestPage, which read the same instance) — so a live push and the
                    page render observe ONE state instance. They need SessionProvider (both) and
                    ToastProvider (ServiceRequestsProvider) above them, satisfied here. */}
                <OrdersProvider>
                  <ServiceRequestsProvider>
                    <RealtimeProvider factory={factory}>
                      <App />
                    </RealtimeProvider>
                  </ServiceRequestsProvider>
                </OrdersProvider>
              </CartProvider>
            </ToastProvider>
          </VenueProvider>
        </SessionProvider>
      </BrowserRouter>
    </StrictMode>,
  );
}

void bootstrap();
