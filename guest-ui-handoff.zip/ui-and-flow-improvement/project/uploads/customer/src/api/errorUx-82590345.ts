import { ApiError } from './ApiError';

// Single per-status UX policy (UX-01). Maps an ApiError.status to a small, pure,
// testable descriptor that callers use to drive navigation/toasts. The 401 first-try
// is already silent-retried in http(); this classifies the UNRECOVERABLE/still-401
// case (and the other documented statuses) into a user-safe outcome.
//
// SECURITY (ApiError SECURITY rule / ASVS V7): the returned message is FIXED copy keyed
// on status — it NEVER echoes error.message or any raw internals, so a token, secret, or
// Authorization header can never leak into rendered UX. This helper is react-router-free
// (callers own navigation) so it stays a pure unit.
export type ErrorUxKind =
  | 'expired'
  | 'feature-disabled'
  | 'mismatch'
  | 'session-closed'
  | 'validation'
  | 'generic';

export interface ErrorUxResult {
  kind: ErrorUxKind;
  message: string;
  route?: '/expired' | '/error';
}

export function errorUx(error: unknown): ErrorUxResult {
  const status = error instanceof ApiError ? error.status : 0;

  switch (status) {
    case 401:
      // Unrecoverable session (http() already silent-retried once) → Session Expired screen.
      return { kind: 'expired', message: 'This session has expired.', route: '/expired' };
    case 403:
      return { kind: 'feature-disabled', message: "That's not available here." };
    case 404:
      // Session/venue mismatch → Invalid QR screen.
      return { kind: 'mismatch', message: "We couldn't find your session.", route: '/error' };
    case 409:
      return { kind: 'session-closed', message: 'Your table session has closed.' };
    case 400:
    case 422:
      // CR-04: the backend surfaces validation as BOTH 400 (documented) and 422 (Spring
      // bean-validation) — ServiceRequestsProvider.create already branches on `400 || 422`.
      // Map both to the SAME validation outcome so this single per-status policy stays
      // consistent with the call sites (and a 400 no longer falls through to generic).
      return { kind: 'validation', message: 'Please check your input and try again.' };
    default:
      return { kind: 'generic', message: 'Something went wrong. Please try again.' };
  }
}
