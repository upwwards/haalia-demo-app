import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { server } from '../../test/server';
import { errorHandlers } from '../../test/handlers';
import { nowPlus, signedFakeJwt } from '../../test/jwt';
import { ApiError } from '../ApiError';
import { configureHttp } from '../http';
import { clearCart, getCart, submitCart, upsertCart } from './cart';
import { getSessionOrders } from './orders';

const SID = 'session-1';

beforeEach(() => {
  configureHttp({
    getToken: () => signedFakeJwt({ exp: nowPlus(3600) }),
    reAuth: async () => {},
  });
});
afterEach(() => configureHttp({ getToken: () => null, reAuth: async () => {} }));

describe('cart endpoints — happy path (CART-01/02/03)', () => {
  it('getCart returns a GuestCartResponse with a numeric totalPrice and items', async () => {
    const cart = await getCart(SID);
    expect(cart.serviceSessionId).toBe(SID);
    expect(typeof cart.totalPrice).toBe('number');
    expect(cart.items.length).toBeGreaterThan(0);
    // Spec field names — never totalAmount/effectivePrice.
    expect(cart.items[0]).toHaveProperty('unitPrice');
    expect(cart.items[0]).toHaveProperty('itemTotal');
  });

  it('upsertCart PUTs to /guest/cart and echoes the posted items (full-replace reconcile)', async () => {
    const cart = await upsertCart({
      serviceSessionId: SID,
      items: [
        { menuItemId: 'item-1', quantity: 3 },
        { menuItemId: 'item-2', quantity: 1, variantId: 'var-1' },
      ],
    });
    expect(cart.items).toHaveLength(2);
    const line = cart.items.find((i) => i.menuItemId === 'item-1');
    expect(line?.quantity).toBe(3);
    expect(line?.itemTotal).toBe(line!.unitPrice * 3);
    // totalPrice reflects the posted quantities (server-authoritative reconcile).
    expect(cart.totalPrice).toBe(
      cart.items.reduce((sum, i) => sum + i.itemTotal, 0),
    );
  });

  it('clearCart resolves to undefined (204 No Content)', async () => {
    await expect(clearCart(SID)).resolves.toBeUndefined();
  });

  it('submitCart POSTs and returns an OrderResponse with status PENDING', async () => {
    const order = await submitCart(SID);
    expect(order.status).toBe('PENDING');
    expect(typeof order.orderNumber).toBe('number');
    expect(typeof order.totalPrice).toBe('number');
    expect(order.orderItems.length).toBeGreaterThan(0);
  });
});

describe('orders endpoint — happy path (ORDER-02)', () => {
  it('getSessionOrders returns a bare OrderResponse[] (not a Page envelope)', async () => {
    const orders = await getSessionOrders(SID);
    expect(Array.isArray(orders)).toBe(true);
    expect(orders.length).toBeGreaterThan(0);
    expect(orders[0].status).toBeDefined();
    // Bare array — must NOT be wrapped.
    expect((orders as unknown as { content?: unknown }).content).toBeUndefined();
  });
});

describe('cart/order error factories (ORDER-01 / Pitfall 7)', () => {
  it('submit 409 (session not ACTIVE) surfaces ApiError status 409', async () => {
    server.use(errorHandlers.conflictPost(`/guest/cart/${SID}/submit`));
    const err = await submitCart(SID).catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect((err as ApiError).status).toBe(409);
  });

  it('submit 400 (empty cart) surfaces ApiError status 400', async () => {
    server.use(errorHandlers.badRequestPost(`/guest/cart/${SID}/submit`));
    const err = await submitCart(SID).catch((e) => e);
    expect((err as ApiError).status).toBe(400);
  });

  it('PUT 400 (bad cart write) surfaces ApiError status 400', async () => {
    server.use(errorHandlers.badRequestPut('/guest/cart'));
    const err = await upsertCart({ serviceSessionId: SID, items: [] }).catch(
      (e) => e,
    );
    expect((err as ApiError).status).toBe(400);
  });

  it('DELETE 404 surfaces ApiError status 404', async () => {
    server.use(errorHandlers.notFoundDelete(`/guest/cart/${SID}`));
    const err = await clearCart(SID).catch((e) => e);
    expect((err as ApiError).status).toBe(404);
  });

  it('cart GET 404 surfaces ApiError status 404', async () => {
    server.use(errorHandlers.notFoundGet(`/guest/cart/${SID}`));
    const err = await getCart(SID).catch((e) => e);
    expect((err as ApiError).status).toBe(404);
  });

  it('orders GET 404 surfaces ApiError status 404', async () => {
    server.use(errorHandlers.notFoundGet(`/guest/orders/${SID}`));
    const err = await getSessionOrders(SID).catch((e) => e);
    expect((err as ApiError).status).toBe(404);
  });
});
