import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { nowPlus, signedFakeJwt } from '../../test/jwt';
import { configureHttp } from '../http';
import {
  cancelServiceRequest,
  createServiceRequest,
  listServiceRequests,
} from './serviceRequests';
import { checkoutSession } from './session';

const SID = 'session-1';

beforeEach(() => {
  configureHttp({
    getToken: () => signedFakeJwt({ exp: nowPlus(3600) }),
    reAuth: async () => {},
  });
});
afterEach(() => configureHttp({ getToken: () => null, reAuth: async () => {} }));

describe('service-request endpoints — happy path (SVC-01/02/03)', () => {
  it('createServiceRequest POSTs the body (serviceSessionId, requestType, message) and echoes a fresh OPEN row', async () => {
    const sr = await createServiceRequest({
      serviceSessionId: SID,
      requestType: 'CUSTOM',
      message: 'extra napkins please',
    });
    expect(sr.serviceSessionId).toBe(SID);
    expect(sr.requestType).toBe('CUSTOM');
    expect(sr.message).toBe('extra napkins please');
    expect(sr.status).toBe('OPEN');
    // Field discipline (D-05): timing is requestedAt/completedAt, NEVER `created`.
    expect(sr).toHaveProperty('requestedAt');
    expect(sr).not.toHaveProperty('created');
  });

  it('createServiceRequest sends message:null for non-CUSTOM types without a note', async () => {
    const sr = await createServiceRequest({
      serviceSessionId: SID,
      requestType: 'WATER',
      message: null,
    });
    expect(sr.requestType).toBe('WATER');
    expect(sr.message).toBeNull();
  });

  it('listServiceRequests aggregates ALL pages into a flat array (proves pageNumber/pageSize loop)', async () => {
    const rows = await listServiceRequests(SID);
    // 2-page fixture: page 0 has 2 rows, page 1 (last) has 1 → 3 total. A wrong param name
    // would refetch page 0 forever / return a single page, so >2 proves the loop + param names.
    expect(rows.length).toBe(3);
    expect(rows.length).toBeGreaterThan(2);
    expect(rows.map((r) => r.id)).toEqual(['sr-1', 'sr-2', 'sr-3']);
    // All 5 statuses are valid contract values; spot-check the ones the fixture serves.
    expect(rows[0].status).toBe('OPEN');
  });

  it('cancelServiceRequest POSTs {sessionId}/{requestId}/cancel and reconciles to status CANCELLED', async () => {
    const sr = await cancelServiceRequest(SID, 'sr-1');
    expect(sr.id).toBe('sr-1');
    expect(sr.serviceSessionId).toBe(SID);
    expect(sr.status).toBe('CANCELLED');
  });
});

describe('checkout endpoint — happy path (SESS-01)', () => {
  it('checkoutSession POSTs {sessionId}/checkout (no body) and returns numeric totals', async () => {
    const summary = await checkoutSession(SID);
    expect(summary.sessionId).toBe(SID);
    expect(typeof summary.totalOrders).toBe('number');
    expect(typeof summary.totalSpent).toBe('number');
    expect(summary.totalOrders).toBe(3);
    expect(summary.totalSpent).toBe(1516.5);
  });
});
