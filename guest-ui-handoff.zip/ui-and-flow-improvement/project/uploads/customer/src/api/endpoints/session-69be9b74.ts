import { http } from '../http';
import type {
  GuestCheckoutResponse,
  GuestServiceSessionResponse,
} from '../types';

// Establish (or fetch) the guest service session. No request body — serviceLocationId
// comes from the JWT. Caller reads `.id` as the sessionId. Routes through http() so it
// carries the bearer token and the 401 single-flight retry seam.
export function getOrCreateSession(): Promise<GuestServiceSessionResponse> {
  return http<GuestServiceSessionResponse>(
    '/guest/service-sessions/get-or-create',
    { method: 'POST' },
  );
}

// POST /api/v1/guest/service-sessions/{sessionId}/checkout — end the session (irreversible).
// sessionId is a PATH param and the request takes NO body (do not pass one). Resolves to a
// GuestCheckoutResponse {sessionId, totalOrders, totalSpent} the Thank-you screen reads verbatim.
export function checkoutSession(sessionId: string): Promise<GuestCheckoutResponse> {
  return http<GuestCheckoutResponse>(
    `/guest/service-sessions/${sessionId}/checkout`,
    { method: 'POST' },
  );
}
