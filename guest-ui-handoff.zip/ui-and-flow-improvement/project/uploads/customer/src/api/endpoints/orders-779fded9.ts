import { http } from '../http';
import type { OrderResponse } from '../types';

// GET /api/v1/guest/orders/{sessionId} — order history/status. Returns a BARE OrderResponse[]
// (NOT a Spring Page envelope, unlike the menu) so there is no pagination loop here.
// sessionId is a PATH param. Phase 5 reuses this as the WebSocket-reconnect resync source.
export function getSessionOrders(sessionId: string): Promise<OrderResponse[]> {
  return http<OrderResponse[]>(`/guest/orders/${sessionId}`);
}
