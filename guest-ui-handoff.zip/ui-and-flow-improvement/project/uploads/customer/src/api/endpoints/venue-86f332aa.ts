import { http } from '../http';
import type { Feature, GuestVenueResponse } from '../types';

// GET /api/v1/guest/venue/features — bare string[] of enabled feature enums.
// http() runs res.json() regardless of the */* content-type, so this parses fine.
// No new transport code: bearer token + base URL + 401 retry are owned by http().
export function getEnabledFeatures(): Promise<Feature[]> {
  return http<Feature[]>('/guest/venue/features');
}

// GET /api/v1/guest/venue/get-venue-info — venue display details.
export function getVenueDetails(): Promise<GuestVenueResponse> {
  return http<GuestVenueResponse>('/guest/venue/get-venue-info');
}
