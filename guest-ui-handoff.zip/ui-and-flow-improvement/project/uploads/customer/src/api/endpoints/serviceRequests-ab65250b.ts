import { http } from '../http';
import type {
  GuestServiceRequestCreateRequest,
  GuestServiceRequestResponse,
  PageGuestServiceRequestResponse,
} from '../types';

// POST /api/v1/guest/service-requests — raise a request. sessionId travels in the BODY as
// `serviceSessionId` (Pitfall: NOT in the path — mirror upsertCart). Routes through http()
// so it carries the bearer token + 401 single-flight retry. Resolves to the created row.
export function createServiceRequest(
  body: GuestServiceRequestCreateRequest,
): Promise<GuestServiceRequestResponse> {
  return http<GuestServiceRequestResponse>('/guest/service-requests', {
    method: 'POST',
    body: JSON.stringify(body),
  });
}

// GET /api/v1/guest/service-requests/{sessionId} — aggregate ALL pages into a flat list.
// Query params are `pageNumber`/`pageSize` (NOT page/size) — a wrong name silently returns
// defaults and loses rows. Loop is bounded by `last`/`totalPages` plus a hard pageNumber cap
// so a never-`last` backend cannot loop unbounded. Copies the menu aggregator verbatim.
export async function listServiceRequests(
  sessionId: string,
  pageSize = 20,
): Promise<GuestServiceRequestResponse[]> {
  const all: GuestServiceRequestResponse[] = [];
  let pageNumber = 0;
  for (;;) {
    const page = await http<PageGuestServiceRequestResponse>(
      `/guest/service-requests/${sessionId}?pageNumber=${pageNumber}&pageSize=${pageSize}`,
    );
    all.push(...(page.content ?? []));
    const totalPages = page.totalPages ?? 1;
    if (page.last || pageNumber + 1 >= totalPages) break;
    pageNumber += 1;
    if (pageNumber > 500) break; // hard safety cap against a misbehaving backend
  }
  return all;
}

// POST /api/v1/guest/service-requests/{sessionId}/{requestId}/cancel — cancel an OPEN request.
// BOTH ids travel in the PATH and the request takes NO body (do not pass one). Server-authoritative:
// resolves to the reconciled row whose status is CANCELLED.
export function cancelServiceRequest(
  sessionId: string,
  requestId: string,
): Promise<GuestServiceRequestResponse> {
  return http<GuestServiceRequestResponse>(
    `/guest/service-requests/${sessionId}/${requestId}/cancel`,
    { method: 'POST' },
  );
}
