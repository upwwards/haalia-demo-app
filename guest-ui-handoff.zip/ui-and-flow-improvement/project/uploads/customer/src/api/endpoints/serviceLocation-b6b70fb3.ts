import { http } from '../http';
import type { GuestServiceLocationResponse } from '../types';

// GET /api/v1/guest/service-locations/current — the location bound to the JWT.
// No request body; serviceLocationId comes from the bearer token. Routes through http().
export function getCurrentLocation(): Promise<GuestServiceLocationResponse> {
  return http<GuestServiceLocationResponse>('/guest/service-locations/current');
}
