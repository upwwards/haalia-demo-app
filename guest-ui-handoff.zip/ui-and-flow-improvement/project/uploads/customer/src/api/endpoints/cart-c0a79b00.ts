import { http } from '../http';
import type {
  GuestCartResponse,
  GuestCartUpsertRequest,
  OrderResponse,
} from '../types';

// GET /api/v1/guest/cart/{sessionId} — Sync-on-Read. sessionId is a PATH param.
export function getCart(sessionId: string): Promise<GuestCartResponse> {
  return http<GuestCartResponse>(`/guest/cart/${sessionId}`);
}

// PUT /api/v1/guest/cart — full-replace upsert. sessionId travels in the BODY as
// `serviceSessionId` (Pitfall 4) — the path has NO param. Never send items: [] (clearCart instead).
export function upsertCart(body: GuestCartUpsertRequest): Promise<GuestCartResponse> {
  return http<GuestCartResponse>('/guest/cart', {
    method: 'PUT',
    body: JSON.stringify(body),
  });
}

// DELETE /api/v1/guest/cart/{sessionId} — clear the cart. sessionId is a PATH param;
// the backend replies 204, which http() resolves to undefined.
export function clearCart(sessionId: string): Promise<void> {
  return http<void>(`/guest/cart/${sessionId}`, { method: 'DELETE' });
}

// POST /api/v1/guest/cart/{sessionId}/submit — place the order. sessionId is a PATH param
// and the request takes NO body (do not pass one).
export function submitCart(sessionId: string): Promise<OrderResponse> {
  return http<OrderResponse>(`/guest/cart/${sessionId}/submit`, { method: 'POST' });
}
