import { config } from '../../config';
import { ApiError } from '../ApiError';
import type { GuestJwtResponse, GuestLoginRequest } from '../types';

// Public guest login. Deliberately BYPASSES the 401-retry hook in http.ts: there is no
// token yet, and a 401 here is terminal ("invalid QR"), not a trigger for re-auth.
export async function authenticateGuest(
  qr: GuestLoginRequest,
): Promise<GuestJwtResponse> {
  const res = await fetch(
    `${config.apiBaseUrl}/api/v1/auth/guest/authenticate`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(qr),
    },
  );
  if (!res.ok) throw await ApiError.from(res);
  return (await res.json()) as GuestJwtResponse;
}
