import { http } from '../http';
import type {
  GuestEffectiveMenuResponse,
  PageGuestEffectiveMenuResponse,
} from '../types';

// GET /api/v1/guest/menu/item/{itemId} — single item detail (full variants[]).
// Path param is `itemId` (NOT `menuItemId`) per the spec. Same DTO as a list item.
export function getMenuItem(itemId: string): Promise<GuestEffectiveMenuResponse> {
  return http<GuestEffectiveMenuResponse>(`/guest/menu/item/${itemId}`);
}

// GET /api/v1/guest/menu/effective — aggregate ALL pages into a flat list.
// Query params are `pageNumber`/`pageSize` (NOT page/size) — a wrong name silently
// returns defaults and loses items. Loop is bounded by `last`/`totalPages` plus a hard
// pageNumber cap so a never-`last` backend cannot loop unbounded (Pitfall 2 / T-02-02).
export async function getEffectiveMenu(
  pageSize = 20,
): Promise<GuestEffectiveMenuResponse[]> {
  const all: GuestEffectiveMenuResponse[] = [];
  let pageNumber = 0;
  for (;;) {
    const page = await http<PageGuestEffectiveMenuResponse>(
      `/guest/menu/effective?pageNumber=${pageNumber}&pageSize=${pageSize}`,
    );
    all.push(...(page.content ?? []));
    const totalPages = page.totalPages ?? 1;
    if (page.last || pageNumber + 1 >= totalPages) break;
    pageNumber += 1;
    if (pageNumber > 500) break; // hard safety cap against a misbehaving backend
  }
  return all;
}
