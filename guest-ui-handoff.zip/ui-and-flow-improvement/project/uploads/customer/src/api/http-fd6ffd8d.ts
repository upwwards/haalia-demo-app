import { config } from '../config';
import { ApiError } from './ApiError';

// Module-level bridge so api/ stays React-free. SessionProvider wires these via configureHttp.
let getToken: () => string | null = () => null;
let reAuth: () => Promise<void> = async () => {};

export function configureHttp(o: {
  getToken: () => string | null;
  reAuth: () => Promise<void>;
}): void {
  getToken = o.getToken;
  reAuth = o.reAuth;
}

// The single REST chokepoint. Prefixes ${config.apiBaseUrl}/api/v1, injects the bearer
// token when present, runs the single-flight 401 -> reAuth -> retry-once seam, and throws
// a typed ApiError on any non-2xx. 204 resolves to undefined.
export async function http<T>(
  path: string,
  init: RequestInit = {},
  _retried = false,
): Promise<T> {
  const token = getToken();
  const res = await fetch(`${config.apiBaseUrl}/api/v1${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...init.headers,
    },
  });

  if (res.status === 401 && !_retried) {
    await reAuth(); // single-flight (owned by SessionProvider in Plan 03)
    return http<T>(path, init, true); // retry the SAME request exactly once
  }

  if (!res.ok) throw await ApiError.from(res);
  return res.status === 204 ? (undefined as T) : ((await res.json()) as T);
}
