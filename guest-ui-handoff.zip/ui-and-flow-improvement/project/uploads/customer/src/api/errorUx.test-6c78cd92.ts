import { describe, expect, it } from 'vitest';
import { ApiError } from './ApiError';
import { errorUx } from './errorUx';

describe('errorUx (UX-01 per-status policy)', () => {
  it('maps 401 → expired, routed to /expired', () => {
    const r = errorUx(new ApiError(401, 'Unauthorized'));
    expect(r.kind).toBe('expired');
    expect(r.route).toBe('/expired');
  });

  it('maps 403 → feature-disabled, no route', () => {
    const r = errorUx(new ApiError(403, 'Forbidden'));
    expect(r.kind).toBe('feature-disabled');
    expect(r.route).toBeUndefined();
  });

  it('maps 404 → mismatch, routed to /error', () => {
    const r = errorUx(new ApiError(404, 'Not Found'));
    expect(r.kind).toBe('mismatch');
    expect(r.route).toBe('/error');
  });

  it('maps 409 → session-closed, no route', () => {
    const r = errorUx(new ApiError(409, 'Conflict'));
    expect(r.kind).toBe('session-closed');
    expect(r.route).toBeUndefined();
  });

  it('maps 400 → validation, no route (CR-04 — same outcome as 422)', () => {
    const r = errorUx(new ApiError(400, 'Bad Request'));
    expect(r.kind).toBe('validation');
    expect(r.route).toBeUndefined();
  });

  it('maps 422 → validation, no route', () => {
    const r = errorUx(new ApiError(422, 'Unprocessable'));
    expect(r.kind).toBe('validation');
    expect(r.route).toBeUndefined();
  });

  it('maps an unknown ApiError status → generic', () => {
    const r = errorUx(new ApiError(500, 'Server Error'));
    expect(r.kind).toBe('generic');
    expect(r.route).toBeUndefined();
  });

  it('maps a non-ApiError (status 0) → generic', () => {
    const r = errorUx(new Error('boom'));
    expect(r.kind).toBe('generic');
    expect(r.route).toBeUndefined();
  });

  it('never leaks the token/secret/Authorization in any returned message', () => {
    // Even if the raw ApiError message carries internals, the descriptor copy is fixed.
    const leaky = 'Authorization: Bearer super-secret-token';
    const statuses = [401, 403, 404, 409, 422, 500, 0];
    for (const s of statuses) {
      const r = errorUx(new ApiError(s, leaky));
      expect(r.message).not.toMatch(/Bearer/i);
      expect(r.message).not.toMatch(/token/i);
      expect(r.message).not.toMatch(/Authorization/i);
      expect(r.message).not.toContain('super-secret-token');
    }
  });
});
