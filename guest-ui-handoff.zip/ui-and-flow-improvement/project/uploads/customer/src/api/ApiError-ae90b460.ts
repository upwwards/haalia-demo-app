import type { ErrorResponse } from './types';

// Typed transport error carrying the HTTP status so later phases can drive per-status UX.
// SECURITY: never put a token, secret, or Authorization header into the message.
export class ApiError extends Error {
  readonly status: number;
  readonly code?: string;

  constructor(status: number, message: string, code?: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
  }

  // Build an ApiError from a non-2xx Response. Parses the ErrorResponse body ONLY when
  // the response is JSON (guarded so an ngrok interstitial HTML page is never JSON-parsed);
  // otherwise falls back to res.statusText.
  static async from(res: Response): Promise<ApiError> {
    const contentType = res.headers.get('content-type') ?? '';
    if (contentType.includes('application/json')) {
      try {
        const body = (await res.json()) as Partial<ErrorResponse>;
        const message = body.message ?? res.statusText ?? `HTTP ${res.status}`;
        return new ApiError(res.status, message, body.code);
      } catch {
        // fall through to statusText on malformed JSON
      }
    }
    return new ApiError(res.status, res.statusText || `HTTP ${res.status}`);
  }
}
