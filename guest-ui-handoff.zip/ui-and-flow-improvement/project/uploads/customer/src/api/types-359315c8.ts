// Hand-written guest DTOs mirrored EXACTLY from api-docs.json (OpenAPI 3.1.0).
// Where prose docs disagree with the spec, the spec wins (per CLAUDE.md).

// POST /api/v1/auth/guest/authenticate — request body (all fields required).
export interface GuestLoginRequest {
  clientId: string;
  clientSecret: string;
  venueId: string;
  serviceLocationId: string;
}

// POST /api/v1/auth/guest/authenticate — 200 response.
// NOTE: this response intentionally has NO token-expiry field — the OpenAPI guest schema
// omits it (only staff schemas carry one). Token expiry is derived by decoding the JWT
// `exp` claim in Plan 03, not read from this response.
export interface GuestJwtResponse {
  accessToken: string;
  tokenType: string;
  organizationId: string;
  venueId: string;
  serviceLocationId: string;
  role: string;
}

// POST /api/v1/guest/service-sessions/get-or-create — 200 response.
// `id` IS the sessionId. Use id/startedAt/endedAt; do not depend on created/venueId.
export interface GuestServiceSessionResponse {
  id: string;
  serviceLocationId: string;
  status: string;
  startedAt: string;
  endedAt: string;
}

// Standard error envelope returned for all guest error statuses (401/403/404/409/422).
export interface ValidationError {
  field: string;
  message: string;
  rejectedValue: unknown;
}

export interface ErrorResponse {
  status: number;
  code: string;
  message: string;
  timestamp: string;
  path: string;
  validationErrors?: ValidationError[];
}

// GET /api/v1/guest/venue/features — 200 response is a bare string[] of these enum values
// (content-type */*; http() calls res.json() regardless). Gate UI on features.includes(...).
export type Feature =
  | 'ORDER_PLACEMENT'
  | 'SERVICE_REQUESTS'
  | 'GOOGLE_REVIEWS'
  | 'KDS'
  | 'ANALYTICS'
  | 'MENU_ITEM_VARIANTS'
  | 'MODEL_3D'
  | 'VENUE_PRICE_OVERRIDE';

// GuestVenueResponse.operationHours[] element. `dayOfWeek` is an array of strings (spec).
export interface OperationHour {
  opens: string;
  closes: string;
  dayOfWeek: string[];
}

// GET /api/v1/guest/venue/get-venue-info — 200 response.
// NOTE: field is `venueName` (NOT `name`) per the spec.
export interface GuestVenueResponse {
  id: string;
  venueName: string;
  phoneNumber: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  operationHours: OperationHour[];
}

// GET /api/v1/guest/service-locations/current — 200 response.
// NOTE: field is `locationType` (NOT `type`); spec has NO `locationCode` field.
export interface GuestServiceLocationResponse {
  id: string;
  name: string;
  locationType: string;
  venueId: string;
  venueName: string;
  active: boolean;
  showOrderHistory: boolean;
}

// A single variant override inside GuestEffectiveMenuResponse.variants[].
// `effectivePrice` is nullable — strict TS forces null handling in the price layer.
export interface MenuItemVariantOverrideResponse {
  variantId: string;
  label: string;
  effectivePrice: number | null;
  displayOrder: number;
  available: boolean;
  isOverridden: boolean;
}

// One menu item from GET /menu/effective (content[]) and GET /menu/item/{itemId}.
// `price` is null when hasVariants === true → derive display price from variants[].effectivePrice.
export interface GuestEffectiveMenuResponse {
  menuItemId: string;
  name: string;
  description: string;
  primaryImageUrl: string | null;
  modelUrl: string | null;
  type: 'VEG' | 'NON_VEG';
  preparationTimeInMinutes: number;
  calories?: number | null;
  categoryId: string;
  categoryName: string;
  price: number | null;
  available: boolean;
  tags: string[];
  hasVariants: boolean;
  variants: MenuItemVariantOverrideResponse[];
}

// GET /api/v1/guest/menu/effective — 200 response (Spring Page envelope).
// The aggregator only needs content/last/totalPages/number; the rest are kept for fidelity.
export interface PageGuestEffectiveMenuResponse {
  content: GuestEffectiveMenuResponse[];
  totalPages: number;
  totalElements: number;
  number: number;
  size: number;
  numberOfElements: number;
  first: boolean;
  last: boolean;
  empty: boolean;
}

// ---------- Cart DTOs (PUT /guest/cart body) ----------

// One PUT /guest/cart item. Spec field is `quantity` (required, min 1); `variantId` optional.
// `notes` is the optional guest special-instruction note for this line (sent only when set).
export interface GuestCartItemRequest {
  menuItemId: string;
  quantity: number;
  variantId?: string;
  notes?: string;
}

// PUT /api/v1/guest/cart — request body. sessionId travels HERE as `serviceSessionId`
// (NOT in the path — Pitfall 4). Full-replace: items[] is the complete intended set.
export interface GuestCartUpsertRequest {
  serviceSessionId: string;
  items: GuestCartItemRequest[];
}

// ---------- Cart DTOs (cart responses) ----------

// One cart line in GuestCartResponse.items[]. DIVERGENCE vs GUEST.md prose: the revalidated
// per-unit price is `unitPrice` (NOT `effectivePrice`). Spec carries NO variantId/variantLabel here (Pitfall 6).
export interface GuestCartItemResponse {
  menuItemId: string;
  menuItemName: string;
  categoryName: string;
  quantity: number;
  unitPrice: number;
  itemTotal: number;
  notes?: string | null;
}

// GET /api/v1/guest/cart/{sessionId} & PUT /api/v1/guest/cart — 200 response.
// DIVERGENCE vs GUEST.md prose: the server total is `totalPrice` (NOT `totalAmount`); lines are `items[]`.
export interface GuestCartResponse {
  serviceSessionId: string;
  totalPrice: number;
  status: string;
  items: GuestCartItemResponse[];
  estimatedWaitMinutes?: number | null;
}

// ---------- Order DTOs ----------

// Order lifecycle status — exact 6-value enum per the spec OrderResponse.status.
export type OrderStatus =
  | 'PENDING'
  | 'CONFIRMED'
  | 'PREPARING'
  | 'READY'
  | 'COMPLETED'
  | 'CANCELLED';

// One order line in OrderResponse.orderItems[]. DIVERGENCE: order lines DO carry `variantLabel`
// (unlike cart lines) and use `itemPrice`/`itemName` (NOT unitPrice/menuItemName).
export interface OrderItemResponse {
  id: string;
  menuItemId: string;
  itemName: string;
  categoryName: string;
  variantLabel: string;
  itemPrice: number;
  quantity: number;
  itemTotal: number;
  notes?: string | null;
}

// POST /api/v1/guest/cart/{sessionId}/submit & GET /api/v1/guest/orders/{sessionId} element.
// DIVERGENCE vs GUEST.md prose: the order total is `totalPrice` (NOT `totalAmount`) and lines
// are under `orderItems[]` (NOT `items[]`). NOTE: per the spec `priorityFlag` is a STRING
// (NOT a boolean) — the spec wins over the plan prose (CLAUDE.md). `source` is GUEST | STAFF.
export interface OrderResponse {
  id: string;
  orderNumber: number;
  venueId: string;
  serviceLocationId: string;
  locationName: string;
  serviceSessionId: string;
  status: OrderStatus;
  source: 'GUEST' | 'STAFF';
  notes: string;
  totalPrice: number;
  orderItems: OrderItemResponse[];
  created: string;
  placedAt: string;
  confirmedAt: string;
  preparingAt: string;
  readyAt: string;
  deliveredAt: string;
  assignedWaiterId: string;
  assignedWaiterName: string;
  allergyFlag: boolean;
  allergyNote: string;
  priorityFlag: string;
  priorityNote: string;
}

// ---------- Service Request DTOs ----------

// Service request type — exact 7-value enum per the spec GuestServiceRequestCreateRequest/
// GuestServiceRequestResponse.requestType. CUSTOM is the only type whose `message` the UI
// makes mandatory (D-02) — the contract itself never marks message required.
export type ServiceRequestType =
  | 'WATER'
  | 'BILL'
  | 'WAITER'
  | 'CLEAN_TABLE'
  | 'REFILL'
  | 'ORDER_ASSISTANCE'
  | 'CUSTOM';

// Service request lifecycle status — exact 5-value enum per the spec GuestServiceRequestResponse.status.
export type ServiceRequestStatus =
  | 'OPEN'
  | 'ACKNOWLEDGED'
  | 'COMPLETED'
  | 'IGNORED'
  | 'CANCELLED';

// POST /api/v1/guest/service-requests — request body. sessionId travels HERE as
// `serviceSessionId` (in the BODY, NOT the path — like upsertCart). `message` is optional on
// the contract (D-02: CUSTOM-required is a UI rule only). Spec required: serviceSessionId, requestType.
export interface GuestServiceRequestCreateRequest {
  serviceSessionId: string;
  requestType: ServiceRequestType;
  message?: string | null;
}

// One service request row. Returned by create, by the list content[], and by cancel.
// Field discipline (prose drift, D-05): timing is `requestedAt`/`completedAt`, NEVER `created`.
export interface GuestServiceRequestResponse {
  id: string;
  serviceLocationId: string;
  serviceSessionId: string;
  requestType: ServiceRequestType;
  status: ServiceRequestStatus;
  message: string | null;
  requestedAt: string;
  completedAt: string | null;
}

// GET /api/v1/guest/service-requests/{sessionId} — 200 response (Spring Page envelope).
// The aggregator only needs content/last/totalPages/number; the rest are kept for fidelity.
export interface PageGuestServiceRequestResponse {
  content: GuestServiceRequestResponse[];
  totalPages: number;
  totalElements: number;
  number: number;
  size: number;
  numberOfElements: number;
  first: boolean;
  last: boolean;
  empty: boolean;
}

// ---------- Checkout DTO ----------

// POST /api/v1/guest/service-sessions/{sessionId}/checkout — 200 response.
// DIVERGENCE vs GUEST.md prose ({status, closedAt}): the spec returns {sessionId, totalOrders,
// totalSpent} — the schema wins. `totalSpent` is rendered ₹ via .toFixed(2); never computed client-side.
export interface GuestCheckoutResponse {
  sessionId: string;
  totalOrders: number;
  totalSpent: number;
}
