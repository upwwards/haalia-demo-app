import { afterEach, describe, expect, it, vi } from 'vitest';
import { http as mswHttp, HttpResponse } from 'msw';
import { server } from '../test/server';
import { errorBody, nowPlus, signedFakeJwt } from '../test/jwt';
import { config } from '../config';
import { ApiError } from './ApiError';
import { configureHttp, http } from './http';
import { authenticateGuest } from './endpoints/auth';
import { getOrCreateSession } from './endpoints/session';

// Reset the module-level bridge to inert defaults between tests.
afterEach(() => configureHttp({ getToken: () => null, reAuth: async () => {} }));

describe('http wrapper (AUTH-01)', () => {
  it('injects Authorization: Bearer <token> when a token is present', async () => {
    let received: string | null = 'MISSING';
    server.use(
      mswHttp.get('*/api/v1/__echo', ({ request }) => {
        received = request.headers.get('authorization');
        return HttpResponse.json({ ok: true });
      }),
    );
    configureHttp({
      getToken: () => signedFakeJwt({ exp: nowPlus(3600) }),
      reAuth: async () => {},
    });
    await http('/__echo', { method: 'GET' });
    expect(received).toMatch(/^Bearer /);
  });

  it('omits the Authorization header when there is no token', async () => {
    let received: string | null = 'MISSING';
    server.use(
      mswHttp.get('*/api/v1/__echo', ({ request }) => {
        received = request.headers.get('authorization');
        return HttpResponse.json({ ok: true });
      }),
    );
    configureHttp({ getToken: () => null, reAuth: async () => {} });
    await http('/__echo', { method: 'GET' });
    expect(received).toBeNull();
  });

  it('targets ${config.apiBaseUrl}/api/v1 + path (env-swap contract)', async () => {
    let url = '';
    server.use(
      mswHttp.get('*/api/v1/__echo', ({ request }) => {
        url = request.url;
        return HttpResponse.json({ ok: true });
      }),
    );
    configureHttp({ getToken: () => null, reAuth: async () => {} });
    await http('/__echo', { method: 'GET' });
    expect(url).toBe(`${config.apiBaseUrl}/api/v1/__echo`);
  });

  it('throws ApiError with status 403 and never routes 403 into re-auth', async () => {
    const reAuthSpy = vi.fn(async () => {});
    server.use(
      mswHttp.get('*/api/v1/__forbidden', () =>
        HttpResponse.json(errorBody(403, 'FORBIDDEN'), { status: 403 }),
      ),
    );
    configureHttp({ getToken: () => null, reAuth: reAuthSpy });
    const err = await http('/__forbidden', { method: 'GET' }).catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect((err as ApiError).status).toBe(403);
    expect(reAuthSpy).not.toHaveBeenCalled();
  });

  it('on a single 401: calls reAuth exactly once then retries successfully', async () => {
    let calls = 0;
    const reAuthSpy = vi.fn(async () => {});
    server.use(
      mswHttp.get('*/api/v1/__retry', () => {
        calls += 1;
        if (calls === 1) {
          return HttpResponse.json(errorBody(401, 'UNAUTHORIZED'), { status: 401 });
        }
        return HttpResponse.json({ ok: true });
      }),
    );
    configureHttp({ getToken: () => null, reAuth: reAuthSpy });
    const result = await http<{ ok: boolean }>('/__retry', { method: 'GET' });
    expect(reAuthSpy).toHaveBeenCalledTimes(1);
    expect(calls).toBe(2);
    expect(result).toEqual({ ok: true });
  });

  it('on a persistent 401: throws terminally without looping (one retry max)', async () => {
    let calls = 0;
    const reAuthSpy = vi.fn(async () => {});
    server.use(
      mswHttp.get('*/api/v1/__always401', () => {
        calls += 1;
        return HttpResponse.json(errorBody(401, 'UNAUTHORIZED'), { status: 401 });
      }),
    );
    configureHttp({ getToken: () => null, reAuth: reAuthSpy });
    const err = await http('/__always401', { method: 'GET' }).catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect((err as ApiError).status).toBe(401);
    expect(reAuthSpy).toHaveBeenCalledTimes(1);
    expect(calls).toBe(2); // original + exactly one retry, then throw
  });
});

describe('guest endpoints', () => {
  it('authenticateGuest hits /auth/guest/authenticate and bypasses the re-auth hook', async () => {
    const reAuthSpy = vi.fn(async () => {});
    configureHttp({ getToken: () => null, reAuth: reAuthSpy });
    // Default handler returns 401 when clientSecret === 'wrong'.
    const err = await authenticateGuest({
      clientId: 'c',
      clientSecret: 'wrong',
      venueId: 'v',
      serviceLocationId: 'l',
    }).catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect((err as ApiError).status).toBe(401);
    expect(reAuthSpy).not.toHaveBeenCalled(); // terminal — no re-auth on guest login
  });

  it('getOrCreateSession posts with no body and returns sessionId via response.id', async () => {
    configureHttp({
      getToken: () => signedFakeJwt({ exp: nowPlus(3600) }),
      reAuth: async () => {},
    });
    const session = await getOrCreateSession();
    expect(session.id).toBe('session-1');
    expect(session.status).toBe('ACTIVE');
  });
});
