// Single source of runtime configuration, read from Vite env (import.meta.env).
// Swap VITE_API_BASE_URL to point the app at a different host (e.g. ngrok) with no code change.
export const config = {
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8080',
  mocking: import.meta.env.VITE_API_MOCKING === 'enabled',
  // Guest auth credentials for THIS deployment's organization. Obtained from the dashboard's
  // "generate guest credentials" and configured here — NOT embedded in the table QR. The QR
  // carries only venueId + serviceLocationId; these env creds + those ids → POST guest/authenticate.
  guestClientId: import.meta.env.VITE_GUEST_CLIENT_ID ?? '',
  guestClientSecret: import.meta.env.VITE_GUEST_CLIENT_SECRET ?? '',
};
