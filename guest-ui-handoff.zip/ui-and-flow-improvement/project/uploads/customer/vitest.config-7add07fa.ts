/// <reference types="vitest/config" />
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['src/test/setup.ts'],
    globals: true,
    // Unit/integration tests live under src/. Playwright specs in e2e/ are run by
    // `test:e2e`, not Vitest — excluded here so Vitest doesn't try to collect them.
    include: ['src/**/*.{test,spec}.{ts,tsx}'],
  },
});
