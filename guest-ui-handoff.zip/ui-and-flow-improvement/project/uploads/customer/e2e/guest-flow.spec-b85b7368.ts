import { expect, test } from '@playwright/test';

// Full-flow guest E2E (RT-02/RT-03, TEST-03 closeout). Drives the ENTIRE wired stack against
// the mocked layer only — REST on the browser MSW worker (05-04) and real-time on the
// deterministic STOMP double via window.__stompPush (05-04) — with NO live backend. The
// playwright.config webServer runs `npm run dev` with VITE_API_MOCKING=enabled, so config.mocking
// is true: the worker intercepts every guest REST call from the SAME handlers vitest uses, and
// window.__stompPush(dest, { destination, data }) pushes order/SR frames into the live UI.
//
// The pushed `data` payloads use the REST DTO field names (OrderResponse: orderItems / itemName /
// totalPrice / status; GuestServiceRequestResponse: id / requestType / status), NOT the abbreviated
// WS-doc example — the provider unwraps msg.body.data and feeds it straight into applyLiveOrder /
// applyLiveRequest, which key on `id` (replace if present, prepend if new).

// The two verified guest topics for the fixture session (session-1 from handlers.ts).
const ORDERS_TOPIC = '/topic/guest/session/session-1/orders';
const SR_TOPIC = '/topic/guest/session/session-1/service-requests';

// A live OrderResponse advancing order-1 (#1042) from PREPARING → READY. Same `id` as the GET
// fixture so applyLiveOrder replaces it in place and the TrackingPage step machine moves to READY.
const orderReadyFrame = {
  destination: ORDERS_TOPIC,
  data: {
    id: 'order-1',
    orderNumber: 1042,
    venueId: 'venue-1',
    serviceLocationId: 'loc-1',
    locationName: 'Table 12',
    serviceSessionId: 'session-1',
    status: 'READY',
    source: 'GUEST',
    notes: '',
    totalPrice: 698,
    orderItems: [
      {
        id: 'oi-1',
        menuItemId: 'item-1',
        itemName: 'Margherita Pizza',
        categoryName: 'Mains',
        variantLabel: '',
        itemPrice: 349,
        quantity: 2,
        itemTotal: 698,
      },
    ],
    created: new Date().toISOString(),
    placedAt: new Date().toISOString(),
    confirmedAt: new Date().toISOString(),
    preparingAt: new Date().toISOString(),
    readyAt: new Date().toISOString(),
    deliveredAt: '',
    assignedWaiterId: '',
    assignedWaiterName: '',
    allergyFlag: false,
    allergyNote: '',
    priorityFlag: '',
    priorityNote: '',
  },
};

// A live GuestServiceRequestResponse with a FRESH id so applyLiveRequest prepends a NEW row to
// the SR list (data-testid sr-row-sr-live). Field names match the REST DTO (id/requestType/status).
const srLiveFrame = {
  destination: SR_TOPIC,
  data: {
    id: 'sr-live',
    serviceLocationId: 'loc-1',
    serviceSessionId: 'session-1',
    requestType: 'BILL',
    status: 'ACKNOWLEDGED',
    message: null,
    requestedAt: new Date().toISOString(),
    completedAt: null,
  },
};

test('guest completes the full flow: QR → menu → cart → order → track → service request → checkout', async ({
  page,
}) => {
  // ---------- (1) QR landing → authenticate (MSW) → menu ----------
  await page.goto('/'); // redirects to /welcome
  await page.getByRole('button', { name: /View menu/ }).click();
  // Menu renders a fixture item — proves auth + the venue/menu GETs ran against the worker.
  // The dish name appears twice (row title + ImageSlot placeholder), so target the first.
  await expect(page.getByText('Margherita Pizza').first()).toBeVisible();

  // ---------- (2) add an item to the cart, open the cart, assert server-authoritative lines ----------
  await page.getByRole('button', { name: 'Add Margherita Pizza' }).click();
  // The cart pill ("View cart") appears once the cart has a line; tapping it opens /cart.
  await page.getByText('View cart').click();
  await expect(page).toHaveURL(/\/cart$/);
  // The cart is server-authoritative: adding item-1 issues a PUT full-replace, and the cart
  // renders the line + total from the PUT response (never a client-computed sum). The PUT handler
  // echoes the added line (item-1, qty 1, unitPrice 349) → one line at ₹349.00.
  await expect(page.getByText('Item item-1').first()).toBeVisible();
  await expect(page.getByRole('button', { name: /Send to kitchen · ₹349.00/ })).toBeVisible();

  // ---------- (3) Send to kitchen (POST submit via MSW) → inline confirmation → View order ----------
  await page.getByRole('button', { name: /Send to kitchen/ }).click();
  await expect(page.getByText('Order placed')).toBeVisible();
  await page.getByRole('button', { name: 'View order' }).click();
  await expect(page).toHaveURL(/\/track$/);

  // ---------- (4) TrackingPage: assert the order + current step, then drive a LIVE update ----------
  // GET /orders returns order-1 (#1042) at PREPARING (step index 2). The "Now" pill marks it.
  await expect(page.getByText('#1042')).toBeVisible();
  // "Preparing" shows in the Stage header AND as the step-2 label — target the first.
  await expect(page.getByText('Preparing').first()).toBeVisible();

  // RT-02: push a live OrderResponse (status READY) to the /orders topic and assert the step
  // machine advanced to the READY step end-to-end (no REST refetch, pure WebSocket-driven update).
  await page.evaluate(
    ([dest, frame]) => window.__stompPush!(dest as string, frame as { destination: string; data: unknown }),
    [ORDERS_TOPIC, orderReadyFrame] as const,
  );
  // Assert the step machine ADVANCED, not merely that a "Ready" label exists (every one of the
  // five step labels is always in the DOM, just dimmed when not yet reached — so a bare
  // getByText('Ready') is a false positive). The Stage header VALUE cell is the unambiguous live
  // signal: it renders exactly STEPS[step].label, reading "Preparing" before the push and flipping
  // to "Ready" only once applyLiveOrder lands the READY frame. Target the value div that sits
  // immediately after the "Stage" label so the dimmed step-list "Ready" cannot satisfy it.
  const stageValue = page
    .locator('.label', { hasText: /^Stage$/ })
    .locator('xpath=following-sibling::div[1]');
  await expect(stageValue).toHaveText('Ready');

  // ---------- (5) ServiceRequestPage: assert the live list, raise a request, then push a LIVE SR ----------
  // Navigate CLIENT-SIDE via the in-app "Need help" button (React Router), NOT page.goto — a
  // full reload would remount SessionProvider, which rehydrates token/sessionId from storage but
  // leaves status=null, so the RealtimeProvider gate (status==='ACTIVE') would never re-open and
  // the live SR push would land on no subscription. An in-app navigation keeps the ACTIVE session
  // and the live STOMP subscription intact (the same condition under which the order push above
  // succeeded), so window.__stompPush reaches applyLiveRequest.
  await page.getByRole('button', { name: /Need help/ }).click();
  await expect(page).toHaveURL(/\/help$/);
  // GET list returns sr-1 (OPEN), sr-2 (ACKNOWLEDGED), sr-3 (COMPLETED) across two pages.
  await expect(page.getByTestId('sr-row-sr-1')).toBeVisible();
  await expect(page.getByTestId('sr-row-sr-3')).toBeVisible();

  // Raise a request: pick the WATER tile and Send (POST create via MSW). The provider re-reads
  // the server's list afterwards (D-06, server-authoritative), so success is proven by the
  // "Request sent" toast rather than a persisted optimistic row (the stateless fixture list
  // does not echo sr-new back on the refetch).
  await page.getByTestId('sr-tile-WATER').click();
  // create() refetches the SR list on success (D-06, server-authoritative). That refetch GET is
  // async and would CLOBBER a live-pushed row if it resolved AFTER the push. Wait for the refetch
  // GET to fully complete BEFORE pushing, so sr-live is applied on top of the settled list and no
  // late refetch overwrites it. (sr-row-sr-1/sr-3 are already on screen from the initial GET, so
  // asserting their visibility does NOT actually wait for the create's refetch — the response wait
  // does.) This is the deterministic ordering the live-push assertion depends on.
  // Match the LAST page (pageNumber=1) of the refetch: listServiceRequests aggregates both pages
  // and only commits setRequests after the final page resolves, so waiting on pageNumber=1
  // guarantees the refetch has fully landed before we push sr-live.
  const srRefetch = page.waitForResponse(
    (r) =>
      /\/api\/v1\/guest\/service-requests\/session-1\?.*pageNumber=1/.test(r.url()) &&
      r.request().method() === 'GET' &&
      r.status() === 200,
  );
  await page.getByRole('button', { name: /Send request/ }).click();
  await expect(page.getByText('Request sent')).toBeVisible();
  await srRefetch;
  // The settled refetch still renders the server fixture list (sr-1/sr-3).
  await expect(page.getByTestId('sr-row-sr-1')).toBeVisible();
  await expect(page.getByTestId('sr-row-sr-3')).toBeVisible();

  // RT-02: push a live GuestServiceRequestResponse (fresh id sr-live) to the /service-requests
  // topic and assert the SR list updated live (the new row appears with no REST refetch).
  await page.evaluate(
    ([dest, frame]) => window.__stompPush!(dest as string, frame as { destination: string; data: unknown }),
    [SR_TOPIC, srLiveFrame] as const,
  );
  await expect(page.getByTestId('sr-row-sr-live')).toBeVisible();

  // ---------- (6) RELOAD to /track, then PROVE realtime survives the reload (CR-01 lock-in) ----------
  // This goto is a deliberate FULL RELOAD (not client-side nav). Before CR-01 was fixed, a reload
  // remounted SessionProvider, which rehydrated token/sessionId from sessionStorage but left
  // status=null — so the RealtimeProvider gate (status==='ACTIVE') never reopened and the live WS
  // subscription was silently dead for the rest of the session. CR-01 makes the rehydrate re-derive
  // ACTIVE for a valid, non-expired token, so the gate reopens and the fresh fake STOMP factory
  // re-subscribes on activate. We assert that BY pushing a live frame AFTER the reload and seeing
  // the UI update with no REST refetch — locking in CR-01 so a regression fails this spec.
  await page.goto('/track');
  await expect(page.getByText('#1042')).toBeVisible();
  // After reload, GET /orders re-seeds order-1 at PREPARING. Wait for window.__stompPush to be
  // re-registered by the reloaded bootstrap (it is set inside the mocking branch before render).
  await page.waitForFunction(() => typeof window.__stompPush === 'function');
  const stageValueAfterReload = page
    .locator('.label', { hasText: /^Stage$/ })
    .locator('xpath=following-sibling::div[1]');
  await expect(stageValueAfterReload).toHaveText('Preparing');
  // Push a live READY frame on the reloaded session. If realtime did NOT survive the reload
  // (the CR-01 bug) this push lands on no subscription and the stage stays "Preparing" → fail.
  await page.evaluate(
    ([dest, frame]) => window.__stompPush!(dest as string, frame as { destination: string; data: unknown }),
    [ORDERS_TOPIC, orderReadyFrame] as const,
  );
  await expect(stageValueAfterReload).toHaveText('Ready');

  // ---------- (7) complete checkout (POST checkout via MSW) ----------
  await page.getByRole('button', { name: 'Done? Close the bill' }).click();
  await page.getByRole('button', { name: 'Confirm — this closes your table' }).click();
  // checkout() success navigates to /checkout (the session summary screen).
  await expect(page).toHaveURL(/\/checkout$/);
});
