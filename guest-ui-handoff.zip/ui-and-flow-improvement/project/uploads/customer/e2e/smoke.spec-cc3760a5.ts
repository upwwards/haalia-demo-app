import { expect, test } from '@playwright/test';

// Minimal boot check — the full guest-flow E2E lands in Phase 5.
test('app shell responds at /', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('body')).toBeVisible();
});
