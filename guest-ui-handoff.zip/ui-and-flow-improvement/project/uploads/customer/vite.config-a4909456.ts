import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { port: 5175 },
  // sockjs-client (the real STOMP transport behind RealtimeProvider, statically in the module
  // graph) references the Node-only `global` at module-eval time, which is undefined in the
  // browser and throws "global is not defined" — blanking the entire app render. Alias it to
  // the browser-standard globalThis (the canonical Vite polyfill for sockjs-client).
  define: { global: 'globalThis' },
});
