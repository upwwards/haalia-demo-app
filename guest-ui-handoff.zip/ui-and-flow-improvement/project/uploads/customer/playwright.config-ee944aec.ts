import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  use: { baseURL: 'http://localhost:5175' },
  webServer: {
    // The repo's node_modules/.bin shims lack the exec bit, so `npm run dev` (which spawns the
    // `vite` shim) fails with "vite: Permission denied". Invoke Vite via its Node entrypoint
    // instead — same dev server, same port, no .bin shim. (Project constraint: run tools via node
    // entrypoints, not .bin/npx.)
    command: 'node ../../node_modules/vite/bin/vite.js --port 5175',
    url: 'http://localhost:5175',
    reuseExistingServer: !process.env.CI,
    env: { VITE_API_MOCKING: 'enabled' },
  },
});
